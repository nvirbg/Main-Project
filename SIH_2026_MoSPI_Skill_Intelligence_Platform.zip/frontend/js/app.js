/**
 * Main Application Controller & Bootstrapper
 * Mount-Once Shell Architecture:
 * - Mounts the static portal shell once, preventing full DOM re-creation
 * - Tab navigation and state changes update elements in-place with ZERO blinking/flickering
 * - Eliminates cross-session data leakage
 */

let currentShell = null; // 'login' | 'portal'

// In-place tab switcher without re-rendering or blinking
const switchTab = (tabName) => {
  const state = store.getState();
  const userRole = String(state.currentUser?.role_name || state.currentUser?.role || state.activePersona || "").toLowerCase();
  const isAdmin = userRole.includes("admin") || state.activePersona === "admin";
  const isAnalyst = userRole.includes("analyst") || state.activePersona === "analyst";

  // Strict RBAC Guard: Only Administrator can access 'admin' tab
  if (tabName === "admin" && !isAdmin) {
    store.showToast("🛡️ Access Restricted: Admin Analytics is strictly reserved for Administrators.", "warning");
    tabName = isAnalyst ? "faculty" : "learner";
  }

  // Strict RBAC Guard: Only Data Analyst / Faculty can access 'faculty' tab
  if (tabName === "faculty" && !isAnalyst) {
    tabName = isAdmin ? "admin" : "learner";
  }

  store.state.activeTab = tabName;

  // 1. Update navigation tab active states in-place
  document.querySelectorAll(".nav-tab-btn").forEach(btn => {
    if (btn.getAttribute("data-tab") === tabName) {
      btn.classList.add("active");
    } else {
      btn.classList.remove("active");
    }
  });

  // 2. Update view panel active states in-place
  document.querySelectorAll(".tab-view").forEach(view => {
    if (view.id === `view-${tabName}`) {
      view.classList.add("active");
    } else {
      view.classList.remove("active");
    }
  });

  if (tabName === "quiz" && window.QuizComponent && window.QuizComponent.loadBackendQuizzes) {
    window.QuizComponent.loadBackendQuizzes();
  }
};
window.switchTab = switchTab;

const renderApp = () => {
  const state = store.getState();
  const root = document.getElementById("app-root");
  if (!root) return;

  // CASE 1: User is NOT authenticated
  if (!state.isAuthenticated) {
    if (currentShell !== "login") {
      currentShell = "login";
      root.innerHTML = `
        ${LoginComponent.render(state)}
        <!-- Dedicated Toast Container -->
        <div class="toast-container" id="global-toast-container"></div>
      `;
      LoginComponent.bindEvents();
    }
    return;
  }

  // CASE 2: User IS authenticated
  if (currentShell !== "portal") {
    currentShell = "portal";
    root.innerHTML = `
      <div class="gov-tricolor-strip"></div>
      <div class="bg-ambient"></div>
      <div class="app-container" id="main-portal-shell">
        <div id="navbar-mount">
          ${NavbarComponent.render(state)}
        </div>

        <main class="main-content" id="main-tab-content">
          ${LearnerDashboardComponent.render(state)}
          ${typeof FacultyDashboardComponent !== 'undefined' ? FacultyDashboardComponent.render(state) : ''}
          ${SkillGapComponent.render(state)}
          ${QuizComponent.render(state)}
          ${CoursesComponent.render(state)}
          ${AssistantComponent.render(state)}
          ${AdminDashboardComponent.render(state)}
        </main>

        <!-- Toast Container -->
        <div class="toast-container" id="global-toast-container"></div>

        <!-- Modals -->
        ${SecurityModal.render()}
        ${DbStatusModal.render()}
      </div>

      <!-- Floating Chat FAB & Drawer (outside app-container for fixed positioning) -->
      <div id="chat-fab-mount">
        ${AssistantComponent.renderFab(state)}
      </div>
    `;

    // Bind events once for the mounted portal shell
    NavbarComponent.bindEvents();
    LearnerDashboardComponent.bindEvents();
    if (typeof FacultyDashboardComponent !== 'undefined') {
      FacultyDashboardComponent.bindEvents();
    }
    SkillGapComponent.bindEvents();
    QuizComponent.bindEvents();
    CoursesComponent.bindEvents();
    AssistantComponent.bindEvents();
    AssistantComponent.bindFabEvents();
    AdminDashboardComponent.bindEvents();
    SecurityModal.bindEvents();
    DbStatusModal.bindEvents();

    // Determine initial tab based on role
    const initialRole = String(state.currentUser?.role_name || state.currentUser?.role || state.activePersona || "").toLowerCase();
    let initialTab = state.activeTab;
    if (!initialTab) {
      if (initialRole.includes("admin")) initialTab = "admin";
      else if (initialRole.includes("analyst")) initialTab = "faculty";
      else initialTab = "learner";
    }
    switchTab(initialTab);
    return;
  }

  // Shell is ALREADY mounted: update dynamic elements in-place without wiping the DOM!
  const navMount = document.getElementById("navbar-mount");
  if (navMount) {
    navMount.innerHTML = NavbarComponent.render(state);
    NavbarComponent.bindEvents();
  }

  // In-place refresh of quiz view when quiz state changes
  const viewQuiz = document.getElementById("view-quiz");
  if (viewQuiz && viewQuiz.parentElement) {
    const temp = document.createElement("div");
    temp.innerHTML = QuizComponent.render(state);
    const newView = temp.firstElementChild;
    if (newView) {
      viewQuiz.parentElement.replaceChild(newView, viewQuiz);
      QuizComponent.bindEvents();
    }
  }

  // In-place refresh of courses view if in DOM
  const viewCourses = document.getElementById("view-courses");
  if (viewCourses && viewCourses.parentElement) {
    const temp = document.createElement("div");
    temp.innerHTML = CoursesComponent.render(state);
    const newView = temp.firstElementChild;
    if (newView) {
      viewCourses.parentElement.replaceChild(newView, viewCourses);
      CoursesComponent.bindEvents();
    }
  }

  // Only mount chat FAB/drawer if not yet present in DOM to prevent wiping user input or closing drawer
  const fabMount = document.getElementById("chat-fab-mount");
  if (fabMount && !fabMount.firstElementChild) {
    fabMount.innerHTML = AssistantComponent.renderFab(state);
    AssistantComponent.bindFabEvents();
  }

  // Only switch tab if activeTab in DOM is not already matching
  const currentActiveTabEl = document.querySelector(".tab-view.active");
  const targetTabId = `view-${state.activeTab || 'learner'}`;
  if (!currentActiveTabEl || currentActiveTabEl.id !== targetTabId) {
    switchTab(state.activeTab || "learner");
  }
};

// Global Persona Switcher for the Hackathon Demonstration
window.switchPersona = async (personaKey) => {
  const persona = CONFIG.DEMO_USERS[personaKey];
  if (!persona) return;

  store.resetSession();
  store.setState({ 
    isAuthenticated: true,
    activePersona: personaKey, 
    currentUser: {
      name: persona.name,
      email: persona.email,
      designation: persona.designation,
      role_name: persona.role,
      department_name: persona.department
    },
    isLoading: true 
  });
  store.showToast(`Switched persona to: ${persona.name} (${persona.designation})`, "info");

  try {
    const authRes = await API.login(persona.email, persona.password);
    if (authRes && authRes.access_token) {
      localStorage.setItem("token", authRes.access_token);
      store.setState({ token: authRes.access_token, backendOnline: true });
    }
  } catch (err) {
    console.warn("Backend auth failed or offline, operating in verified demo mode:", err);
  }

  if (personaKey === "admin") {
    switchTab("admin");
  } else if (personaKey === "analyst") {
    switchTab("faculty");
  } else {
    switchTab("learner");
  }

  await refreshBackendData();
};

// Refresh Data from FastAPI Backend with batching to avoid repetitive rendering
const refreshBackendData = async () => {
  try {
    const isAlive = await API.checkHealth();
    if (!isAlive) {
      store.setState({ backendOnline: false });
      return;
    }

    // Parallel fetch of all portal datasets
    const [dashRes, coursesRes, recsRes, gapsRes, adminRes] = await Promise.allSettled([
      API.getLearnerDashboard(),
      API.getCourses(),
      API.getRecommendations(),
      API.getSkillGaps(),
      API.getAdminDashboard()
    ]);

    const updates = { backendOnline: true };

    if (dashRes.status === "fulfilled" && dashRes.value) {
      updates.learnerDashboard = dashRes.value;
      if (dashRes.value.learner?.overall_competency_pct) {
        updates.overallScore = dashRes.value.learner.overall_competency_pct;
      }
    }
    if (coursesRes.status === "fulfilled" && coursesRes.value && coursesRes.value.length > 0) {
      updates.courses = coursesRes.value;
    }
    if (recsRes.status === "fulfilled" && recsRes.value?.recommendations) {
      updates.recommendations = recsRes.value.recommendations;
    }
    if (gapsRes.status === "fulfilled" && gapsRes.value?.gaps) {
      updates.skillGaps = gapsRes.value.gaps;
    }
    if (adminRes.status === "fulfilled" && adminRes.value) {
      updates.adminDashboard = adminRes.value;
    }

    // Single batched state update
    store.setState(updates);

    // In-place refresh of navbar in DOM
    const navbarMount = document.getElementById("navbar-mount");
    if (navbarMount) {
      navbarMount.innerHTML = NavbarComponent.render(store.getState());
      NavbarComponent.bindEvents();
    }

    // In-place refresh of learner dashboard view if in DOM
    const viewLearner = document.getElementById("view-learner");
    if (viewLearner && viewLearner.parentElement) {
      const temp = document.createElement("div");
      temp.innerHTML = LearnerDashboardComponent.render(store.getState());
      const newView = temp.firstElementChild;
      if (newView) {
        viewLearner.parentElement.replaceChild(newView, viewLearner);
        LearnerDashboardComponent.bindEvents();
      }
    }

    // In-place refresh of courses view if in DOM
    const viewCourses = document.getElementById("view-courses");
    if (viewCourses && viewCourses.parentElement && updates.courses) {
      const temp = document.createElement("div");
      temp.innerHTML = CoursesComponent.render(store.getState());
      const newView = temp.firstElementChild;
      if (newView) {
        viewCourses.parentElement.replaceChild(newView, viewCourses);
        CoursesComponent.bindEvents();
      }
    }

    // In-place refresh of skill gap view if in DOM
    const viewSkillGap = document.getElementById("view-skill-gap");
    if (viewSkillGap && viewSkillGap.parentElement && updates.skillGaps) {
      const temp = document.createElement("div");
      temp.innerHTML = SkillGapComponent.render(store.getState());
      const newView = temp.firstElementChild;
      if (newView) {
        viewSkillGap.parentElement.replaceChild(newView, viewSkillGap);
        SkillGapComponent.bindEvents();
      }
    }

    // In-place refresh of admin dashboard view if in DOM
    const viewAdmin = document.getElementById("view-admin");
    if (viewAdmin && viewAdmin.parentElement && updates.adminDashboard) {
      const temp = document.createElement("div");
      temp.innerHTML = AdminDashboardComponent.render(store.getState());
      const newView = temp.firstElementChild;
      if (newView) {
        viewAdmin.parentElement.replaceChild(newView, viewAdmin);
        AdminDashboardComponent.bindEvents();
      }
    }
  } catch (err) {
    console.warn("Could not sync with backend, continuing with local dataset:", err);
  }
};

// Initialize Application
document.addEventListener("DOMContentLoaded", async () => {
  const savedTheme = localStorage.getItem("theme") || "light";
  document.documentElement.setAttribute("data-theme", savedTheme);

  // Subscribe render loop
  store.subscribe(() => {
    renderApp();
  });

  // Initial render
  renderApp();

  // Check backend health & existing token session
  try {
    const isLive = await API.checkHealth();
    store.setState({ backendOnline: isLive });

    const existingToken = localStorage.getItem("token");
    if (existingToken && isLive) {
      store.setState({ isAuthenticated: true, token: existingToken });
      await refreshBackendData();
    } else {
      store.setState({ isAuthenticated: false });
    }
  } catch (e) {
    console.log("Ready in zero-config mode.");
  }
});

