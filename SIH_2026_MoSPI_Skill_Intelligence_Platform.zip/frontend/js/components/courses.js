/**
 * iGOT Karmayogi & NSSTA Course Catalogue Component
 * MoSPI Capacity Building & Competency Framework Integration
 */

const CoursesComponent = (() => {
  let activeFilter = "all";
  let searchQuery = "";

  const defaultCatalog = [
    {
      id: 1,
      igot_course_id: "IGOT-STAT-001",
      title: "Modern Survey Sampling and Estimation Techniques",
      description: "Comprehensive course covering stratified multistage sampling, cluster design, and weights calibration for official statistical surveys like NSSO and PLFS.",
      provider: "iGOT Karmayogi",
      duration_hours: 18.5,
      level: "intermediate",
      category: "statistical",
      is_tpac_recommended: true,
      skills: ["Sampling Techniques & Estimation", "Survey Design & Questionnaire Formulation"]
    },
    {
      id: 2,
      igot_course_id: "IGOT-STAT-002",
      title: "National Accounts Statistics & GDP Estimation (SNA 2008)",
      description: "In-depth guide to the System of National Accounts (SNA 2008), sequence of accounts, Gross Value Added (GVA), and sector balance sheets.",
      provider: "NSSTA / MoSPI",
      duration_hours: 24.0,
      level: "advanced",
      category: "statistical",
      is_tpac_recommended: true,
      skills: ["National Accounts Statistics (SNA 2008)", "Industrial Statistics (IIP & ASI)"]
    },
    {
      id: 3,
      igot_course_id: "IGOT-STAT-003",
      title: "Price Index Numbers: CPI & WPI Compilation",
      description: "Index number theory, Laspeyres and Paasche formulas, weighting diagrams, price collection mechanisms, and headline inflation tracking.",
      provider: "MoSPI Prices Wing",
      duration_hours: 14.0,
      level: "intermediate",
      category: "statistical",
      is_tpac_recommended: true,
      skills: ["Price Statistics (CPI & WPI)"]
    },
    {
      id: 4,
      igot_course_id: "IGOT-STAT-004",
      title: "Periodic Labour Force Survey (PLFS) Concepts & Estimation",
      description: "Methodologies for estimating Worker Population Ratio (WPR), Labour Force Participation Rate (LFPR), and activity status.",
      provider: "NSSO / NSSTA",
      duration_hours: 16.0,
      level: "intermediate",
      category: "statistical",
      is_tpac_recommended: true,
      skills: ["Labour Statistics & PLFS", "Sampling Techniques & Estimation"]
    },
    {
      id: 5,
      igot_course_id: "IGOT-STAT-005",
      title: "Agricultural Statistics & Crop Estimation Methodologies",
      description: "General Crop Estimation Survey (GCES), land-use classifications, and integration of remote sensing with agricultural surveys.",
      provider: "MoSPI Agriculture Division",
      duration_hours: 12.0,
      level: "intermediate",
      category: "statistical",
      is_tpac_recommended: false,
      skills: ["Agricultural Statistics & Crop Estimation"]
    },
    {
      id: 6,
      igot_course_id: "IGOT-STAT-006",
      title: "SDG National Indicator Framework (NIF) Monitoring",
      description: "Alignment of official indicators with UN Sustainable Development Goals, baseline setting, and periodic progress tracking.",
      provider: "MoSPI Social Statistics",
      duration_hours: 10.0,
      level: "beginner",
      category: "statistical",
      is_tpac_recommended: true,
      skills: ["SDG Indicators & Monitoring Framework", "Metadata Standards (SDMX)"]
    },
    {
      id: 7,
      igot_course_id: "IGOT-STAT-007",
      title: "Data Quality Assurance Frameworks (DQAF) in Official Surveys",
      description: "International quality frameworks, non-sampling error detection, imputation algorithms, and survey audit methodologies.",
      provider: "NSSTA",
      duration_hours: 15.0,
      level: "advanced",
      category: "statistical",
      is_tpac_recommended: true,
      skills: ["Data Quality Assurance Frameworks", "Survey Design & Questionnaire Formulation"]
    },
    {
      id: 8,
      igot_course_id: "IGOT-TECH-001",
      title: "Python for Official Statistics & Microdata Analysis",
      description: "Hands-on data cleaning, tabulation, and automated report generation for large sample survey microdata using Python, Pandas, and SciPy.",
      provider: "iGOT Karmayogi",
      duration_hours: 30.0,
      level: "beginner",
      category: "technical",
      is_tpac_recommended: true,
      skills: ["Python for Statistical Computing", "Data Visualization & Power BI / Tableau"]
    },
    {
      id: 9,
      igot_course_id: "IGOT-TECH-002",
      title: "Applied Econometrics & Survey Analysis using R & Stata",
      description: "Specialized course on survey-weighted regressions, instrumental variables, and impact evaluation using R and Stata for policy research.",
      provider: "NSSTA",
      duration_hours: 22.0,
      level: "intermediate",
      category: "technical",
      is_tpac_recommended: true,
      skills: ["R Programming & R-Studio", "Stata for Econometrics & Surveys"]
    },
    {
      id: 10,
      igot_course_id: "IGOT-TECH-003",
      title: "SQL & Relational Databases for Large Microdata",
      description: "SQL joins, window functions, database indexing, and query optimization for NSS and Census microdata tables.",
      provider: "iGOT Karmayogi",
      duration_hours: 16.0,
      level: "beginner",
      category: "technical",
      is_tpac_recommended: false,
      skills: ["SQL & Relational Databases"]
    },
    {
      id: 11,
      igot_course_id: "IGOT-TECH-004",
      title: "GIS & Spatial Sampling Boundaries with QGIS",
      description: "Geotagging field locations, creating primary sampling units using satellite imagery, and spatial statistics in QGIS.",
      provider: "NSSTA / Survey of India",
      duration_hours: 20.0,
      level: "intermediate",
      category: "technical",
      is_tpac_recommended: true,
      skills: ["GIS & Spatial Data Analysis (QGIS)"]
    },
    {
      id: 12,
      igot_course_id: "IGOT-TECH-005",
      title: "Interactive Data Visualization & Dashboards (Power BI)",
      description: "Transforming static statistical releases into dynamic interactive executive dashboards for policymaker consumption.",
      provider: "iGOT Karmayogi",
      duration_hours: 15.0,
      level: "beginner",
      category: "technical",
      is_tpac_recommended: true,
      skills: ["Data Visualization & Power BI / Tableau"]
    },
    {
      id: 13,
      igot_course_id: "IGOT-TECH-006",
      title: "AI & Machine Learning for Survey Data Validation",
      description: "Applying machine learning algorithms to detect anomalies, outliers, and fraudulent survey records in field microdata.",
      provider: "MoSPI DIID",
      duration_hours: 25.0,
      level: "advanced",
      category: "technical",
      is_tpac_recommended: true,
      skills: ["AI / Machine Learning for Data Quality", "Python for Statistical Computing"]
    },
    {
      id: 14,
      igot_course_id: "IGOT-TECH-007",
      title: "Statistical APIs & Open Data Dissemination (SDMX)",
      description: "Developing REST APIs for official datasets, complying with NDAP and international SDMX data exchange specifications.",
      provider: "MoSPI Computer Centre",
      duration_hours: 12.0,
      level: "intermediate",
      category: "technical",
      is_tpac_recommended: false,
      skills: ["Statistical APIs & Open Data Dissemination", "Metadata Standards (SDMX)"]
    },
    {
      id: 15,
      igot_course_id: "IGOT-GOV-001",
      title: "Data Privacy, DPDP Act 2023 & Cybersecurity in Government",
      description: "Mandatory training on the Digital Personal Data Protection Act, secure data handling, CERT-In compliance, and citizen data safeguards.",
      provider: "iGOT Karmayogi",
      duration_hours: 8.0,
      level: "beginner",
      category: "digital_governance",
      is_tpac_recommended: false,
      skills: ["Data Privacy & DPDP Act 2023", "Cybersecurity & CERT-In Guidelines"]
    },
    {
      id: 16,
      igot_course_id: "IGOT-GOV-002",
      title: "Government Cloud Computing on MeghRaj for Statistics",
      description: "Hosting high-frequency economic pipelines on National Informatics Centre's MeghRaj GI Cloud securely.",
      provider: "NIC / MeitY",
      duration_hours: 14.0,
      level: "intermediate",
      category: "digital_governance",
      is_tpac_recommended: true,
      skills: ["Government Cloud (MeghRaj)", "Cloud Computing & Big Data Analytics"]
    },
    {
      id: 17,
      igot_course_id: "IGOT-GOV-003",
      title: "Digital Signatures & Paperless e-Office Operations",
      description: "Managing DSC tokens, document encryption, and automated workflow tracking inside the e-Office framework.",
      provider: "iGOT Karmayogi",
      duration_hours: 6.0,
      level: "beginner",
      category: "digital_governance",
      is_tpac_recommended: false,
      skills: ["Digital Signatures & e-Office Operations"]
    },
    {
      id: 18,
      igot_course_id: "IGOT-GOV-004",
      title: "Digital Public Infrastructure (DPI) & India Stack Integration",
      description: "Harnessing Aadhaar authentication, DigiLocker, and UPI transactional data streams for statistical compilation.",
      provider: "iGOT Karmayogi",
      duration_hours: 10.0,
      level: "intermediate",
      category: "digital_governance",
      is_tpac_recommended: true,
      skills: ["Digital Public Infrastructure (DPI)"]
    },
    {
      id: 19,
      igot_course_id: "IGOT-MGT-001",
      title: "Statistical Ethics, Leadership & Field Survey Management",
      description: "Guidance on UN Fundamental Principles of Official Statistics, managing field enumerators, conflict resolution, and quality inspection.",
      provider: "NSSTA",
      duration_hours: 12.0,
      level: "intermediate",
      category: "behavioural",
      is_tpac_recommended: true,
      skills: ["Statistical Ethics & Code of Practice", "Leadership & Team Management", "Project Management in Statistical Operations"]
    },
    {
      id: 20,
      igot_course_id: "IGOT-MGT-002",
      title: "Effective Communication & Dissemination of Official Statistics",
      description: "Translating technical statistical indices into clear press releases, infographics, and policy briefs for decision-makers.",
      provider: "NSSTA",
      duration_hours: 10.0,
      level: "beginner",
      category: "behavioural",
      is_tpac_recommended: true,
      skills: ["Communication & Statistical Dissemination"]
    },
    {
      id: 21,
      igot_course_id: "IGOT-MGT-003",
      title: "Project Management for Large-Scale Field Surveys",
      description: "Work breakdown structures, budget tracking, field monitoring protocols, and risk mitigation in nationwide surveys.",
      provider: "NSSTA",
      duration_hours: 18.0,
      level: "advanced",
      category: "behavioural",
      is_tpac_recommended: true,
      skills: ["Project Management in Statistical Operations", "Leadership & Team Management"]
    },
    {
      id: 22,
      igot_course_id: "IGOT-MGT-004",
      title: "Change Management & CAPI Digital Transformation",
      description: "Managing the organizational transition from Paper-Assisted Personal Interview (PAPI) to Computer-Assisted Personal Interview (CAPI).",
      provider: "NSSTA",
      duration_hours: 12.0,
      level: "intermediate",
      category: "behavioural",
      is_tpac_recommended: true,
      skills: ["Change Management & Technology Adoption"]
    }
  ];

  const getFilteredCourses = () => {
    const state = (window.store && window.store.getState) ? window.store.getState() : {};
    let courses = (state.courses && state.courses.length > 0) ? state.courses : defaultCatalog;

    if (activeFilter !== "all") {
      if (activeFilter === "tpac") {
        courses = courses.filter(c => c.is_tpac_recommended);
      } else {
        const target = String(activeFilter).toLowerCase();
        courses = courses.filter(c => {
          const cat = String(c.category || "").toLowerCase();
          if (cat === target) return true;
          if (target === "statistical" && (cat.includes("stat") || cat.includes("official"))) return true;
          if (target === "technical" && (cat.includes("tech") || cat.includes("data") || cat.includes("python"))) return true;
          if (target === "digital_governance" && (cat.includes("gov") || cat.includes("digital"))) return true;
          if (target === "behavioural" && (cat.includes("behav") || cat.includes("mgt") || cat.includes("lead"))) return true;
          return false;
        });
      }
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      courses = courses.filter(c => 
        String(c.title || "").toLowerCase().includes(q) || 
        String(c.description || "").toLowerCase().includes(q) ||
        String(c.igot_course_id || "").toLowerCase().includes(q) ||
        (Array.isArray(c.skills) && c.skills.some(s => String(s).toLowerCase().includes(q)))
      );
    }

    return courses;
  };

  const renderCards = (courses) => {
    if (!courses || courses.length === 0) {
      return `
        <div class="glass-panel" style="grid-column: 1 / -1; padding: 3rem 2rem; text-align: center; border-radius: 12px;">
          <div style="font-size: 2.75rem; margin-bottom: 0.75rem;">🔍</div>
          <h3 style="font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem; font-size: 1.15rem;">No Courses Match Criteria</h3>
          <p style="color: var(--text-secondary); font-size: 0.875rem; max-width: 440px; margin: 0 auto 1.25rem;">
            No courses found under the current filter or search terms. Click "All Modules" to view the complete catalog.
          </p>
          <button class="btn btn-secondary btn-sm" id="btn-reset-course-filters">
            Show All Modules
          </button>
        </div>
      `;
    }

    return courses.map(c => `
      <div class="glass-panel course-card" style="padding: 1.5rem; display: flex; flex-direction: column; justify-content: space-between;">
        <div class="course-header">
          <div class="course-tags" style="display: flex; gap: 0.4rem; flex-wrap: wrap; margin-bottom: 0.75rem;">
            ${c.is_tpac_recommended ? '<span class="tag-tpac">NSSTA TPAC Priority</span>' : ''}
            <span class="tag-igot">${c.provider}</span>
            <span class="card-badge" style="text-transform: capitalize;">${c.level}</span>
          </div>
          <h3 class="course-title" style="font-size: 1.05rem; font-weight: 700; color: var(--text-primary); margin-bottom: 0.5rem; line-height: 1.35;">
            ${c.title}
          </h3>
          <p style="font-size: 0.825rem; color: var(--text-secondary); margin-bottom: 0.75rem; line-height: 1.45;">
            ${c.description}
          </p>
          <div class="course-meta" style="font-size: 0.78rem; color: var(--text-muted); display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.75rem;">
            <span>⏱️ ${c.duration_hours} hrs</span>
            <span>•</span>
            <span>ID: <code>${c.igot_course_id}</code></span>
          </div>
          <div style="display: flex; flex-wrap: wrap; gap: 0.35rem; margin-bottom: 1rem;">
            ${(c.skills || []).map(s => `<span class="source-badge" style="font-size: 0.72rem; padding: 2px 7px;">${s}</span>`).join('')}
          </div>
        </div>
        <div class="course-footer" style="display: flex; gap: 0.5rem; margin-top: auto; pt: 0.75rem; border-top: 1px solid var(--border-subtle);">
          <button class="btn btn-secondary btn-sm btn-view-syllabus" data-course-id="${c.id || c.igot_course_id}" style="flex: 1;">
            Syllabus Details
          </button>
          <button class="btn btn-primary btn-sm btn-enroll-catalog" data-course-id="${c.id || c.igot_course_id}" style="flex: 1;">
            <span>🚀</span> Enroll on iGOT
          </button>
        </div>
      </div>
    `).join('');
  };

  const render = (state) => {
    const courses = getFilteredCourses();

    return `
      <section class="tab-view ${state.activeTab === 'courses' ? 'active' : ''}" id="view-courses">
        <div class="page-header">
          <div>
            <span class="gov-subtext">Integrated Karmayogi Bharat Ecosystem</span>
            <h1 class="page-title">iGOT Karmayogi & NSSTA Course Catalogue</h1>
            <p class="page-subtitle">Verified capacity-building programmes aligned with India's Official Statistics Competency Framework.</p>
          </div>
          <div class="header-action-group">
            <span class="card-badge" style="background: rgba(16,185,129,0.15); color: #6ee7b7; border-color: rgba(16,185,129,0.3);">
              ✓ iGOT Adapter: API-Ready
            </span>
          </div>
        </div>

        <!-- Filters & Search Toolbar -->
        <div class="glass-panel" style="padding: 1.25rem 1.5rem; margin-bottom: 2rem;">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
            <!-- Category Pills -->
            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
              <button class="sample-pill ${activeFilter === 'all' ? 'active' : ''}" data-filter="all">All Modules</button>
              <button class="sample-pill ${activeFilter === 'tpac' ? 'active' : ''}" data-filter="tpac">★ NSSTA TPAC Priority</button>
              <button class="sample-pill ${activeFilter === 'statistical' ? 'active' : ''}" data-filter="statistical">Statistical Methods</button>
              <button class="sample-pill ${activeFilter === 'technical' ? 'active' : ''}" data-filter="technical">Data Science & Python</button>
              <button class="sample-pill ${activeFilter === 'digital_governance' ? 'active' : ''}" data-filter="digital_governance">Digital Governance</button>
              <button class="sample-pill ${activeFilter === 'behavioural' ? 'active' : ''}" data-filter="behavioural">Leadership & Ethics</button>
            </div>

            <!-- Search Box -->
            <div style="width: 260px;">
              <input type="text" id="course-search-input" placeholder="Search title or skills..." value="${searchQuery}" 
                style="width: 100%; background: var(--bg-secondary); border: 1px solid var(--border-default); border-radius: 8px; padding: 0.5rem 0.75rem; color: var(--text-primary); font-size: 0.85rem; outline: none;" />
            </div>
          </div>
        </div>

        <!-- Course Cards Grid -->
        <div class="course-grid">
          ${renderCards(courses)}
        </div>
      </section>
    `;
  };

  const refreshGrid = () => {
    const grid = document.querySelector("#view-courses .course-grid");
    if (!grid) return;

    // Update active class on pills
    document.querySelectorAll("#view-courses [data-filter]").forEach(btn => {
      if (btn.getAttribute("data-filter") === activeFilter) {
        btn.classList.add("active");
      } else {
        btn.classList.remove("active");
      }
    });

    const courses = getFilteredCourses();
    grid.innerHTML = renderCards(courses);
    bindCardEvents();
  };

  const showSyllabusModal = (course) => {
    let overlay = document.getElementById("course-syllabus-modal-overlay");
    if (!overlay) {
      overlay = document.createElement("div");
      overlay.id = "course-syllabus-modal-overlay";
      overlay.style.cssText = "position: fixed; inset: 0; background: rgba(0,0,0,0.75); backdrop-filter: blur(8px); z-index: 2100; display: flex; align-items: center; justify-content: center; padding: 1.5rem;";
      document.body.appendChild(overlay);
    }
    overlay.innerHTML = `
      <div class="glass-panel" style="max-width: 650px; width: 100%; max-height: 88vh; overflow-y: auto; padding: 2rem; border-color: rgba(99,102,241,0.4); box-shadow: 0 20px 40px rgba(0,0,0,0.4); animation: modalFadeIn 0.25s ease-out;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.25rem; border-bottom: 1px solid var(--border-subtle); padding-bottom: 0.75rem;">
          <div>
            <div style="display: flex; gap: 0.5rem; align-items: center; margin-bottom: 0.35rem; flex-wrap: wrap;">
              <span class="tag-igot">${course.provider}</span>
              <span class="card-badge" style="text-transform: capitalize;">${course.level}</span>
              ${course.is_tpac_recommended ? '<span class="tag-tpac">NSSTA TPAC Priority</span>' : ''}
            </div>
            <h2 style="font-size: 1.25rem; font-weight: 800; color: var(--text-primary); margin: 0;">${course.title}</h2>
            <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;">
              Course ID: <code>${course.igot_course_id}</code> • Total Duration: <strong>${course.duration_hours} Hours</strong>
            </div>
          </div>
          <button class="btn-icon" id="btn-close-syllabus-modal" style="width: 32px; height: 32px; font-size: 1rem; cursor: pointer;">✕</button>
        </div>

        <p style="font-size: 0.875rem; color: var(--text-secondary); line-height: 1.5; margin-bottom: 1.25rem;">
          ${course.description}
        </p>

        <div style="margin-bottom: 1.5rem;">
          <h4 style="font-size: 0.85rem; text-transform: uppercase; color: var(--primary-accent); font-weight: 700; margin-bottom: 0.6rem; letter-spacing: 0.04em;">
            📚 Structured Curriculum Modules
          </h4>
          <div style="display: flex; flex-direction: column; gap: 0.6rem;">
            <div class="glass-card" style="padding: 0.75rem 1rem; border-left: 3px solid #818cf8;">
              <div style="font-weight: 700; font-size: 0.85rem; color: var(--text-primary);">Module 1: Foundational Framework & Methodology (4.5 hrs)</div>
              <div style="font-size: 0.78rem; color: var(--text-muted); margin-top: 2px;">Theoretical underpinnings, international standardizations, and statutory frameworks.</div>
            </div>
            <div class="glass-card" style="padding: 0.75rem 1rem; border-left: 3px solid #34d399;">
              <div style="font-weight: 700; font-size: 0.85rem; color: var(--text-primary);">Module 2: Field Implementation, Sampling & Data Collection (5.0 hrs)</div>
              <div style="font-size: 0.78rem; color: var(--text-muted); margin-top: 2px;">Primary data acquisition, questionnaire design, field enumerator oversight, and protocol rigor.</div>
            </div>
            <div class="glass-card" style="padding: 0.75rem 1rem; border-left: 3px solid #fb923c;">
              <div style="font-weight: 700; font-size: 0.85rem; color: var(--text-primary);">Module 3: Statistical Quality Checks, Tabulation & Verification (5.0 hrs)</div>
              <div style="font-size: 0.78rem; color: var(--text-muted); margin-top: 2px;">Outlier detection, multiplier calibration, cross-validation against administrative data.</div>
            </div>
            <div class="glass-card" style="padding: 0.75rem 1rem; border-left: 3px solid #38bdf8;">
              <div style="font-weight: 700; font-size: 0.85rem; color: var(--text-primary);">Module 4: Dissemination, Policy Impact & Case Studies (4.0 hrs)</div>
              <div style="font-size: 0.78rem; color: var(--text-muted); margin-top: 2px;">Evidence-based policy formulation, SDMX compliant data dissemination, and ministry reporting.</div>
            </div>
          </div>
        </div>

        <div style="margin-bottom: 1.5rem;">
          <h4 style="font-size: 0.85rem; text-transform: uppercase; color: var(--text-muted); font-weight: 700; margin-bottom: 0.5rem; letter-spacing: 0.04em;">
            🎯 Competencies Targeted
          </h4>
          <div style="display: flex; flex-wrap: wrap; gap: 0.4rem;">
            ${(course.skills || []).map(s => `<span class="source-badge" style="font-size: 0.75rem; padding: 4px 8px;">${s}</span>`).join('')}
          </div>
        </div>

        <div style="display: flex; justify-content: flex-end; gap: 0.75rem; border-top: 1px solid var(--border-subtle); padding-top: 1rem;">
          <button class="btn btn-secondary btn-sm" id="btn-modal-dismiss-syllabus">Close</button>
          <button class="btn btn-primary btn-sm" id="btn-modal-enroll-syllabus" data-course-id="${course.id || course.igot_course_id}">
            <span>🚀</span> Enroll on iGOT Karmayogi
          </button>
        </div>
      </div>
    `;
    overlay.style.display = "flex";

    const close = () => { overlay.style.display = "none"; };
    const closeBtn = overlay.querySelector("#btn-close-syllabus-modal");
    if (closeBtn) closeBtn.onclick = close;
    const dismissBtn = overlay.querySelector("#btn-modal-dismiss-syllabus");
    if (dismissBtn) dismissBtn.onclick = close;
    overlay.onclick = (e) => {
      if (e.target === overlay) close();
    };
    const enrollBtn = overlay.querySelector("#btn-modal-enroll-syllabus");
    if (enrollBtn) {
      enrollBtn.onclick = () => {
        if (window.store && window.store.showToast) {
          store.showToast(`Enrolled in "${course.title}" via iGOT Karmayogi API adapter!`, "success");
        }
        close();
      };
    }
  };

  const bindCardEvents = () => {
    // Reset filters button (shown when no courses match)
    const resetBtn = document.getElementById("btn-reset-course-filters");
    if (resetBtn) {
      resetBtn.onclick = () => {
        activeFilter = "all";
        searchQuery = "";
        const searchInput = document.getElementById("course-search-input");
        if (searchInput) searchInput.value = "";
        refreshGrid();
      };
    }

    // Enroll buttons
    document.querySelectorAll("#view-courses .btn-enroll-catalog").forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        btn.textContent = "✓ Enrolled";
        btn.classList.remove("btn-primary");
        btn.classList.add("btn-secondary");
        if (window.store && window.store.showToast) {
          store.showToast("Successfully enrolled via iGOT Karmayogi API adapter!", "success");
        }
      };
    });

    // View syllabus buttons
    document.querySelectorAll("#view-courses .btn-view-syllabus").forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const idAttr = btn.getAttribute("data-course-id");
        const state = (window.store && window.store.getState) ? window.store.getState() : {};
        const allCourses = (state.courses && state.courses.length > 0) ? state.courses : defaultCatalog;
        const course = allCourses.find(c => String(c.id) === idAttr || c.igot_course_id === idAttr);
        if (course) {
          showSyllabusModal(course);
        }
      };
    });
  };

  const bindEvents = () => {
    // Filter click
    document.querySelectorAll("#view-courses [data-filter]").forEach(btn => {
      btn.onclick = (e) => {
        e.preventDefault();
        activeFilter = btn.getAttribute("data-filter");
        refreshGrid();
      };
    });

    // Search input
    const searchInput = document.getElementById("course-search-input");
    if (searchInput) {
      searchInput.oninput = (e) => {
        searchQuery = e.target.value;
        refreshGrid();
      };
    }

    bindCardEvents();
  };

  return { render, bindEvents, refreshGrid };
})();

window.CoursesComponent = CoursesComponent;
