/**
 * Header & Navigation Component
 * Fully professional government header with live DB verification, zero demo dropdown clutter,
 * and authenticated user identity display.
 */

const NavbarComponent = (() => {
  const render = (state) => {
    const user = state.currentUser || 
      (state.learnerDashboard && state.learnerDashboard.learner) || 
      { name: "Karthikeya Sharma", designation: "Junior Statistical Officer (JSO)", role: "Statistical Officer" };

    let displayName = user.name || "Officer Karthikeya Sharma, JSO";
    if (!displayName || displayName.toLowerCase().includes("statistical officer") || displayName === "null") {
      displayName = "Officer Karthikeya Sharma, JSO";
    }
    const displayDesig = user.designation || "Junior Statistical Officer (JSO)";
    const rawRole = String(user.role_name || user.role || (state.currentUser && state.currentUser.role_name) || state.activePersona || "").toLowerCase();
    const isAdmin = (rawRole.includes("admin") || state.activePersona === "admin");
    const isAnalyst = (rawRole.includes("analyst") || state.activePersona === "analyst");
    const statusText = state.backendOnline ? "🟢 MySQL 8.x Active" : "🟠 Offline Mode";
    const userInitial = displayName.replace(/^Officer\s+/i, '').charAt(0).toUpperCase() || "K";

    return `
      <header class="gov-header">
        <div class="header-top">
          <div class="brand-section">
            <div class="emblem-wrapper">
              <span class="emblem-icon">🏛️</span>
            </div>
            <div class="brand-titles">
              <span class="gov-subtext">भारत सरकार | Government of India</span>
              <div class="portal-title">
                MoSPI Skill Intelligence Platform
                <span class="portal-badge">iGOT Karmayogi</span>
              </div>
            </div>
          </div>

          <div class="header-actions">
            <!-- Live Database Connection Indicator -->
            <div class="card-badge" id="backend-status-pill" title="FastAPI & MySQL Connection Status">
              ${statusText}
            </div>

            <!-- Live Database Audit Button -->
            <button class="btn btn-secondary btn-sm" id="btn-verify-db" title="Inspect live records stored in MySQL database" style="display: flex; align-items: center; gap: 0.4rem; padding: 0.35rem 0.8rem; font-size: 0.8rem; border-color: rgba(99,102,241,0.4); background: rgba(99,102,241,0.1); color: var(--primary-accent); font-weight: 600;">
              <span>🗄️</span> Verify DB
            </button>

            <!-- Theme Switcher -->
            <button class="btn-icon" id="theme-toggle-btn" title="Toggle Light/Dark Theme">
              ${state.theme === 'dark' ? '☀️' : '🌙'}
            </button>

            <!-- Official Profile Badge -->
            <div class="user-badge" id="header-user-profile" style="background: rgba(99,102,241,0.12); border: 1px solid rgba(99,102,241,0.3); border-radius: 8px; padding: 4px 12px; display: flex; align-items: center; gap: 0.6rem;">
              <div class="user-avatar" style="background: linear-gradient(135deg, #10b981, #059669); font-weight: 800; color: #fff; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 0.85rem; box-shadow: 0 0 8px rgba(16,185,129,0.4);">
                ${userInitial}
              </div>
              <div class="user-info-mini" style="text-align: left;">
                <span class="user-name-mini" style="font-weight: 700; color: var(--text-primary); font-size: 0.85rem; display: flex; align-items: center; gap: 5px;">
                  <span>🇮🇳</span> ${displayName}
                </span>
                <span class="user-role-mini" style="font-size: 0.72rem; color: var(--success); font-weight: 600; display: block;">
                  ● Active Official • ${displayDesig}
                </span>
              </div>
            </div>

            <!-- Logout Button -->
            <button class="btn btn-secondary btn-sm" id="btn-header-logout" title="Sign out of portal" style="padding: 0.35rem 0.75rem; border-color: rgba(239,68,68,0.3); color: #fca5a5;">
              <span>🚪</span> Logout
            </button>
          </div>
        </div>

        <!-- Navigation Tabs (Strictly Role-Aware RBAC) -->
        <nav class="nav-tabs" id="main-nav-tabs">
          ${isAnalyst ? `
            <!-- Data Analyst / Teacher & Examiner Portal -->
            <button class="nav-tab-btn ${state.activeTab === 'faculty' ? 'active' : ''}" data-tab="faculty">
              <span>👨‍🏫</span> Faculty &amp; Student Studio
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'quiz' ? 'active' : ''}" data-tab="quiz">
              <span>✨</span> AI Assessment &amp; MCQs
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'courses' ? 'active' : ''}" data-tab="courses">
              <span>📚</span> iGOT Course References
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'assistant' ? 'active' : ''}" data-tab="assistant">
              <span>🤖</span> AI Teaching Assistant
            </button>
          ` : isAdmin ? `
            <!-- Administrator Portal (Exclusive Executive Analytics) -->
            <button class="nav-tab-btn admin-tab ${state.activeTab === 'admin' ? 'active' : ''}" data-tab="admin">
              <span>🛡️</span> Admin Analytics ★
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'courses' ? 'active' : ''}" data-tab="courses">
              <span>📚</span> iGOT Academy Catalogue
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'assistant' ? 'active' : ''}" data-tab="assistant">
              <span>🤖</span> AI Platform Assistant
            </button>
          ` : `
            <!-- Statistical Officer (Learner / Trainee) Portal -->
            <button class="nav-tab-btn ${state.activeTab === 'learner' ? 'active' : ''}" data-tab="learner">
              <span>📊</span> Learner Dashboard
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'skill-gap' ? 'active' : ''}" data-tab="skill-gap">
              <span>🎯</span> Skill Gap Profiler
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'quiz' ? 'active' : ''}" data-tab="quiz">
              <span>📝</span> Take Assessments &amp; Quizzes
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'courses' ? 'active' : ''}" data-tab="courses">
              <span>📚</span> iGOT Catalogue
            </button>
            <button class="nav-tab-btn ${state.activeTab === 'assistant' ? 'active' : ''}" data-tab="assistant">
              <span>🤖</span> AI Learning Assistant
            </button>
          `}
        </nav>
      </header>
    `;
  };

  const bindEvents = () => {
    // Live Database Verification Modal Trigger
    const btnVerifyDb = document.getElementById("btn-verify-db");
    if (btnVerifyDb) {
      btnVerifyDb.addEventListener("click", () => {
        if (window.DbStatusModal) {
          window.DbStatusModal.open();
        } else {
          store.showToast("Opening MySQL database inspector...", "info");
        }
      });
    }

    // Theme Toggle
    const themeBtn = document.getElementById("theme-toggle-btn");
    if (themeBtn) {
      themeBtn.addEventListener("click", () => {
        const current = store.getState().theme;
        const nextTheme = current === "dark" ? "light" : "dark";
        document.documentElement.setAttribute("data-theme", nextTheme);
        localStorage.setItem("theme", nextTheme);
        store.setState({ theme: nextTheme });
      });
    }

    // Tab Navigation - Smooth in-place tab switching without full-page destruction
    document.querySelectorAll(".nav-tab-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const tab = btn.getAttribute("data-tab");
        if (window.switchTab) {
          window.switchTab(tab);
        } else {
          store.setState({ activeTab: tab });
        }
      });
    });

    // Logout
    const btnLogout = document.getElementById("btn-header-logout");
    if (btnLogout) {
      btnLogout.addEventListener("click", () => {
        store.logout();
      });
    }
  };

  return { render, bindEvents };
})();

window.NavbarComponent = NavbarComponent;
