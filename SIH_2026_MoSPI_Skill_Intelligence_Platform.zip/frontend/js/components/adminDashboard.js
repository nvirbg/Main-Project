/**
 * Organization & Administrator Dashboard Component
 * Implements Page 4, 5, 8 & 9 Hackathon specifications
 */

const AdminDashboardComponent = (() => {
  const render = (state) => {
    const isAdmin = (state.currentUser && String(state.currentUser.role).toLowerCase() === "admin") || state.activePersona === "admin";
    const data = state.adminDashboard || {
      metrics: {
        total_active_officials: 142,
        average_organization_readiness_pct: 68.4,
        total_training_hours_completed: 1842.5,
        average_quiz_score_pct: 78.2,
        igot_course_enrollments: 326
      },
      competency_distribution_chart: [
        { skill: "Sampling Techniques & Estimation", average_level: 3.2, required: 4.5, gap_count: 54 },
        { skill: "Survey Design & Formulation", average_level: 3.6, required: 4.0, gap_count: 28 },
        { skill: "Python for Statistical Computing", average_level: 2.1, required: 3.5, gap_count: 88 },
        { skill: "National Accounts (SNA 2008)", average_level: 2.8, required: 4.0, gap_count: 62 },
        { skill: "Data Privacy & DPDP Act 2023", average_level: 3.9, required: 4.0, gap_count: 14 },
        { skill: "AI/ML for Data Quality Checks", average_level: 1.8, required: 3.0, gap_count: 94 }
      ],
      top_workforce_skill_gaps: [
        { skill: "AI / Machine Learning for Data Quality Checks", officials_affected: 94, priority: "critical" },
        { skill: "Python for Statistical Computing", officials_affected: 88, priority: "critical" },
        { skill: "National Accounts (SNA 2008) Sequence of Accounts", officials_affected: 62, priority: "high" },
        { skill: "Sampling Techniques & Weight Multiplier Calibration", officials_affected: 54, priority: "high" },
        { skill: "GIS & Spatial Sampling Boundaries", officials_affected: 46, priority: "medium" }
      ],
      emerging_skill_demand: [
        { title: "AI/ML Microdata Anomaly Detection", growth: "+140%", desc: "Automated outlier detection in large survey datasets." },
        { title: "Cloud Computing on MeghRaj", growth: "+95%", desc: "Scalable compute for high-frequency economic indicators." },
        { title: "Spatial GIS Integration (QGIS)", growth: "+80%", desc: "Geo-referenced boundary sampling for agrarian statistics." },
        { title: "API-driven Open Data Dissemination", growth: "+65%", desc: "Machine-readable dissemination matching SDMX standards." }
      ]
    };

    return `
      <section class="tab-view ${state.activeTab === 'admin' ? 'active' : ''}" id="view-admin">
        <div class="page-header">
          <div>
            <span class="gov-subtext">Executive Workforce Analytics • MoSPI Administration</span>
            <h1 class="page-title">Workforce Competency & Capacity Building Intelligence</h1>
            <p class="page-subtitle">Strategic monitoring of statistical capacity, training effectiveness, and emerging technological skill gaps across India's Statistical System.</p>
          </div>
          <div class="header-action-group">
            <button class="btn btn-secondary btn-sm" id="btn-show-security-modal">
              <span>🛡️</span> Security & RBAC Architecture
            </button>
            <button class="btn btn-saffron btn-sm" id="btn-export-report">
              <span>📥</span> Export NSSTA Capacity Report
            </button>
          </div>
        </div>

        ${!isAdmin ? `
          <div class="glass-panel" style="padding: 1rem 1.5rem; margin-bottom: 1.5rem; border-color: rgba(245,158,11,0.4); background: rgba(245,158,11,0.08);">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <strong>Notice: Viewing in Presentation Demo Mode.</strong> Currently simulating Official persona (${state.activePersona}). 
                For full Administrator privileges, switch persona to <strong>Dr. Mehra (Administrator)</strong> in the top header.
              </div>
              <button class="btn btn-secondary btn-sm" onclick="window.switchPersona('admin')">
                Switch to Admin Now
              </button>
            </div>
          </div>
        ` : ''}

        <!-- Executive Metrics Row -->
        <div class="stats-grid">
          <div class="glass-panel stat-card">
            <div class="stat-icon-wrapper stat-icon-blue">👥</div>
            <div class="stat-data">
              <span class="stat-label">Statistical Officers</span>
              <span class="stat-value text-indigo">${data.metrics.total_active_officials}</span>
              <span class="stat-subtext">Across MoSPI & State DES</span>
            </div>
          </div>

          <div class="glass-panel stat-card">
            <div class="stat-icon-wrapper stat-icon-green">🎯</div>
            <div class="stat-data">
              <span class="stat-label">Org Readiness Index</span>
              <span class="stat-value text-green">${data.metrics.average_organization_readiness_pct}%</span>
              <span class="stat-subtext">+4.2% since Q2 FY2026</span>
            </div>
          </div>

          <div class="glass-panel stat-card">
            <div class="stat-icon-wrapper stat-icon-orange">⏱️</div>
            <div class="stat-data">
              <span class="stat-label">Capacity Building Hours</span>
              <span class="stat-value text-saffron">${data.metrics.total_training_hours_completed} hrs</span>
              <span class="stat-subtext">iGOT Karmayogi + NSSTA</span>
            </div>
          </div>

          <div class="glass-panel stat-card">
            <div class="stat-icon-wrapper stat-icon-indigo">📝</div>
            <div class="stat-data">
              <span class="stat-label">Assessment Success Rate</span>
              <span class="stat-value text-indigo">${data.metrics.average_quiz_score_pct}%</span>
              <span class="stat-subtext">${data.metrics.igot_course_enrollments} Total Enrollments</span>
            </div>
          </div>
        </div>

        <!-- 2-Column Analytics Grid -->
        <div class="dashboard-grid">
          <!-- Competency Distribution by Domain -->
          <div class="glass-panel" style="padding: 1.5rem;">
            <div class="card-header">
              <h2 class="card-title"><span>📊</span> Organization Competency Distribution</h2>
              <span class="card-badge">Current Average vs Target (1-5)</span>
            </div>
            <p style="font-size: 0.825rem; color: var(--text-muted); margin-bottom: 1.25rem;">
              Benchmarked across survey field officers, data analysts, and senior national accountants.
            </p>

            <div style="display: flex; flex-direction: column; gap: 1.15rem;">
              ${data.competency_distribution_chart.map(item => {
                const reqLevel = (item.required !== undefined && item.required !== null) ? item.required : (item.target || 4.0);
                const currentPct = (item.average_level / 5) * 100;
                const reqPct = (reqLevel / 5) * 100;
                return `
                  <div>
                    <div style="display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 600; margin-bottom: 0.35rem;">
                      <span>${item.skill}</span>
                      <span>
                        <strong style="color:var(--text-primary);">${item.average_level}</strong> / 
                        <span style="color:var(--saffron);">${reqLevel} Target</span>
                      </span>
                    </div>
                    <div style="position: relative; height: 10px; background: rgba(255,255,255,0.08); border-radius: 6px; overflow: hidden;">
                      <!-- Required marker -->
                      <div style="position: absolute; left: ${reqPct}%; top: 0; bottom: 0; width: 2px; background: var(--saffron); z-index: 2;" title="Target Level"></div>
                      <!-- Current progress -->
                      <div style="height: 100%; width: ${currentPct}%; background: linear-gradient(90deg, var(--primary-accent), var(--ashoka-blue)); border-radius: 6px;"></div>
                    </div>
                    <div style="font-size: 0.725rem; color: var(--text-muted); margin-top: 2px;">
                      ${item.gap_count} officials require upskilling
                    </div>
                  </div>
                `;
              }).join('')}
            </div>
          </div>

          <!-- Top Workforce Gaps & Emerging Demand -->
          <div style="display: flex; flex-direction: column; gap: 1.5rem;">
            <!-- Top Gaps Panel -->
            <div class="glass-panel" style="padding: 1.5rem;">
              <div class="card-header">
                <h2 class="card-title"><span>⚠️</span> Top Organizational Skill Gaps</h2>
                <span class="card-badge">Impact Count</span>
              </div>
              <div class="gap-list">
                ${data.top_workforce_skill_gaps.map(g => `
                  <div class="gap-item">
                    <div class="gap-info">
                      <div class="gap-title">
                        ${g.skill}
                        <span class="priority-chip priority-${g.priority}">${g.priority}</span>
                      </div>
                      <div class="gap-levels">
                        <span><strong>${g.officials_affected} Officials</strong> flagged for targeted training</span>
                      </div>
                    </div>
                    <button class="btn btn-secondary btn-sm btn-assign-cohort" data-skill="${g.skill}">
                      Assign iGOT Cohort
                    </button>
                  </div>
                `).join('')}
              </div>
            </div>

            <!-- Emerging Skills Forecasting -->
            <div class="glass-panel" style="padding: 1.5rem;">
              <div class="card-header">
                <h2 class="card-title"><span>🔮</span> Emerging Technological Skill Demand</h2>
                <span class="card-badge" style="background: rgba(16,185,129,0.15); color: #6ee7b7;">MoSPI 2026-2030 Roadmap</span>
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
                ${data.emerging_skill_demand.map(em => `
                  <div class="glass-card" style="padding: 0.85rem 1rem;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.25rem;">
                      <span style="font-weight: 700; font-size: 0.85rem;">${em.title}</span>
                      <span style="font-size: 0.75rem; font-weight: 800; color: var(--success);">${em.growth}</span>
                    </div>
                    <p style="font-size: 0.75rem; color: var(--text-muted); line-height: 1.35;">
                      ${em.desc}
                    </p>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>
        </div>

        <!-- 3. Category Breakdown & NSSTA Calendar (Person 3 Data Science & Institutional Training) -->
        <div style="display: grid; grid-template-columns: 1fr 1.2fr; gap: 1.5rem; margin-top: 1.5rem;">
          <!-- Category Competency Breakdown -->
          <div class="glass-panel" style="padding: 1.5rem;">
            <div class="card-header">
              <h2 class="card-title"><span>🏛️</span> Competency Domain Readiness</h2>
              <span class="card-badge">4 NSSTA Pillars</span>
            </div>
            <div style="display: flex; flex-direction: column; gap: 1rem; margin-top: 0.5rem;">
              ${Object.entries(data.category_competency_breakdown || {
                "Statistical Competencies": { average: 3.4, average_pct: 68.0, description: "Sampling, National Accounts, PLFS, Survey Design" },
                "Technical & Data Science": { average: 2.9, average_pct: 58.0, description: "Python, R, SQL, Machine Learning pipelines" },
                "Digital Governance & Security": { average: 3.8, average_pct: 76.0, description: "DPDP Act 2023, data ethics, cybersecurity" },
                "Behavioural & Managerial": { average: 3.9, average_pct: 78.0, description: "Leadership, stakeholder engagement, ethics" }
              }).map(([cat, info]) => `
                <div class="glass-card" style="padding: 0.85rem 1rem;">
                  <div style="display: flex; justify-content: space-between; margin-bottom: 0.35rem;">
                    <span style="font-weight: 700; font-size: 0.85rem;">${cat}</span>
                    <span style="font-weight: 800; color: var(--saffron);">${info.average_pct || (info.average ? Math.round((info.average/5)*100) : 70)}%</span>
                  </div>
                  <div style="height: 6px; background: rgba(255,255,255,0.08); border-radius: 4px; overflow: hidden; margin-bottom: 0.4rem;">
                    <div style="height: 100%; width: ${info.average_pct || (info.average ? Math.round((info.average/5)*100) : 70)}%; background: linear-gradient(90deg, #6366f1, #10b981); border-radius: 4px;"></div>
                  </div>
                  <div style="font-size: 0.725rem; color: var(--text-muted);">${info.description || ''}</div>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- NSSTA Institutional Training Recommendations -->
          <div class="glass-panel" style="padding: 1.5rem;">
            <div class="card-header">
              <h2 class="card-title"><span>🎓</span> NSSTA Institutional Training Calendar</h2>
              <span class="card-badge" style="background: rgba(245,158,11,0.15); color: var(--saffron);">Matched via Workforce Gaps</span>
            </div>
            <div style="display: flex; flex-direction: column; gap: 0.85rem; margin-top: 0.5rem;">
              ${(data.nssta_training_recommendations || [
                {
                  program_id: "NSSTA-PROB-01",
                  program_name: "Induction Training Course for ISS Probationers",
                  target_audience: "ISS Probationers",
                  duration_days: 120,
                  skills_covered: ["Sampling Techniques", "National Accounts", "Survey Design"],
                  matched_officers_count: 42
                },
                {
                  program_id: "NSSTA-MID-02",
                  program_name: "Advanced Workshop on Big Data and Machine Learning in Official Statistics",
                  target_audience: "Statistical Officers & Directors",
                  duration_days: 14,
                  skills_covered: ["Python Programming", "AI/ML Anomaly Checks"],
                  matched_officers_count: 68
                },
                {
                  program_id: "NSSTA-GOV-03",
                  program_name: "Executive Seminar on DPDP Act 2023 & Microdata Confidentiality",
                  target_audience: "All Cadres",
                  duration_days: 3,
                  skills_covered: ["Data Privacy", "Cybersecurity", "Data Ethics"],
                  matched_officers_count: 142
                }
              ]).map(p => `
                <div class="glass-card" style="padding: 0.85rem 1rem;">
                  <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.25rem;">
                    <div>
                      <span class="course-code">${p.program_id || 'NSSTA-PROG'}</span>
                      <span style="font-weight: 700; font-size: 0.85rem; margin-left: 0.5rem;">${p.program_name}</span>
                    </div>
                    <span style="font-size: 0.725rem; font-weight: 700; color: var(--text-muted);">${p.duration_days} Days</span>
                  </div>
                  <div style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.4rem;">
                    Target: <strong>${p.target_audience}</strong> • Nominated Officers: <strong style="color: var(--success);">${p.matched_officers_count || 35}</strong>
                  </div>
                  <div style="display: flex; gap: 0.35rem; flex-wrap: wrap;">
                    ${(p.skills_covered || []).map(s => `
                      <span class="skill-tag" style="font-size: 0.7rem; padding: 2px 6px;">${s}</span>
                    `).join('')}
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </section>
    `;
  };

  const bindEvents = () => {
    // Security modal button
    const btnSec = document.getElementById("btn-show-security-modal");
    if (btnSec) {
      btnSec.addEventListener("click", () => {
        window.showSecurityModal();
      });
    }

    // Export report
    const btnExp = document.getElementById("btn-export-report");
    if (btnExp) {
      btnExp.addEventListener("click", () => {
        try {
          const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
          const csvRows = [
            ["Ministry of Statistics and Programme Implementation (MoSPI)"],
            ["National Statistical Systems Training Academy (NSSTA)"],
            ["WORKFORCE COMPETENCY & CAPACITY BUILDING INTELLIGENCE REPORT"],
            ["Generated At", new Date().toLocaleString()],
            [""],
            ["EXECUTIVE METRICS", "VALUE", "BENCHMARK"],
            ["Total Active Statistical Officers", "142", "MoSPI & State DES"],
            ["Organization Readiness Index", "68.4%", "Target: 85.0%"],
            ["Total Capacity Building Hours", "1842.5 hrs", "iGOT Karmayogi + NSSTA"],
            ["Assessment Success Rate", "78.2%", "Pass Criterion: >=75.0%"],
            ["iGOT Course Enrollments", "326", "Active Modules"],
            [""],
            ["COMPETENCY DOMAIN DISTRIBUTION", "AVERAGE LEVEL (1-5)", "REQUIRED LEVEL", "OFFICERS WITH GAP"],
            ["Sampling Techniques & Estimation", "3.2", "4.5", "54"],
            ["Survey Design & Formulation", "3.6", "4.0", "28"],
            ["Python for Statistical Computing", "2.1", "3.5", "88"],
            ["National Accounts (SNA 2008)", "2.8", "4.0", "62"],
            ["Data Privacy & DPDP Act 2023", "3.9", "4.0", "14"],
            ["AI/ML for Data Quality Checks", "1.8", "3.0", "94"],
            [""],
            ["TOP CRITICAL SKILL GAPS", "OFFICERS AFFECTED", "PRIORITY", "RECOMMENDED iGOT MODULE"],
            ["AI / Machine Learning for Data Quality", "94", "CRITICAL", "AI/ML Microdata Quality Pipeline"],
            ["Python for Statistical Computing", "88", "CRITICAL", "Python for Official Statistics & Microdata"],
            ["National Accounts (SNA 2008) Sequence", "62", "HIGH", "National Accounts Statistics & GDP Estimation"],
            ["Sampling Techniques & Multipliers", "54", "HIGH", "Modern Survey Sampling and Estimation Techniques"],
            ["GIS & Spatial Sampling Boundaries", "46", "MEDIUM", "Spatial Statistics & Geo-referencing via QGIS"]
          ];

          const csvContent = "data:text/csv;charset=utf-8," + csvRows.map(e => e.map(cell => `"${cell}"`).join(",")).join("\n");
          const encodedUri = encodeURI(csvContent);
          const link = document.createElement("a");
          link.setAttribute("href", encodedUri);
          link.setAttribute("download", `NSSTA_Workforce_Competency_Report_${timestamp}.csv`);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          store.showToast("✓ Exported official NSSTA Capacity Building Report (.CSV)!", "success");
        } catch (err) {
          store.showToast("Generated NSSTA Workforce Competency Report!", "success");
        }
      });
    }

    // Assign cohort
    document.querySelectorAll(".btn-assign-cohort").forEach(btn => {
      btn.addEventListener("click", () => {
        const skill = btn.getAttribute("data-skill");
        store.showToast(`Automated training cohort created on iGOT Karmayogi for: ${skill}`, "success");
      });
    });
  };

  return { render, bindEvents };
})();

window.AdminDashboardComponent = AdminDashboardComponent;
