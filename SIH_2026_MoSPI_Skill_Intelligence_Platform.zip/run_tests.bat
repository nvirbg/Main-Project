@echo off
title Run All MVP and AI Test Suites (MoSPI / SIH 2026)
color 0B

echo ======================================================================
echo   MoSPI and iGOT Karmayogi - Smart India Hackathon 2026
echo   Running All 9 MVP Test Suites (AI, Data Science, RBAC and Backend)
echo ======================================================================
echo.

cd /d "%~dp0sih_backend\sih_backend"

set PY_CMD=python
if exist "venv\Scripts\python.exe" (
    set PY_CMD=.\venv\Scripts\python.exe
    echo [*] Using project virtual environment (venv)
) else (
    echo [*] Using system Python environment
)

echo.
%PY_CMD% tests\run_all_tests.py
echo.

pause
