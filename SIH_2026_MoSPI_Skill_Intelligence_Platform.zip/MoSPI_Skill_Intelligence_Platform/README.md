# 🏛️ MoSPI & iGOT Karmayogi — AI-Enabled Skill Intelligence & Learning Platform
### Smart India Hackathon (SIH) 2026 | Ministry of Statistics and Programme Implementation (MoSPI) & NSSTA

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.115.0-009688.svg)](https://fastapi.tiangolo.com/)
[![MySQL 8.x](https://img.shields.io/badge/MySQL-8.x%20InnoDB-00758F.svg)](https://www.mysql.com/)
[![iGOT Karmayogi](https://img.shields.io/badge/iGOT-Karmayogi%20Integrated-FF9933.svg)](https://igotkarmayogi.gov.in/)
[![DPDP Act 2023](https://img.shields.io/badge/Security-DPDP%20Act%202023%20%26%20CERT--In-green.svg)](https://www.meity.gov.in/)

---

## 📌 Executive Summary

The **AI-Enabled Skill Intelligence & Learning Platform** is an enterprise-grade capacity-building system designed for the **Ministry of Statistics and Programme Implementation (MoSPI)** and the **National Statistical Systems Training Academy (NSSTA)**. 

The platform bridges the critical competency gap in India's official statistical machinery (JSO, SSO, and ISS cadres) by delivering:
1. **Dynamic Competency Diagnostics**: Baseline evaluation calibrating self-declared skill confidence against role requirements.
2. **AI-Driven Gap Analysis & Action Plans**: Precision scoring (0–5 scale) that details *where to improve* and *how to improve*.
3. **iGOT Karmayogi Course Recommendation**: Blended structural skill-tag matching and semantic search to recommend personalized training tracks.
4. **Multimodal AI Question & Assessment Generator**: Automated MCQ generation with full rationale from uploaded policy and survey materials (PDF, DOCX, PPTX, Text).
5. **Workforce Analytics & Institutional Governance**: Comprehensive real-time administration dashboard for academy heads and ministry leadership.

---

## 👥 Three Core User Portals & Separation of Responsibilities

| Role Category | Persona | Responsibilities & User Flow |
| :--- | :--- | :--- |
| **Statistical Officer** *(Learner / Trainee)* | `Officer Karthikeya Sharma, JSO`<br>`Rajesh Verma, SSO` | • Declares initial competency confidence (0–5 scale) on login.<br>• Undergoes an automatic **AI Baseline Diagnostic Assessment**.<br>• Receives personalized skill gap scores, study roadmap, and iGOT course recommendations.<br>• Engages with the AI Statistical Tutor. |
| **Data Analyst** *(Examiner & Faculty)* | `Priya Nair, Assistant Director` | • **Does not take exams**; serves as the academic examiner and content researcher.<br>• Uploads curriculum documents and generates AI assessments & MCQs.<br>• Evaluates question quality and monitors statistical microdata competency trends. |
| **Administrator** *(NSSTA Academy Head)* | `Dr. Arun Mehra, Director General` | • **Does not take exams**; manages academy-wide operations.<br>• Governs user accounts, departments, and competency frameworks.<br>• Audits live MySQL 8.x database records and monitors division-level compliance. |

---

## 🏗️ System Architecture

```
                                  [ User Browser ]
                                         │
                                         ▼
                 ┌───────────────────────────────────────────────┐
                 │          FastAPI Unified Web Server           │
                 │              (Port 8000 / Uvicorn)            │
                 └───────┬───────────────────────────────┬───────┘
                         │                               │
       Static Assets & Single Page App                   │ REST API / WebSocket
                         │                               │
                         ▼                               ▼
                 ┌──────────────┐                ┌──────────────┐
                 │   Frontend   │                │   Routers    │
                 │ Vanilla SPA  │                │ Auth / Quiz  │
                 │ (HTML5/CSS3) │                │ Admin / iGOT │
                 └──────────────┘                └───────┬──────┘
                                                         │
                                   ┌─────────────────────┴─────────────────────┐
                                   ▼                                           ▼
                         ┌──────────────────┐                        ┌──────────────────┐
                         │   MySQL 8.x DB   │                        │    AI Modules    │
                         │  18 InnoDB Tables│                        │ Claude / TF-IDF  │
                         │   ACID Compliant │                        │ Question Gen     │
                         └──────────────────┘                        └──────────────────┘
```

### 1. Backend & Data Layer
- **FastAPI (ASGI)**: High-performance asynchronous API framework serving both endpoints and static SPA assets.
- **SQLAlchemy 2.0 ORM**: Strict relational mappings with foreign key integrity across 18 InnoDB tables.
- **MySQL 8.x**: Production-grade relational database with automatic SQLite zero-config fallback.
- **Authentication**: Stateless JWT access & refresh tokens with bcrypt password hashing.

### 2. Modern Frontend SPA
- **Zero-Build Architecture**: Native ES6 modules and modern Vanilla CSS (no Node.js build step required).
- **Design System**: Rich Government of India branding with saffron/indigo/emerald accents, ambient dark/light themes, and glassmorphism.
- **Responsive Layout**: Designed for tablets, desktops, and mobile field inspection units.

### 3. AI & Recommendation Engine
- **RAG & TF-IDF Hybrid**: 70% structural competency tag matching combined with 30% semantic text similarity against course metadata.
- **Adaptive Quiz Generator**: Generates 4-option MCQs with explanations, difficulty tiers, and statutory citations (e.g. DPDP Act 2023, SNA 2008).
- **Diagnostic Calibrator**: Real-time evaluation translating test responses into 0–5 skill levels and competency gaps.

---

## 📂 Project Repository Structure

```
├── README.md                      # Comprehensive SIH submission guide
├── requirements.txt               # Top-level Python dependency specifications
├── .env.example                   # Environment configuration template
├── .gitignore                     # Git ignore rules for clean repository
├── start_platform.bat             # One-click Windows launch script
├── run_tests.bat                  # Automated unit and integration test runner
│
├── frontend/                      # Client-Side Application (Mounted at /)
│   ├── index.html                 # Root HTML5 portal shell
│   ├── css/
│   │   ├── styles.css             # Core design system & theme variables
│   │   └── components.css         # UI component styling (cards, tables, modals)
│   └── js/
│       ├── app.js                 # Application bootstrapper & tab controller
│       ├── config.js              # Environment settings & demo personas
│       ├── state.js               # Reactive central state store
│       ├── api.js                 # REST API client adapter
│       └── components/            # UI Components
│           ├── login.js           # Role-based sign-in & diagnostic registration
│           ├── navbar.js          # Header with live DB audit and user status
│           ├── learnerDashboard.js# Competency radars & learning progress
│           ├── skillGap.js        # Skill gap breakdown & required benchmarks
│           ├── quiz.js            # AI assessment runner & exam generator
│           ├── courses.js         # iGOT Karmayogi integrated catalogue
│           ├── assistant.js       # AI statistical mentor & chat drawer
│           ├── adminDashboard.js  # Workforce analytics & audit tables
│           ├── securityModal.js   # DPDP Act & CERT-In compliance modal
│           └── dbStatusModal.js   # Real-time database inspection modal
│
├── sih_backend/sih_backend/       # Core FastAPI Application
│   ├── app/
│   │   ├── main.py                # App entrypoint & static mounting
│   │   ├── config.py              # Pydantic environment configuration
│   │   ├── database.py            # SQLAlchemy engine & session management
│   │   ├── models/                # 18 relational database schema models
│   │   ├── routers/               # API endpoints (auth, quiz, admin, etc.)
│   │   └── services/              # Business logic (recommender, scoring)
│   ├── ai/                        # Question generator & AI assistant modules
│   ├── scripts/                   # Database migrations and seed scripts
│   └── tests/                     # Automated test suites
│
├── sql/                           # Database DDL scripts and seed dumps
└── docs/                          # Architecture diagrams and specifications
```

---

## 🚀 Quick Start Guide

### Prerequisites
- **Python 3.10+** installed on PATH.
- **MySQL 8.x** (optional; the platform automatically supports SQLite if MySQL is offline).

### Step 1: Clone the Repository
```bash
git clone <repository_url>
cd <repository_folder>
```

### Step 2: Set Up Virtual Environment & Dependencies
```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux / macOS:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Step 3: Configure Environment Variables
```bash
cp .env.example .env
```
*(Optionally set your `DATABASE_URL` in `.env`. Default connects to local MySQL `sih_skill_platform` or SQLite).*

### Step 4: Seed Initial Data
```bash
cd sih_backend/sih_backend
python -m scripts.seed
cd ../..
```

### Step 5: Start the Platform (1-Click)
**On Windows**:
Simply double-click:
```bash
start_platform.bat
```

**Or via Terminal**:
```bash
cd sih_backend/sih_backend
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Open your browser and visit:
👉 **[http://localhost:8000](http://localhost:8000)**  
API Documentation: **[http://localhost:8000/docs](http://localhost:8000/docs)**

---

## 🔑 Pre-Configured Demo Credentials

For demonstration and judging, the login screen features **1-click authenticated cards**:

| Persona | Role Category | Email | Password | Access Rights |
| :--- | :--- | :--- | :--- | :--- |
| **Karthikeya Sharma** | Statistical Officer | `karthikeya@mospi.gov.in` | `SecurePassword123!` | Learner, Diagnostic Quiz, Skill Gaps, iGOT Courses |
| **Priya Nair** | Data Analyst | `priya.nair@mospi.gov.in` | `SecurePassword123!` | Examiner, AI MCQ Generator, Analytics (No exam forced) |
| **Dr. Arun Mehra** | Administrator | `admin@nssta.gov.in` | `ChangeMe123!` | Academy Oversight, DB Audit, User Governance |
| **Rajesh Verma** | Senior Stat Officer | `rajesh.verma@mospi.gov.in` | `SecurePassword123!` | Senior Cadre Learner, National Accounts Specialization |

---

## 🧪 Testing & Verification

Run the automated test suite verifying all API routers, AI quiz generators, and recommendation algorithms:
```bash
# Windows
run_tests.bat

# Manual
pytest sih_backend/sih_backend/tests/
```

---

## 🛡️ Security, Privacy & Compliance

- **DPDP Act 2023 Compliant**: Personal data anonymization, explicit consent logs for skill profiling, and role-based access control (RBAC).
- **CERT-In Guidelines**: 6-hour incident disclosure protocols and secure audit logging stored with immutable timestamps.
- **Data Integrity**: Enforced foreign key constraints and transactional rollback protection.

---

## 👥 Team & Submission Information

- **Event**: Smart India Hackathon (SIH) 2026
- **Organization**: Ministry of Statistics and Programme Implementation (MoSPI)
- **Institution**: National Statistical Systems Training Academy (NSSTA)
