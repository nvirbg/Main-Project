"""Person 3 - Data Science & Analytics Lead - Competency Matrix Engine
Provides multi-dimensional competency matrix modeling, role-skill mappings,
and integration with workforce capacity metrics for the MoSPI & NSSTA framework.
"""
import os
import sys
import json
from typing import Any, Dict, List, Optional

# Ensure parent and current directory are on sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Re-export Person 3's core workforce metrics from analytics.metrics
try:
    from analytics.metrics import (
        average_competency,
        top_skill_gaps,
        completion_rate,
        average_quiz_score,
        skill_distribution,
        future_skill_demand,
    )
except ImportError:
    try:
        from metrics import (  # type: ignore
            average_competency,
            top_skill_gaps,
            completion_rate,
            average_quiz_score,
            skill_distribution,
            future_skill_demand,
        )
    except ImportError:
        from .metrics import (  # type: ignore
            average_competency,
            top_skill_gaps,
            completion_rate,
            average_quiz_score,
            skill_distribution,
            future_skill_demand,
        )


def _load_data_file(filename: str) -> Dict[str, Any]:
    """Helper to locate and load json datasets from local data folders."""
    candidates = [
        os.path.join(os.path.dirname(__file__), "..", "data", filename),
        os.path.join(os.path.dirname(__file__), "data", filename),
        os.path.join(os.getcwd(), "data", filename),
        os.path.join(os.getcwd(), "sih_backend", "sih_backend", "data", filename),
    ]
    for p in candidates:
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
    return {}


def load_competency_framework() -> Dict[str, Any]:
    """Loads the 4-domain NSSTA MoSPI Competency Framework."""
    return _load_data_file("competency_framework.json")


def load_roles() -> List[Dict[str, Any]]:
    """Loads all official statistical roles and their competency requirements."""
    data = _load_data_file("roles.json")
    if isinstance(data, list):
        return data
    return data.get("roles", [])


def load_skills() -> List[Dict[str, Any]]:
    """Loads the 32 official skills categorized across 4 domains."""
    data = _load_data_file("skills.json")
    if isinstance(data, list):
        return data
    return data.get("skills", [])


def build_competency_matrix() -> Dict[str, Any]:
    """
    Constructs a full 2D Role-Skill Competency Matrix mapping each role
    to its required skills, target proficiency levels (1-5), and priority.
    """
    roles = load_roles()
    skills = load_skills()
    framework = load_competency_framework()

    skill_by_id = {s["id"]: s for s in skills if "id" in s}
    skill_by_name = {s["name"]: s for s in skills if "name" in s}
    matrix = {}

    for role in roles:
        r_name = role["name"]
        matrix[r_name] = {
            "role_id": role.get("id"),
            "description": role.get("description", ""),
            "competencies": {},
            "domains": {
                "statistical": [],
                "technical": [],
                "digital_governance": [],
                "behavioural": [],
            },
        }

        raw_reqs = role.get("required_skills") or role.get("requirements") or []
        for req in raw_reqs:
            s_id = req.get("skill_id")
            s_name = req.get("skill_name")
            meta = {}
            if s_id and s_id in skill_by_id:
                meta = skill_by_id[s_id]
                s_name = meta.get("name", s_name or s_id)
            elif s_name and s_name in skill_by_name:
                meta = skill_by_name[s_name]
                s_id = meta.get("id", s_id)
            else:
                s_name = s_name or s_id or "Unknown Skill"

            req_lvl = req.get("required_level", 3)
            raw_p = req.get("priority", "medium")
            if isinstance(raw_p, (int, float)):
                if raw_p >= 0.9:
                    priority = "critical"
                elif raw_p >= 0.7:
                    priority = "high"
                else:
                    priority = "medium"
            else:
                priority = str(raw_p).lower()

            raw_cat = meta.get("category") or meta.get("domain", "statistical")
            cat_norm = raw_cat.lower()
            if "stat" in cat_norm:
                domain = "statistical"
            elif "tech" in cat_norm:
                domain = "technical"
            elif "gov" in cat_norm or "priv" in cat_norm or "cyber" in cat_norm:
                domain = "digital_governance"
            else:
                domain = "behavioural"

            comp_entry = {
                "skill_id": s_id,
                "skill_name": s_name,
                "required_level": req_lvl,
                "priority": priority,
                "domain": domain,
                "description": meta.get("description", ""),
            }

            matrix[r_name]["competencies"][s_name] = comp_entry
            if domain in matrix[r_name]["domains"]:
                matrix[r_name]["domains"][domain].append(comp_entry)

    return {
        "framework_name": framework.get("framework_name", "MoSPI Competency Framework"),
        "version": framework.get("version", "2026.1"),
        "roles_count": len(roles),
        "skills_count": len(skills),
        "matrix": matrix,
    }


def get_role_competency_matrix(role_name: str) -> Optional[Dict[str, Any]]:
    """Retrieves the specific competency requirement vector for a given role."""
    full_matrix = build_competency_matrix()["matrix"]
    # Case-insensitive lookup
    for name, data in full_matrix.items():
        if name.lower() == role_name.lower():
            return data
    return None


def evaluate_official_against_matrix(
    user_skills: Dict[str, int], role_name: str
) -> Dict[str, Any]:
    """
    Evaluates an official's current skill profile against the Competency Matrix for their role.
    Computes domain-wise scores, overall readiness %, and weighted skill gaps.
    """
    role_data = get_role_competency_matrix(role_name)
    if not role_data:
        # Fallback evaluation
        return {
            "role": role_name,
            "overall_readiness_pct": 100.0,
            "domain_scores": {},
            "gaps": [],
        }

    competencies = role_data["competencies"]
    total_required = 0
    total_acquired = 0
    gaps = []
    domain_totals: Dict[str, Dict[str, int]] = {}

    priority_weights = {"critical": 3.0, "high": 2.0, "medium": 1.0, "low": 0.5}

    for skill_name, req in competencies.items():
        req_level = req["required_level"]
        priority = req["priority"].lower()
        domain = req["domain"]
        curr_level = user_skills.get(skill_name, 0)
        acquired = min(curr_level, req_level)

        total_required += req_level
        total_acquired += acquired

        if domain not in domain_totals:
            domain_totals[domain] = {"required": 0, "acquired": 0}
        domain_totals[domain]["required"] += req_level
        domain_totals[domain]["acquired"] += acquired

        gap = max(0, req_level - curr_level)
        if gap > 0:
            weight = priority_weights.get(priority, 1.0)
            gaps.append({
                "skill_name": skill_name,
                "current_level": curr_level,
                "required_level": req_level,
                "gap": gap,
                "priority": priority,
                "domain": domain,
                "weighted_priority": gap * weight,
            })

    gaps.sort(key=lambda x: (x["weighted_priority"], x["gap"]), reverse=True)

    overall_pct = (
        round((total_acquired / total_required) * 100.0, 1) if total_required > 0 else 100.0
    )

    domain_scores = {}
    for dom, counts in domain_totals.items():
        r = counts["required"]
        a = counts["acquired"]
        domain_scores[dom] = round((a / r) * 100.0, 1) if r > 0 else 100.0

    return {
        "role": role_name,
        "overall_readiness_pct": overall_pct,
        "domain_scores": domain_scores,
        "gaps": gaps,
        "competency_count": len(competencies),
    }


if __name__ == "__main__":
    print("=" * 70)
    print(" PERSON 3 - MoSPI COMPETENCY MATRIX & WORKFORCE METRICS ENGINE")
    print("=" * 70)

    cm = build_competency_matrix()
    print(f"Framework: {cm['framework_name']} (v{cm['version']})")
    print(f"Roles in Matrix: {cm['roles_count']}")
    print(f"Skills in Matrix: {cm['skills_count']}\n")

    print("-" * 70)
    print("ROLE COMPETENCY MATRIX SUMMARY:")
    for role_name, data in cm["matrix"].items():
        print(f"\n* Role: {role_name}")
        print(f"  Description: {data['description']}")
        print("  Required Competencies:")
        for s_name, comp in data["competencies"].items():
            print(f"    - {s_name:<42} | Req Level: {comp['required_level']}/5 | Priority: {comp['priority'].upper()}")

    print("\n" + "-" * 70)
    print("SAMPLE EVALUATION: Statistical Officer (Baseline User)")
    sample_skills = {
        "Survey Design & Questionnaire Formulation": 3,
        "Sampling Techniques & Estimation": 2,
        "National Accounts Statistics (SNA 2008)": 1,
        "Price Statistics (CPI & WPI)": 2,
        "Python for Statistical Computing": 2,
        "Statistical Ethics & Code of Practice": 2,
    }
    eval_res = evaluate_official_against_matrix(sample_skills, "Statistical Officer")
    print(f"Overall Readiness: {eval_res['overall_readiness_pct']}%")
    print(f"Domain Scores: {eval_res['domain_scores']}")
    print("Top Skill Gaps:")
    for g in eval_res["gaps"]:
        print(f"  * {g['skill_name']}: Current {g['current_level']} -> Required {g['required_level']} (Gap: {g['gap']}, Priority: {g['priority'].upper()})")

    print("\n" + "=" * 70)
