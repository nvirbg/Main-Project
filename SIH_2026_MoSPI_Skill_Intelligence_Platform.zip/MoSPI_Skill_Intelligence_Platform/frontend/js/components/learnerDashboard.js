/**
 * Learner Dashboard Component
 * Implements Page 8 & Page 9 Hackathon specifications
 */

const LearnerDashboardComponent = (() => {
  const render = (state) => {
    const user = state.currentUser || 
      (state.learnerDashboard && state.learnerDashboard.learner) || 
      {
        name: "Karthikeya Sharma",
        designation: "Junior Statistical Officer (JSO)",
        department: "National Statistical Systems Training Academy (NSSTA)",
        role: "Statistical Officer"
      };

    const dashboard = state.learnerDashboard || {};
    const learner = dashboard.learner || {
      name: user.name || "Karthikeya Sharma",
      designation: user.designation || "Junior Statistical Officer (JSO)",
      role: user.role_name || user.role || "Statistical Officer",
      department: user.department_name || user.department || "MoSPI",
      overall_competency_pct: state.overallScore || 0,
      total_learning_hours: 0,
      courses_completed: 0
    };

    const rawName = learner.name || user.name || "Karthikeya Sharma";
    const displayName = (rawName.toLowerCase().includes("statistical officer") || rawName === "null")
      ? "Karthikeya Sharma" 
      : rawName;
    const displayDesig = learner.designation || user.designation || "Junior Statistical Officer (JSO)";
    const userDept = user.department_name || user.department || learner.department || "MoSPI Official Statistics Division";

    const criticalGaps = (dashboard.critical_gaps && dashboard.critical_gaps.length > 0)
      ? dashboard.critical_gaps
      : (state.skillGaps && state.skillGaps.length > 0)
      ? state.skillGaps
      : [];

    const recommendations = (dashboard.recommended_pathways && dashboard.recommended_pathways.length > 0)
      ? dashboard.recommended_pathways
      : (state.recommendations && state.recommendations.length > 0)
      ? state.recommendations
      : [];

    // SVG Circular Progress calculation
    const radius = 38;
    const circumference = 2 * Math.PI * radius;
    const scoreVal = learner.overall_competency_pct ?? state.overallScore ?? 0;
    const strokeDashoffset = circumference - (scoreVal / 100) * circumference;

    return `
      <section class="tab-view ${state.activeTab === 'learner' ? 'active' : ''}" id="view-learner">
        <!-- Hero Profile Header -->
        <div class="page-header">
          <div>
            <span class="gov-subtext" style="display: flex; align-items: center; gap: 6px;">
              <span>🇮🇳</span> National Statistical Systems Training Academy (NSSTA) • MoSPI
            </span>
            <h1 class="page-title" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
              Welcome, Officer ${displayName}
              <span class="card-badge" style="background: rgba(16,185,129,0.15); color: #34d399; font-size: 0.72rem; border: 1px solid rgba(16,185,129,0.3);">
                ● MoSPI Authenticated
              </span>
            </h1>
            <p class="page-subtitle">${displayDesig} • ${userDept}</p>
          </div>
          <div class="header-action-group">
            <button class="btn btn-secondary btn-sm" id="btn-quick-profiler">
              <span>🎯</span> Adjust Competency Levels
            </button>
            <button class="btn btn-primary btn-sm" id="btn-quick-quiz">
              <span>✨</span> Generate AI Quiz
            </button>
          </div>
        </div>

        <!-- Diagnostic Prompt Modal / Alert if pending -->
        ${window._pendingDiagnosticPrompt ? `
          <div id="diagnostic-onboarding-modal" style="margin-bottom: 1.5rem; background: linear-gradient(135deg, #4f46e5, #0284c7); border-radius: 14px; padding: 1.25rem 1.5rem; color: #ffffff; box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.4); display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
            <div style="max-width: 680px;">
              <div style="font-size: 1.15rem; font-weight: 800; display: flex; align-items: center; gap: 8px; margin-bottom: 0.35rem;">
                <span>✨</span> Personalized Skill Calibration Ready!
              </div>
              <p style="font-size: 0.85rem; color: #e0e7ff; line-height: 1.5; margin: 0;">
                We noted your declared starting skills. Our AI has prepared your <strong>3-minute Basic Diagnostic Quiz</strong> to calibrate your exact verified percentage, detect gaps, and generate tailored recommendations!
              </p>
            </div>
            <div style="display: flex; gap: 0.75rem; align-items: center;">
              <button class="btn" id="btn-modal-start-quiz" style="background: #ffffff; color: #4338ca; font-weight: 800; font-size: 0.875rem; padding: 0.65rem 1.25rem; box-shadow: 0 4px 12px rgba(0,0,0,0.15); border: none; cursor: pointer; border-radius: 8px;">
                <span>📝</span> Take Basic Quiz Now →
              </button>
              <button class="btn" id="btn-modal-dismiss" style="background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); color: #ffffff; font-size: 0.825rem; padding: 0.65rem 1rem; cursor: pointer; border-radius: 8px;">
                Later
              </button>
            </div>
          </div>
        ` : ''}

        <!-- Baseline Diagnostic Assessment Callout Banner (Person 1 Engine) -->
        <div class="glass-panel" id="hero-baseline-quiz-banner" style="margin-bottom: 1.5rem; padding: 1.25rem 1.5rem; background: var(--bg-surface-elevated); border: 1px solid var(--border-accent); border-radius: 14px; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap; box-shadow: var(--shadow-md);">
          <div style="max-width: 650px;">
            <div style="font-weight: 800; font-size: 1.05rem; color: var(--primary-accent); display: flex; align-items: center; gap: 8px; margin-bottom: 0.35rem;">
              <span>⚡</span> Baseline Diagnostic Quiz (AI Skill Calibration)
              <span class="card-badge" style="background: rgba(99,102,241,0.12); color: var(--primary-accent); font-size: 0.72rem; border: 1px solid rgba(99,102,241,0.3); font-weight: 700;">AI Engine</span>
            </div>
            <div style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5;">
              Calibrate your competency levels and role readiness! Our AI administers a tailored basic quiz based on your declared starting skills, calculates your exact verified percentage, identifies critical competency gaps, and generates personalized iGOT course recommendations.
            </div>
          </div>
          <button class="btn btn-primary" id="btn-take-basic-quiz" style="padding: 0.75rem 1.4rem; font-weight: 700; font-size: 0.9rem; box-shadow: var(--shadow-md); white-space: nowrap;">
            <span>📝</span> Take Basic Quiz Here →
          </button>
        </div>

        <!-- Metric Stat Cards -->
        <div class="stats-grid">
          <!-- Readiness Radial Ring -->
          <div class="glass-panel progress-ring-card">
            <div class="stat-data">
              <span class="stat-label">Role Readiness</span>
              <span class="stat-value text-indigo">${scoreVal}%</span>
              <span class="stat-subtext">Target: 85% for Promotion</span>
            </div>
            <div class="progress-ring-wrapper">
              <svg width="90" height="90" viewBox="0 0 90 90">
                <circle cx="45" cy="45" r="${radius}" stroke="rgba(255,255,255,0.08)" stroke-width="8" fill="transparent" />
                <circle cx="45" cy="45" r="${radius}" stroke="var(--primary-accent)" stroke-width="8" fill="transparent"
                  stroke-dasharray="${circumference}" stroke-dashoffset="${strokeDashoffset}" stroke-linecap="round"
                  transform="rotate(-90 45 45)" style="transition: stroke-dashoffset 0.8s ease;" />
              </svg>
              <div class="ring-text">
                <span class="ring-percentage">${scoreVal}%</span>
                <span class="ring-label">INDEX</span>
              </div>
            </div>
          </div>

          <!-- Capacity Building Hours -->
          <div class="glass-panel stat-card">
            <div class="stat-icon-wrapper stat-icon-orange">⏱️</div>
            <div class="stat-data">
              <span class="stat-label">Learning Hours</span>
              <span class="stat-value text-saffron">${learner.total_learning_hours ?? 0} hrs</span>
              <span class="stat-subtext">+6.5 hrs this month on iGOT</span>
            </div>
          </div>

          <!-- Courses Completed -->
          <div class="glass-panel stat-card">
            <div class="stat-icon-wrapper stat-icon-green">🎓</div>
            <div class="stat-data">
              <span class="stat-label">Verified Modules</span>
              <span class="stat-value text-green">${learner.courses_completed ?? 0} Completed</span>
              <span class="stat-subtext">2 Active in Progress</span>
            </div>
          </div>

          <!-- Critical Gaps Identified -->
          <div class="glass-panel stat-card">
            <div class="stat-icon-wrapper stat-icon-blue">⚠️</div>
            <div class="stat-data">
              <span class="stat-label">Identified Gaps</span>
              <span class="stat-value text-indigo">${criticalGaps.length} Skills</span>
              <span class="stat-subtext">Prioritized for immediate training</span>
            </div>
          </div>
        </div>

        <!-- 2-Column Dashboard Grid -->
        <div class="dashboard-grid">
          <!-- Critical Skill Gaps Column -->
          <div class="glass-panel" style="padding: 1.5rem;">
            <div class="card-header">
              <h2 class="card-title">
                <span>⚠️</span> Critical Competency Gaps
              </h2>
              <span class="card-badge">Target Role: ${learner.role || 'Statistical Officer'}</span>
            </div>
            <p style="font-size: 0.825rem; color: var(--text-muted); margin-bottom: 1.25rem;">
              Calculated using weighted gap analysis: <code style="color:var(--saffron);">Gap = Required - Current Level</code>
            </p>

            <div class="gap-list">
              ${criticalGaps.map(g => `
                <div class="gap-item">
                  <div class="gap-info">
                    <div class="gap-title">
                      ${g.skill_name}
                      <span class="priority-chip priority-${g.priority.toLowerCase()}">${g.priority}</span>
                    </div>
                    <div class="gap-levels">
                      <span>Current: <strong class="level-badge">${g.current_level}/5</strong></span>
                      <span>•</span>
                      <span>Required: <strong class="level-badge" style="color:var(--saffron);">${g.required_level}/5</strong></span>
                      <span>•</span>
                      <span style="color:#ef4444;">Gap: -${g.gap}</span>
                    </div>
                  </div>
                  <button class="btn btn-secondary btn-sm btn-practice-gap" data-skill="${g.skill_name}">
                    <span>✨</span> Assess
                  </button>
                </div>
              `).join('')}
            </div>

            <div style="margin-top: 1.5rem; text-align: center;">
              <button class="btn btn-secondary btn-sm" id="btn-view-all-skills" style="width: 100%;">
                View All Competencies in 4-Domain Framework →
              </button>
            </div>
          </div>

          <!-- Personalized iGOT Karmayogi Learning Pathways -->
          <div class="glass-panel" style="padding: 1.5rem;">
            <div class="card-header">
              <h2 class="card-title">
                <span>🎯</span> Recommended iGOT Pathways
              </h2>
              <span class="card-badge" style="background: rgba(99,102,241,0.15); color: #c7d2fe; border-color: rgba(99,102,241,0.3);">
                AI Ranked
              </span>
            </div>
            <p style="font-size: 0.825rem; color: var(--text-muted); margin-bottom: 1.25rem;">
              Ranked using TF-IDF semantic alignment & NSSTA Training Programme Advisory Committee (TPAC) priorities.
            </p>

            <div style="display: flex; flex-direction: column; gap: 1rem;">
              ${recommendations.map(r => `
                <div class="glass-card" style="padding: 1rem 1.25rem;">
                  <div class="course-tags">
                    ${r.is_tpac_recommended ? '<span class="tag-tpac">NSSTA TPAC Priority</span>' : ''}
                    <span class="tag-igot">${r.provider || 'iGOT Karmayogi'}</span>
                    <span class="card-badge" style="text-transform: capitalize;">${r.level || 'Intermediate'}</span>
                  </div>
                  <h3 class="course-title" style="font-size: 0.95rem;">${r.title}</h3>
                  <div class="reason-box">
                    <strong>Why Recommended:</strong> ${r.reason}
                  </div>
                  <div class="course-footer">
                    <span style="font-size: 0.775rem; color: var(--text-muted);">
                      ⏱️ ${r.duration_hours} Hours • Match: <strong style="color:var(--success);">${Math.round((r.score || 0.85) * 100)}%</strong>
                    </span>
                    <button class="btn btn-primary btn-sm btn-enroll-course" data-id="${r.course_id}">
                      <span>🚀</span> Enroll on iGOT
                    </button>
                  </div>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </section>
    `;
  };

  const bindEvents = () => {
    // Diagnostic Onboarding Modal Prompt
    const btnModalStart = document.getElementById("btn-modal-start-quiz");
    if (btnModalStart) {
      btnModalStart.addEventListener("click", () => {
        window._pendingDiagnosticPrompt = false;
        const modal = document.getElementById("diagnostic-onboarding-modal");
        if (modal) modal.style.display = "none";
        if (window.QuizComponent && window.QuizComponent.startBasicDiagnosticQuiz) {
          window.QuizComponent.startBasicDiagnosticQuiz();
        }
      });
    }

    const btnModalDismiss = document.getElementById("btn-modal-dismiss");
    if (btnModalDismiss) {
      btnModalDismiss.addEventListener("click", () => {
        window._pendingDiagnosticPrompt = false;
        const modal = document.getElementById("diagnostic-onboarding-modal");
        if (modal) modal.style.display = "none";
      });
    }

    // Baseline Diagnostic Quiz Callout
    const btnTakeBasic = document.getElementById("btn-take-basic-quiz");
    if (btnTakeBasic) {
      btnTakeBasic.addEventListener("click", () => {
        if (window.QuizComponent && window.QuizComponent.startBasicDiagnosticQuiz) {
          window.QuizComponent.startBasicDiagnosticQuiz();
        } else {
          store.setState({ activeTab: "quiz" });
        }
      });
    }

    // Quick action buttons
    const btnProfiler = document.getElementById("btn-quick-profiler");
    if (btnProfiler) {
      btnProfiler.addEventListener("click", () => store.setState({ activeTab: "skill-gap" }));
    }

    const btnQuiz = document.getElementById("btn-quick-quiz");
    if (btnQuiz) {
      btnQuiz.addEventListener("click", () => store.setState({ activeTab: "quiz" }));
    }

    const btnViewAllSkills = document.getElementById("btn-view-all-skills");
    if (btnViewAllSkills) {
      btnViewAllSkills.addEventListener("click", () => store.setState({ activeTab: "skill-gap" }));
    }

    // Direct practice gap button
    document.querySelectorAll(".btn-practice-gap").forEach(btn => {
      btn.addEventListener("click", () => {
        const skill = btn.getAttribute("data-skill");
        store.setState({ activeTab: "quiz" });
        store.showToast(`Loading assessment generator for: ${skill}`, "info");
      });
    });

    // Enroll on iGOT simulator
    document.querySelectorAll(".btn-enroll-course").forEach(btn => {
      btn.addEventListener("click", () => {
        const courseId = btn.getAttribute("data-id");
        btn.textContent = "✓ Enrolled on iGOT";
        btn.classList.remove("btn-primary");
        btn.classList.add("btn-secondary");
        store.showToast("Successfully enrolled via iGOT Karmayogi adapter interface!", "success");
      });
    });
  };

  return { render, bindEvents };
})();

window.LearnerDashboardComponent = LearnerDashboardComponent;
