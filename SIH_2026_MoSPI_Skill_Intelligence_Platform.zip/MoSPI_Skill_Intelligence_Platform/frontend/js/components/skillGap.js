/**
 * Skill Gap & Competency Profiler Component
 * Implements Page 2 & Page 9 Hackathon specifications:
 * Dynamic competency sliders with 0-5 scale, real-time MySQL persistence,
 * and automatic synchronization with Learner Dashboard.
 */

const SkillGapComponent = (() => {
  // Baseline competency data structured across the 4 domains matching MySQL skills.id
  // All initial levels start at 0 (unskilled/fresh) unless loaded from user's MySQL records.
  const defaultSkills = [
    // 1. Statistical Competencies
    { id: 2, domain: "Statistical Competencies", name: "Sampling Techniques & Estimation", current: 0, required: 4, priority: "critical" },
    { id: 1, domain: "Statistical Competencies", name: "Survey Design & Questionnaire Formulation", current: 0, required: 4, priority: "high" },
    { id: 3, domain: "Statistical Competencies", name: "National Accounts Statistics (SNA 2008)", current: 0, required: 3, priority: "high" },
    { id: 4, domain: "Statistical Competencies", name: "Price Statistics (CPI & WPI)", current: 0, required: 3, priority: "medium" },
    { id: 10, domain: "Statistical Competencies", name: "Data Quality Assurance Frameworks", current: 0, required: 3, priority: "medium" },
    
    // 2. Technical Competencies
    { id: 11, domain: "Technical Competencies", name: "Python for Statistical Computing", current: 0, required: 3, priority: "high" },
    { id: 12, domain: "Technical Competencies", name: "R Programming & R-Studio", current: 0, required: 2, priority: "medium" },
    { id: 13, domain: "Technical Competencies", name: "SQL & Relational Databases", current: 0, required: 3, priority: "medium" },
    { id: 17, domain: "Technical Competencies", name: "GIS & Spatial Data Analysis (QGIS)", current: 0, required: 2, priority: "medium" },
    { id: 18, domain: "Technical Competencies", name: "Data Visualization & Power BI / Tableau", current: 0, required: 3, priority: "medium" },

    // 3. Digital Governance
    { id: 23, domain: "Digital Governance", name: "Data Privacy & DPDP Act 2023", current: 0, required: 3, priority: "medium" },
    { id: 22, domain: "Digital Governance", name: "Cybersecurity & CERT-In Guidelines", current: 0, required: 3, priority: "high" },
    { id: 24, domain: "Digital Governance", name: "Digital Signatures & e-Office Operations", current: 0, required: 4, priority: "low" },

    // 4. Behavioural & Managerial
    { id: 30, domain: "Behavioural & Managerial Competencies", name: "Statistical Ethics & Code of Practice", current: 0, required: 4, priority: "high" },
    { id: 27, domain: "Behavioural & Managerial Competencies", name: "Leadership & Team Management", current: 0, required: 3, priority: "medium" },
    { id: 28, domain: "Behavioural & Managerial Competencies", name: "Communication & Statistical Dissemination", current: 0, required: 3, priority: "medium" }
  ];

  let currentSkills = defaultSkills.map(s => ({ ...s }));

  const syncWithUserState = (state) => {
    // 1. Sync from learnerDashboard skills if available from MySQL
    const backendSkills = state.learnerDashboard?.learner?.skills || [];
    if (backendSkills.length > 0) {
      const bMap = {};
      backendSkills.forEach(b => {
        if (b.skill_id) bMap[b.skill_id] = b.level;
        if (b.skill_name) bMap[b.skill_name.toLowerCase()] = b.level;
      });

      currentSkills.forEach(s => {
        if (bMap[s.id] !== undefined) {
          s.current = bMap[s.id];
        } else if (bMap[s.name.toLowerCase()] !== undefined) {
          s.current = bMap[s.name.toLowerCase()];
        }
      });
      return;
    }

    // 2. Sync from skillGaps if available
    const gaps = state.skillGaps || [];
    if (gaps.length > 0) {
      const gMap = {};
      gaps.forEach(g => {
        if (g.skill_id) gMap[g.skill_id] = g.current_level;
        if (g.skill_name) gMap[g.skill_name.toLowerCase()] = g.current_level;
      });
      currentSkills.forEach(s => {
        if (gMap[s.id] !== undefined) {
          s.current = gMap[s.id];
        } else if (gMap[s.name.toLowerCase()] !== undefined) {
          s.current = gMap[s.name.toLowerCase()];
        }
      });
    }
  };

  const calculateOverallScore = () => {
    let totalReq = 0;
    let totalAcq = 0;
    currentSkills.forEach(s => {
      totalReq += s.required;
      totalAcq += Math.min(s.current, s.required);
    });
    return totalReq > 0 ? Math.round((totalAcq / totalReq) * 100) : 0;
  };

  const render = (state) => {
    syncWithUserState(state);
    const overallScore = calculateOverallScore();
    const user = state.currentUser || 
      (state.learnerDashboard && state.learnerDashboard.learner) || 
      { name: "Karthikeya Sharma", role: "Statistical Officer", role_name: "Statistical Officer" };
    const displayName = (user.name && user.name.toLowerCase() !== "statistical officer") ? user.name : "Karthikeya Sharma";

    // Group by Domain
    const domains = [
      "Statistical Competencies",
      "Technical Competencies",
      "Digital Governance",
      "Behavioural & Managerial Competencies"
    ];

    return `
      <section class="tab-view ${state.activeTab === 'skill-gap' ? 'active' : ''}" id="view-skill-gap">
        <div class="page-header">
          <div>
            <span class="gov-subtext">Competency Framework Engine • National Statistical Systems</span>
            <h1 class="page-title">Competency Profiler & Skill-Gap Analysis</h1>
            <p class="page-subtitle">Official: <strong>Officer ${displayName}</strong> • Target Role: <strong>${user.role_name || user.role || 'Statistical Officer'}</strong></p>
          </div>
          <div class="header-action-group">
            <button class="btn btn-primary btn-sm" id="btn-recalculate-engine">
              <span>🔄</span> Recalculate Recommendation Engine
            </button>
          </div>
        </div>

        <!-- Live Demo Highlight Banner -->
        <div class="glass-panel" style="padding: 1.25rem 1.5rem; margin-bottom: 2rem; border-color: rgba(99,102,241,0.4); background: linear-gradient(135deg, rgba(99,102,241,0.12), rgba(59,130,246,0.06));">
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem;">
            <div>
              <div style="font-weight: 800; font-size: 1rem; color: #c7d2fe; display: flex; align-items: center; gap: 0.5rem;">
                <span>💡</span> Live Skill-Gap Sensitivity Test (0-5 Scale)
              </div>
              <p style="font-size: 0.825rem; color: var(--text-secondary); margin-top: 0.25rem;">
                Adjust any competency slider below from <strong>0 (Unskilled)</strong> to <strong>5 (Expert)</strong>.
                Notice how the Overall Readiness Index and ranked priority gaps recalculate dynamically and persist to MySQL!
              </p>
            </div>
            <div style="display: flex; align-items: center; gap: 1rem;">
              <div style="text-align: right; background: rgba(0,0,0,0.25); padding: 0.5rem 1rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.08);">
                <div style="font-size: 0.72rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em;">Live Readiness</div>
                <div style="font-size: 1.65rem; font-weight: 900; color: ${overallScore >= 70 ? 'var(--success)' : overallScore >= 40 ? 'var(--saffron)' : '#ef4444'};" id="live-readiness-label">${overallScore}%</div>
              </div>
            </div>
          </div>
        </div>

        <!-- 4-Domain Competency Matrix -->
        <div class="glass-panel" style="padding: 1.75rem;">
          <div class="card-header">
            <h2 class="card-title"><span>📊</span> 4-Domain Competency Matrix & Gap Sliders</h2>
            <span class="card-badge" style="background: rgba(99,102,241,0.2); color: #a5b4fc; border: 1px solid rgba(99,102,241,0.4);">
              Scale: 0 (Novice / Unskilled) → 5 (Expert)
            </span>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
            ${domains.map((domName, domIdx) => {
              const domSkills = currentSkills.filter(s => s.domain === domName);
              const icons = ["📈", "💻", "🛡️", "🤝"];
              return `
                <div class="competency-domain-group">
                  <h3 class="domain-group-title">
                    <span>${icons[domIdx]}</span> ${domName}
                  </h3>
                  <div style="display: flex; flex-direction: column; gap: 0.65rem;">
                    ${domSkills.map(s => {
                      const hasGap = s.required > s.current;
                      const gapAmt = s.required - s.current;
                      return `
                        <div class="skill-adjuster-row">
                          <div class="skill-name-col">
                            <span style="font-weight: 600;">${s.name}</span>
                            ${hasGap 
                              ? `<span class="gap-tag-pill" id="gap-tag-${s.id}" style="font-size:0.7rem; color:#ef4444; background: rgba(239,68,68,0.12); padding: 2px 6px; border-radius: 4px; margin-left:6px;">Gap -${gapAmt}</span>` 
                              : `<span class="gap-tag-pill" id="gap-tag-${s.id}" style="font-size:0.7rem; color:#10b981; background: rgba(16,185,129,0.12); padding: 2px 6px; border-radius: 4px; margin-left:6px;">Target Met ✓</span>`}
                          </div>
                          <div class="skill-slider-col">
                            <input type="range" class="skill-slider" data-skill-id="${s.id}" min="0" max="5" value="${s.current}" />
                          </div>
                          <div class="skill-level-display" id="skill-display-${s.id}">
                            <span class="curr-val" style="font-weight:700; color: ${s.current === 0 ? '#94a3b8' : s.current >= s.required ? '#10b981' : '#f59e0b'};">${s.current}</span> / <span style="color:var(--saffron);">${s.required}</span>
                          </div>
                        </div>
                      `;
                    }).join('')}
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      </section>
    `;
  };

  const bindEvents = () => {
    // Slider Change listener
    document.querySelectorAll(".skill-slider").forEach(slider => {
      slider.addEventListener("input", (e) => {
        const skillId = parseInt(e.target.getAttribute("data-skill-id"), 10);
        const newVal = parseInt(e.target.value, 10);

        const skillObj = currentSkills.find(s => s.id === skillId);
        if (skillObj) {
          skillObj.current = newVal;
          const display = document.getElementById(`skill-display-${skillId}`);
          if (display) {
            display.innerHTML = `<span class="curr-val" style="font-weight:700; color: ${newVal === 0 ? '#94a3b8' : newVal >= skillObj.required ? '#10b981' : '#f59e0b'};">${newVal}</span> / <span style="color:var(--saffron);">${skillObj.required}</span>`;
          }

          // Update Gap Tag Pill
          const gapTag = document.getElementById(`gap-tag-${skillId}`);
          if (gapTag) {
            if (newVal < skillObj.required) {
              gapTag.textContent = `Gap -${skillObj.required - newVal}`;
              gapTag.style.color = "#ef4444";
              gapTag.style.background = "rgba(239,68,68,0.12)";
            } else {
              gapTag.textContent = "Target Met ✓";
              gapTag.style.color = "#10b981";
              gapTag.style.background = "rgba(16,185,129,0.12)";
            }
          }

          // Update live readiness
          const newScore = calculateOverallScore();
          const liveLabel = document.getElementById("live-readiness-label");
          if (liveLabel) {
            liveLabel.textContent = `${newScore}%`;
            liveLabel.style.color = newScore >= 70 ? 'var(--success)' : newScore >= 40 ? 'var(--saffron)' : '#ef4444';
          }
          store.setState({ overallScore: newScore });

          // Call backend API to persist to MySQL
          API.updateCompetency(skillId, newVal).catch(() => {});
        }
      });

      slider.addEventListener("change", async (e) => {
        const skillId = parseInt(e.target.getAttribute("data-skill-id"), 10);
        const skillObj = currentSkills.find(s => s.id === skillId);
        if (skillObj) {
          store.showToast(`Updated ${skillObj.name} to ${skillObj.current}/5 in MySQL. Recalculating recommendations...`, "success");
          await API.updateCompetency(skillId, skillObj.current).catch(() => {});
          await refreshBackendData();
        }
      });
    });

    // Recalculate button
    const btnRecalc = document.getElementById("btn-recalculate-engine");
    if (btnRecalc) {
      btnRecalc.addEventListener("click", async () => {
        store.showToast("Skill-Gap Engine & iGOT Recommendation Weights Recalculated!", "info");
        await refreshBackendData();
        store.setState({ activeTab: "learner" });
      });
    }
  };

  return { render, bindEvents };
})();

window.SkillGapComponent = SkillGapComponent;
