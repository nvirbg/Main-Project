/**
 * Security & RBAC Architecture Modal
 * Implements Person 4 (Cybersecurity Lead) & Page 5 / Page 10 Specifications
 */

const SecurityModal = (() => {
  const auditLogs = [
    { timestamp: "2026-09-06 01:42:15", action: "LOGIN", user: "karthikeya@mospi.gov.in", role: "OFFICIAL", details: "JWT Token Issued (HS256)" },
    { timestamp: "2026-09-06 01:45:30", action: "COMPETENCY_UPDATE", user: "karthikeya@mospi.gov.in", role: "OFFICIAL", details: "Skill: Python from 2/5 -> 3/5" },
    { timestamp: "2026-09-06 01:48:10", action: "QUIZ_GENERATION", user: "karthikeya@mospi.gov.in", role: "OFFICIAL", details: "Document: NSSO Sampling Manual (4 MCQs)" },
    { timestamp: "2026-09-06 01:50:22", action: "ADMIN_DASHBOARD_ACCESS", user: "admin@nssta.gov.in", role: "ADMIN", details: "Org Analytics Query via require_roles('admin')" }
  ];

  const render = () => {
    return `
      <div id="security-modal-overlay" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); backdrop-filter: blur(8px); z-index: 2000; align-items: center; justify-content: center; padding: 1rem;">
        <div class="glass-panel" style="max-width: 800px; width: 100%; max-height: 90vh; overflow-y: auto; padding: 2rem; border-color: var(--border-accent);">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; border-bottom: 1px solid var(--border-subtle); padding-bottom: 0.75rem;">
            <div style="display: flex; align-items: center; gap: 0.75rem;">
              <span style="font-size: 1.5rem;">🛡️</span>
              <div>
                <h2 style="font-size: 1.25rem;">Government-Grade Security & RBAC Architecture</h2>
                <span class="gov-subtext" style="color: var(--saffron);">Person 4 — Cybersecurity Lead Specification</span>
              </div>
            </div>
            <button class="btn-icon" id="btn-close-security-modal">✕</button>
          </div>

          <!-- Architecture Pillars -->
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
            <div class="glass-card">
              <div style="font-weight: 700; color: #818cf8; margin-bottom: 0.25rem;">🔐 JWT Token Security</div>
              <p style="font-size: 0.8rem; color: var(--text-secondary); line-height: 1.4;">
                Cryptographic HMAC-SHA256 signature with short-lived access tokens (30m) and rotating refresh tokens (7d). Secrets stored strictly in <code>.env</code>.
              </p>
            </div>
            <div class="glass-card">
              <div style="font-weight: 700; color: #34d399; margin-bottom: 0.25rem;">👥 Role-Based Access Control (RBAC)</div>
              <p style="font-size: 0.8rem; color: var(--text-secondary); line-height: 1.4;">
                Strict route-level authorization via FastAPI dependencies: <code>require_roles("admin")</code> and <code>get_current_official</code>. Officials cannot invoke admin endpoints.
              </p>
            </div>
            <div class="glass-card">
              <div style="font-weight: 700; color: #fb923c; margin-bottom: 0.25rem;">📁 Input Sanitization & Anti-Injection</div>
              <p style="font-size: 0.8rem; color: var(--text-secondary); line-height: 1.4;">
                Strict MIME-type verification (PDF, DOCX, TXT) and 25MB buffer thresholds to prevent buffer overrun and malicious execution during assessment parsing.
              </p>
            </div>
            <div class="glass-card">
              <div style="font-weight: 700; color: #38bdf8; margin-bottom: 0.25rem;">📜 Tamper-Proof Audit Logging</div>
              <p style="font-size: 0.8rem; color: var(--text-secondary); line-height: 1.4;">
                Every authentication attempt, competency modification, document parsing, and administrative action is logged to immutable database audit records.
              </p>
            </div>
          </div>

          <!-- Live Audit Log Stream -->
          <h3 style="font-size: 0.95rem; margin-bottom: 0.75rem; display: flex; align-items: center; gap: 0.5rem;">
            <span>📜</span> Recent Security Audit Stream:
          </h3>
          <div style="background: var(--bg-secondary); border: 1px solid var(--border-default); border-radius: 10px; overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; font-size: 0.775rem; text-align: left;">
              <thead>
                <tr style="border-bottom: 1px solid var(--border-subtle); color: var(--text-muted); background: var(--bg-surface);">
                  <th style="padding: 8px 12px;">Timestamp</th>
                  <th style="padding: 8px 12px;">Action</th>
                  <th style="padding: 8px 12px;">User</th>
                  <th style="padding: 8px 12px;">Role</th>
                  <th style="padding: 8px 12px;">Details</th>
                </tr>
              </thead>
              <tbody>
                ${auditLogs.map(log => `
                  <tr style="border-bottom: 1px solid rgba(255,255,255,0.04);">
                    <td style="padding: 8px 12px; font-family: var(--font-mono);">${log.timestamp}</td>
                    <td style="padding: 8px 12px;"><span class="source-badge" style="color:var(--primary-accent);">${log.action}</span></td>
                    <td style="padding: 8px 12px;">${log.user}</td>
                    <td style="padding: 8px 12px;"><strong>${log.role}</strong></td>
                    <td style="padding: 8px 12px; color: var(--text-secondary);">${log.details}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>

          <div style="margin-top: 1.5rem; text-align: right;">
            <button class="btn btn-primary btn-sm" id="btn-modal-close-action">
              Done / Close Inspector
            </button>
          </div>
        </div>
      </div>
    `;
  };

  const show = () => {
    const overlay = document.getElementById("security-modal-overlay");
    if (overlay) overlay.style.display = "flex";
  };

  const hide = () => {
    const overlay = document.getElementById("security-modal-overlay");
    if (overlay) overlay.style.display = "none";
  };

  const bindEvents = () => {
    const btnClose = document.getElementById("btn-close-security-modal");
    const btnAction = document.getElementById("btn-modal-close-action");
    if (btnClose) btnClose.addEventListener("click", hide);
    if (btnAction) btnAction.addEventListener("click", hide);
  };

  return { render, show, hide, bindEvents };
})();

window.SecurityModal = SecurityModal;
window.showSecurityModal = SecurityModal.show;
