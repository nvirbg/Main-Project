/**
 * iGOT Karmayogi Course Catalogue Component
 * Implements Page 6, 7 & 10 Hackathon specifications
 */

const CoursesComponent = (() => {
  let activeFilter = "all";
  let searchQuery = "";

  const defaultCatalog = [
    {
      id: 1,
      igot_course_id: "IGOT-STAT-001",
      title: "Modern Survey Sampling and Estimation Techniques",
      description: "Stratified multistage sampling, cluster design, and weights calibration for official statistical surveys like NSSO and PLFS.",
      provider: "iGOT Karmayogi",
      duration_hours: 18.5,
      level: "intermediate",
      category: "statistical",
      is_tpac_recommended: true,
      skills: ["Sampling Techniques & Estimation", "Survey Design & Questionnaire Formulation"]
    },
    {
      id: 2,
      igot_course_id: "IGOT-STAT-002",
      title: "National Accounts Statistics & GDP Estimation (SNA 2008)",
      description: "System of National Accounts (SNA 2008), sequence of accounts, Gross Value Added (GVA), and sector balance sheets.",
      provider: "NSSTA / MoSPI",
      duration_hours: 24.0,
      level: "advanced",
      category: "statistical",
      is_tpac_recommended: true,
      skills: ["National Accounts Statistics (SNA 2008)", "Industrial Statistics (IIP & ASI)"]
    },
    {
      id: 3,
      igot_course_id: "IGOT-TECH-001",
      title: "Python for Official Statistics & Microdata Analysis",
      description: "Hands-on data cleaning, tabulation, and automated report generation for large sample survey microdata using Pandas and SciPy.",
      provider: "iGOT Karmayogi",
      duration_hours: 30.0,
      level: "beginner",
      category: "technical",
      is_tpac_recommended: true,
      skills: ["Python for Statistical Computing", "Data Visualization & Power BI / Tableau"]
    },
    {
      id: 4,
      igot_course_id: "IGOT-TECH-002",
      title: "Applied Econometrics & Survey Analysis using R & Stata",
      description: "Survey-weighted regressions, instrumental variables, and impact evaluation using R and Stata for policy research.",
      provider: "NSSTA",
      duration_hours: 22.0,
      level: "intermediate",
      category: "technical",
      is_tpac_recommended: true,
      skills: ["R Programming & R-Studio", "Stata for Econometrics & Surveys"]
    },
    {
      id: 5,
      igot_course_id: "IGOT-GOV-001",
      title: "Data Privacy, DPDP Act 2023 & Cybersecurity in Government",
      description: "Digital Personal Data Protection Act, secure data handling, CERT-In compliance, and citizen data safeguards.",
      provider: "iGOT Karmayogi",
      duration_hours: 8.0,
      level: "beginner",
      category: "digital_governance",
      is_tpac_recommended: false,
      skills: ["Data Privacy & DPDP Act 2023", "Cybersecurity & CERT-In Guidelines"]
    },
    {
      id: 6,
      igot_course_id: "IGOT-MGT-001",
      title: "Statistical Ethics, Leadership & Field Survey Management",
      description: "UN Fundamental Principles of Official Statistics, managing field enumerators, conflict resolution, and quality inspection.",
      provider: "NSSTA",
      duration_hours: 12.0,
      level: "intermediate",
      category: "behavioural",
      is_tpac_recommended: true,
      skills: ["Statistical Ethics & Code of Practice", "Leadership & Team Management", "Project Management"]
    }
  ];

  const render = (state) => {
    let courses = (state.courses && state.courses.length > 0) ? state.courses : defaultCatalog;
    if (activeFilter !== "all") {
      if (activeFilter === "tpac") {
        courses = courses.filter(c => c.is_tpac_recommended);
      } else {
        courses = courses.filter(c => c.category === activeFilter);
      }
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      courses = courses.filter(c => c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q));
    }

    return `
      <section class="tab-view ${state.activeTab === 'courses' ? 'active' : ''}" id="view-courses">
        <div class="page-header">
          <div>
            <span class="gov-subtext">Integrated Karmayogi Bharat Ecosystem</span>
            <h1 class="page-title">iGOT Karmayogi & NSSTA Course Catalogue</h1>
            <p class="page-subtitle">Verified capacity-building programmes aligned with India's Official Statistics Competency Framework.</p>
          </div>
          <div class="header-action-group">
            <span class="card-badge" style="background: rgba(16,185,129,0.15); color: #6ee7b7; border-color: rgba(16,185,129,0.3);">
              ✓ iGOT Adapter: API-Ready
            </span>
          </div>
        </div>

        <!-- Filters & Search Toolbar -->
        <div class="glass-panel" style="padding: 1.25rem 1.5rem; margin-bottom: 2rem;">
          <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
            <!-- Category Pills -->
            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
              <button class="sample-pill ${activeFilter === 'all' ? 'active' : ''}" data-filter="all">All Modules</button>
              <button class="sample-pill ${activeFilter === 'tpac' ? 'active' : ''}" data-filter="tpac">★ NSSTA TPAC Priority</button>
              <button class="sample-pill ${activeFilter === 'statistical' ? 'active' : ''}" data-filter="statistical">Statistical Methods</button>
              <button class="sample-pill ${activeFilter === 'technical' ? 'active' : ''}" data-filter="technical">Data Science & Python</button>
              <button class="sample-pill ${activeFilter === 'digital_governance' ? 'active' : ''}" data-filter="digital_governance">Digital Governance</button>
              <button class="sample-pill ${activeFilter === 'behavioural' ? 'active' : ''}" data-filter="behavioural">Leadership & Ethics</button>
            </div>

            <!-- Search Box -->
            <div style="width: 260px;">
              <input type="text" id="course-search-input" placeholder="Search title or skills..." value="${searchQuery}" 
                style="width: 100%; background: var(--bg-secondary); border: 1px solid var(--border-default); border-radius: 8px; padding: 0.5rem 0.75rem; color: var(--text-primary); font-size: 0.85rem; outline: none;" />
            </div>
          </div>
        </div>

        <!-- Course Cards Grid -->
        <div class="course-grid">
          ${courses.map(c => `
            <div class="glass-panel course-card" style="padding: 1.5rem;">
              <div class="course-header">
                <div class="course-tags">
                  ${c.is_tpac_recommended ? '<span class="tag-tpac">NSSTA TPAC Priority</span>' : ''}
                  <span class="tag-igot">${c.provider}</span>
                  <span class="card-badge" style="text-transform: capitalize;">${c.level}</span>
                </div>
                <h3 class="course-title">${c.title}</h3>
                <p style="font-size: 0.825rem; color: var(--text-secondary); margin-bottom: 0.75rem; line-height: 1.45;">
                  ${c.description}
                </p>
                <div class="course-meta">
                  <span>⏱️ ${c.duration_hours} hrs</span>
                  <span>•</span>
                  <span>ID: <code>${c.igot_course_id}</code></span>
                </div>
                <div style="display: flex; flex-wrap: wrap; gap: 0.35rem; margin-bottom: 1rem;">
                  ${(c.skills || []).map(s => `<span class="source-badge">${s}</span>`).join('')}
                </div>
              </div>
              <div class="course-footer">
                <button class="btn btn-secondary btn-sm btn-view-syllabus" data-course-id="${c.id}">
                  Syllabus Details
                </button>
                <button class="btn btn-primary btn-sm btn-enroll-catalog" data-course-id="${c.id}">
                  <span>🚀</span> Enroll on iGOT
                </button>
              </div>
            </div>
          `).join('')}
        </div>
      </section>
    `;
  };

  const bindEvents = () => {
    // Filter click
    document.querySelectorAll("[data-filter]").forEach(btn => {
      btn.addEventListener("click", () => {
        activeFilter = btn.getAttribute("data-filter");
        renderApp();
      });
    });

    // Search input
    const searchInput = document.getElementById("course-search-input");
    if (searchInput) {
      searchInput.addEventListener("input", (e) => {
        searchQuery = e.target.value;
        renderApp();
      });
    }

    // Enroll buttons
    document.querySelectorAll(".btn-enroll-catalog").forEach(btn => {
      btn.addEventListener("click", () => {
        btn.textContent = "✓ Enrolled";
        btn.classList.remove("btn-primary");
        btn.classList.add("btn-secondary");
        store.showToast("Successfully enrolled via iGOT Karmayogi API adapter!", "success");
      });
    });

    // View syllabus buttons
    document.querySelectorAll(".btn-view-syllabus").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = parseInt(btn.getAttribute("data-course-id"), 10);
        const course = defaultCatalog.find(c => c.id === id);
        if (course) {
          alert(`Course: ${course.title}\nProvider: ${course.provider}\nDuration: ${course.duration_hours} Hours\n\nCurriculum Outline:\n- Module 1: Foundational Framework & Methodology\n- Module 2: Field Implementations and Data Collection\n- Module 3: Statistical Quality Checks & Verification\n- Module 4: Dissemination and Policy Case Studies`);
        }
      });
    });
  };

  return { render, bindEvents };
})();

window.CoursesComponent = CoursesComponent;
