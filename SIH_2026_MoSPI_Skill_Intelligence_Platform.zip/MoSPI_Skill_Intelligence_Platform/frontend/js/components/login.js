/**
 * AI-Enabled Skill Intelligence & Learning Platform
 * Login + Registration Component — MoSPI / NSSTA / iGOT Karmayogi
 * 
 * 3 login/registration categories:
 *   1. Statistical Officer (JSO / SSO — field + data collection roles)
 *   2. Data Analyst (Assistant Director — analytics & research roles)
 *   3. Administrator (NSSTA Admin — system management)
 * All registrations are stored in SQLite via FastAPI /auth/register endpoint.
 */

const LoginComponent = (() => {

  // ---------------------------------------------------------------- CONFIG --
  const CATEGORIES = [
    {
      key: "statistical_officer",
      label: "Statistical Officer",
      icon: "📊",
      color: "#818cf8",
      gradient: "linear-gradient(135deg, #818cf8, #6366f1)",
      description: "JSO / SSO — Survey, Census & Data Collection",
      defaultDesignation: "Junior Statistical Officer (JSO)",
      roleName: "Statistical Officer",
      fields: ["employee_code", "name", "email", "password", "designation", "department_name", "qualification", "work_experience_years"]
    },
    {
      key: "data_analyst",
      label: "Data Analyst",
      icon: "💻",
      color: "#38bdf8",
      gradient: "linear-gradient(135deg, #38bdf8, #0ea5e9)",
      description: "Asst. Director — Analytics, ML & Research",
      defaultDesignation: "Assistant Director / Data Analyst",
      roleName: "Data Analyst",
      fields: ["employee_code", "name", "email", "password", "designation", "department_name", "qualification", "work_experience_years"]
    },
    {
      key: "admin",
      label: "Administrator",
      icon: "🛡️",
      color: "#f97316",
      gradient: "linear-gradient(135deg, #f97316, #ea580c)",
      description: "NSSTA Admin — Platform & Academy Management",
      defaultDesignation: "Head of Academy / System Administrator",
      roleName: "admin",
      fields: ["employee_code", "name", "email", "password", "designation", "department_name", "qualification", "work_experience_years"]
    }
  ];

  const DEPARTMENTS = [
    "National Statistical Systems Training Academy (NSSTA)",
    "MoSPI - Data Informatics & Innovation Division (DIID)",
    "MoSPI - National Accounts Division (NAD)",
    "MoSPI - Prices & Cost of Living Division",
    "MoSPI - Agriculture Statistics Division",
    "MoSPI - Social Statistics Division",
    "MoSPI - Industrial Statistics Wing",
    "Central Statistical Office (CSO)",
    "Office of the Registrar General of India (ORGI)",
    "State DES - Maharashtra",
    "State DES - Karnataka",
    "State DES - Tamil Nadu",
    "State DES - Uttar Pradesh"
  ];

  const INITIAL_REG_SKILLS = [
    { id: 2, name: "Sampling Techniques & Estimation", domain: "Statistical" },
    { id: 1, name: "Survey Design & Questionnaire Formulation", domain: "Statistical" },
    { id: 3, name: "National Accounts Statistics (SNA 2008)", domain: "Statistical" },
    { id: 11, name: "Python for Statistical Computing", domain: "Technical" },
    { id: 13, name: "SQL & Relational Databases", domain: "Technical" },
    { id: 18, name: "Data Visualization & Power BI / Tableau", domain: "Technical" },
    { id: 23, name: "Data Privacy & DPDP Act 2023", domain: "Governance" },
    { id: 30, name: "Statistical Ethics & Code of Practice", domain: "Behavioural" }
  ];

  // ----------------------------------------------------------------- STATE --
  let _mode = "login";         // "login" | "register"
  let _category = "statistical_officer";
  let _regCategory = "statistical_officer";

  // ---------------------------------------------------------------- RENDER --
  const render = (state) => {
    const cat = CATEGORIES.find(c => c.key === _category) || CATEGORIES[0];
    const regCat = CATEGORIES.find(c => c.key === _regCategory) || CATEGORIES[0];
    return `
      <div class="auth-page-wrapper">
        <!-- Gov Tricolor Strip -->
        <div class="gov-tricolor-strip"></div>

        <!-- Background Particles -->
        <div class="auth-bg-particles">
          <div class="particle p1"></div>
          <div class="particle p2"></div>
          <div class="particle p3"></div>
          <div class="particle p4"></div>
        </div>

        <!-- Left Branding Panel -->
        <div class="auth-branding-panel">
          <div class="auth-brand-content">
            <div class="auth-emblem">
              <span style="font-size:3.5rem;">🏛️</span>
            </div>
            <div class="auth-brand-gov">
              भारत सरकार &nbsp;•&nbsp; Government of India
            </div>
            <h1 class="auth-brand-title">MoSPI Skill Intelligence Platform</h1>
            <p class="auth-brand-subtitle">National Statistical Systems Training Academy (NSSTA)</p>
            <div class="auth-brand-badge-row">
              <span class="auth-badge igot">iGOT Karmayogi</span>
              <span class="auth-badge ai">AI-Powered</span>
              <span class="auth-badge">SIH 2026</span>
            </div>

            <!-- Features -->
            <div class="auth-features">
              <div class="auth-feature-item">
                <span class="auth-feature-icon">🎯</span>
                <div>
                  <div class="auth-feature-label">Competency Gap Analysis</div>
                  <div class="auth-feature-desc">AI-powered skill profiling</div>
                </div>
              </div>
              <div class="auth-feature-item">
                <span class="auth-feature-icon">📚</span>
                <div>
                  <div class="auth-feature-label">Personalized Learning</div>
                  <div class="auth-feature-desc">iGOT Karmayogi integration</div>
                </div>
              </div>
              <div class="auth-feature-item">
                <span class="auth-feature-icon">🤖</span>
                <div>
                  <div class="auth-feature-label">AI Quiz Generator</div>
                  <div class="auth-feature-desc">MCQs from uploaded materials</div>
                </div>
              </div>
              <div class="auth-feature-item">
                <span class="auth-feature-icon">📊</span>
                <div>
                  <div class="auth-feature-label">Workforce Analytics</div>
                  <div class="auth-feature-desc">Admin dashboards & reporting</div>
                </div>
              </div>
            </div>

            <div class="auth-brand-footer">
              🛡️ Protected under DPDP Act 2023 &amp; CERT-In Directives
            </div>
          </div>
        </div>

        <!-- Right Auth Panel -->
        <div class="auth-form-panel">
          <div class="auth-form-scroll">

            <!-- Backend Status -->
            <div class="auth-status-bar">
              <span class="auth-status-dot ${state.backendOnline ? 'online' : 'offline'}"></span>
              <span>${state.backendOnline ? 'Backend Server Online' : 'Connecting to server...'}</span>
              <span class="auth-status-db">🗄️ MySQL 8.x DB</span>
            </div>

            <!-- Mode Tabs: Login / Diagnostic Quiz / Register -->
            <div class="auth-mode-tabs" style="display: flex; gap: 0.35rem; margin-bottom: 1.25rem;">
              <button class="auth-mode-tab ${_mode === 'login' ? 'active' : ''}" id="tab-login" type="button" style="flex: 1; font-size: 0.8rem; padding: 8px 6px;">
                🔐 Sign In
              </button>
              <button class="auth-mode-tab ${_mode === 'diagnostic' ? 'active' : ''}" id="tab-diagnostic" type="button" style="flex: 1.35; font-size: 0.8rem; padding: 8px 6px; color: #38bdf8; font-weight: 700;">
                ⚡ Diagnostic &amp; Recs
              </button>
              <button class="auth-mode-tab ${_mode === 'register' ? 'active' : ''}" id="tab-register" type="button" style="flex: 1; font-size: 0.8rem; padding: 8px 6px;">
                ✨ New Register
              </button>
            </div>

            <div id="auth-panel-mount">
              ${_mode === 'login' 
                ? renderLoginPanel(state, cat) 
                : _mode === 'diagnostic' 
                ? renderDiagnosticPanel(state, cat) 
                : renderRegisterPanel(state, regCat)}
            </div>

          </div>
        </div>

        <!-- Toast Container -->
        <div class="toast-container" id="auth-toasts">
          ${(state.toasts || []).map(t => `
            <div class="toast ${t.type}">
              <span>${t.type === 'success' ? '✓' : t.type === 'warning' ? '⚠️' : t.type === 'danger' ? '✗' : 'ℹ️'}</span>
              <span>${t.message}</span>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  };

  const renderLoginPanel = (state, cat) => {
    const isLearner = (_category === "statistical_officer");
    const isAnalyst = (_category === "data_analyst");
    const isAdmin = (_category === "admin");

    return `
    <div class="auth-panel" id="auth-login-panel">
      <div class="auth-panel-header">
        <h2 class="auth-panel-title">Official Sign In</h2>
        <p class="auth-panel-desc">Authenticate with your government credentials or use 1-click verified officer demo</p>
      </div>

      ${isLearner ? `
      <!-- Baseline Diagnostic Onboarding Banner (Learner / Statistical Officer) -->
      <div style="margin-bottom: 1.25rem; padding: 0.85rem 1rem; background: linear-gradient(135deg, rgba(99,102,241,0.14), rgba(56,189,248,0.08)); border: 1px dashed rgba(99,102,241,0.4); border-radius: 8px; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap;">
        <div>
          <div style="font-weight: 700; font-size: 0.85rem; color: #a5b4fc; display: flex; align-items: center; gap: 6px;">
            <span>⚡</span> Learner Baseline Diagnostic Assessment &amp; Recommendations
          </div>
          <div style="font-size: 0.74rem; color: var(--text-muted);">
            Evaluate your starting skill level (0-5 scale) &amp; get personalized iGOT course recommendations instantly.
          </div>
        </div>
        <button type="button" id="btn-banner-diagnostic" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 4px 10px; border-color: #818cf8; color: #818cf8;">
          Take Diagnostic Quiz →
        </button>
      </div>
      ` : ''}

      <!-- Category Selector for Login -->
      <div class="category-selector">
        <div class="category-selector-label">Select Your Role Category</div>
        <div class="category-tabs" id="login-category-tabs">
          ${CATEGORIES.map(c => `
            <div class="category-tab ${_category === c.key ? 'active' : ''}" 
                 data-category="${c.key}"
                 style="${_category === c.key ? `border-color: ${c.color}; background: ${c.color}18;` : ''}">
              <span>${c.icon}</span>
              <span style="${_category === c.key ? `color: ${c.color};` : ''}">${c.label}</span>
            </div>
          `).join('')}
        </div>
        <div class="category-desc-bar" style="border-left-color: ${cat.color}; color: ${cat.color};">
          ${cat.icon} ${cat.description}
        </div>
      </div>

      <!-- Login Form -->
      <form id="login-form" class="auth-form">
        <div class="form-group">
          <label class="form-label">Official Email / Gov ID</label>
          <input type="email" id="login-email" class="form-input"
            placeholder="officer@mospi.gov.in"
            value="${getDemoEmail(_category)}" required />
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="input-with-toggle">
            <input type="password" id="login-password" class="form-input"
              placeholder="••••••••••••"
              value="SecurePassword123!" required />
            <button type="button" class="password-toggle" id="login-pwd-toggle">👁</button>
          </div>
        </div>

        ${isLearner ? `
        <!-- Skill Declaration on Sign In (ONLY FOR STATISTICAL OFFICERS / LEARNERS) -->
        <div style="margin-bottom: 1.25rem; border: 1px solid var(--border-default); border-radius: 12px; background: var(--bg-surface-elevated); overflow: hidden; box-shadow: var(--shadow-sm);">
          <div style="width: 100%; padding: 0.75rem 0.95rem; background: var(--bg-surface); border-bottom: 1px solid var(--border-subtle); display: flex; align-items: center; justify-content: space-between;">
            <span style="display: flex; align-items: center; gap: 8px; font-weight: 700; font-size: 0.85rem; color: var(--text-primary);">
              <span>🎯</span> Declare Your Starting Skills (0 - 5 Scale)
            </span>
            <span style="font-size: 0.7rem; color: var(--primary-accent); font-weight: 700; background: rgba(99,102,241,0.1); padding: 2px 8px; border-radius: 9999px;">AI Calibration</span>
          </div>
          <div id="login-skills-drawer" style="padding: 0.85rem;">
            <p style="font-size: 0.78rem; color: var(--text-secondary); margin-bottom: 0.75rem; line-height: 1.45;">
              Set your current confidence level for key official statistics skills. After login, our AI generates a tailored <strong>Basic Diagnostic Quiz</strong> to calibrate your exact verified percentage &amp; improvement pathway!
            </p>
            <div style="display: flex; gap: 0.5rem; margin-bottom: 0.75rem;">
              <button type="button" id="btn-login-preset-1" style="flex: 1; padding: 0.35rem 0.5rem; font-size: 0.72rem; font-weight: 600; background: var(--bg-surface); border: 1px solid var(--border-default); border-radius: 6px; color: var(--text-secondary); cursor: pointer;">
                Beginner (All 1)
              </button>
              <button type="button" id="btn-login-preset-3" style="flex: 1; padding: 0.35rem 0.5rem; font-size: 0.72rem; font-weight: 600; background: var(--bg-surface); border: 1px solid var(--border-default); border-radius: 6px; color: var(--text-secondary); cursor: pointer;">
                Intermediate (All 3)
              </button>
              <button type="button" id="btn-login-preset-0" style="padding: 0.35rem 0.6rem; font-size: 0.72rem; font-weight: 600; background: var(--bg-surface); border: 1px solid var(--border-default); border-radius: 6px; color: var(--text-muted); cursor: pointer;">
                Reset
              </button>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
              ${INITIAL_REG_SKILLS.slice(0, 6).map(sk => `
                <div style="background: var(--bg-surface); padding: 0.55rem 0.7rem; border-radius: 8px; border: 1px solid var(--border-subtle);">
                  <div style="display: flex; justify-content: space-between; font-size: 0.76rem; margin-bottom: 0.3rem;">
                    <span style="color: var(--text-primary); font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 120px;" title="${sk.name}">${sk.name}</span>
                    <span id="login-skill-val-${sk.id}" style="color: var(--saffron); font-weight: 800;">1 / 5</span>
                  </div>
                  <input type="range" class="login-skill-slider" data-skill-id="${sk.id}" min="0" max="5" value="1" style="width: 100%; cursor: pointer; accent-color: var(--primary-accent);" />
                </div>
              `).join('')}
            </div>
          </div>
        </div>
        ` : isAnalyst ? `
        <!-- Examiner / Teacher / Analytics Staff Access Card -->
        <div style="margin-bottom: 1.25rem; border: 1px solid rgba(56, 189, 248, 0.35); border-radius: 12px; background: rgba(56, 189, 248, 0.08); padding: 1rem; box-shadow: var(--shadow-sm);">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.4rem;">
            <span style="font-weight: 700; font-size: 0.88rem; color: #38bdf8; display: flex; align-items: center; gap: 8px;">
              <span>💻</span> Examiner &amp; Faculty / Data Analyst Access
            </span>
            <span style="font-size: 0.7rem; color: #38bdf8; background: rgba(56,189,248,0.15); padding: 2px 8px; border-radius: 9999px; font-weight: 700;">Exam Setter &amp; Evaluator</span>
          </div>
          <p style="font-size: 0.78rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
            You are signing in as an <strong>Academic Examiner &amp; Data Analyst</strong>. You create official assessments, upload study materials for AI question generation, and analyze national statistical competency metrics. <em>No baseline diagnostic exam required.</em>
          </p>
        </div>
        ` : `
        <!-- Administrator Access Card -->
        <div style="margin-bottom: 1.25rem; border: 1px solid rgba(249, 115, 22, 0.35); border-radius: 12px; background: rgba(249, 115, 22, 0.08); padding: 1rem; box-shadow: var(--shadow-sm);">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.4rem;">
            <span style="font-weight: 700; font-size: 0.88rem; color: #f97316; display: flex; align-items: center; gap: 8px;">
              <span>🛡️</span> NSSTA Platform Administrator Console
            </span>
            <span style="font-size: 0.7rem; color: #f97316; background: rgba(249,115,22,0.15); padding: 2px 8px; border-radius: 9999px; font-weight: 700;">Full System Authority</span>
          </div>
          <p style="font-size: 0.78rem; color: var(--text-secondary); margin: 0; line-height: 1.5;">
            You are signing in with <strong>NSSTA Academy Administrator</strong> privileges to oversee training tracks, manage officer registrations, audit database records, and govern the MoSPI learning platform. <em>No baseline diagnostic exam required.</em>
          </p>
        </div>
        `}

        <button type="submit" class="auth-btn primary" id="btn-submit-login"
                style="background: ${cat.gradient};">
          <span>🔐</span> Sign In as ${cat.label}
        </button>

        <!-- Switch to Register Link -->
        <div style="text-align: center; margin-top: 1rem; padding: 0.75rem 1rem; background: rgba(99,102,241,0.08); border: 1px dashed rgba(99,102,241,0.3); border-radius: 8px;">
          <span style="color: var(--text-muted); font-size: 0.85rem;">New Officer joining MoSPI or NSSTA?</span>
          <button type="button" id="btn-goto-register" style="display: block; margin: 0.35rem auto 0; background: none; border: none; color: #818cf8; font-weight: 700; cursor: pointer; text-decoration: underline; font-size: 0.9rem;">
            ✨ Click Here for New Officer Registration →
          </button>
        </div>
      </form>

      <!-- Divider -->
      <div class="auth-divider">
        <span>OR</span>
      </div>

      <!-- Jan Parichay SSO -->
      <button class="auth-btn sso" id="btn-jan-parichay-sso">
        <span>🇮🇳</span> Sign In with Jan Parichay (National SSO)
      </button>

      <!-- 1-Click Demo Login Cards -->
      <div class="demo-section">
        <div class="demo-section-label">⚡ 1-Click Authenticated Official Login</div>
        <div class="demo-cards">
          <div class="demo-card" data-persona="official">
            <div class="demo-card-avatar" style="background: linear-gradient(135deg,#818cf8,#6366f1);">KS</div>
            <div class="demo-card-info">
              <div class="demo-card-name">Officer Karthikeya Sharma, JSO</div>
              <div class="demo-card-role">Junior Statistical Officer • DIID / MoSPI</div>
            </div>
            <div class="demo-card-arrow">→</div>
          </div>
          <div class="demo-card" data-persona="analyst">
            <div class="demo-card-avatar" style="background: linear-gradient(135deg,#38bdf8,#0ea5e9);">PN</div>
            <div class="demo-card-info">
              <div class="demo-card-name">Priya Nair (Assistant Director)</div>
              <div class="demo-card-role">Asst. Dir. — Data Analyst</div>
            </div>
            <div class="demo-card-arrow">→</div>
          </div>
          <div class="demo-card" data-persona="senior">
            <div class="demo-card-avatar" style="background: linear-gradient(135deg,#fb923c,#f97316);">RV</div>
            <div class="demo-card-info">
              <div class="demo-card-name">Rajesh Verma (Senior Officer)</div>
              <div class="demo-card-role">SSO — Senior Stat Officer</div>
            </div>
            <div class="demo-card-arrow">→</div>
          </div>
          <div class="demo-card admin-card" data-persona="admin">
            <div class="demo-card-avatar" style="background: linear-gradient(135deg,#f97316,#ea580c);">AM</div>
            <div class="demo-card-info">
              <div class="demo-card-name">Dr. Arun Mehra</div>
              <div class="demo-card-role">NSSTA Administrator ★</div>
            </div>
            <div class="demo-card-arrow">→</div>
          </div>
        </div>
      </div>

      <div class="auth-legal">
        🛡️ Authorized Government Access Only. DPDP Act 2023 &amp; CERT-In Compliant.
      </div>
    </div>
    `;
  };

  const renderDiagnosticPanel = (state, cat) => `
    <div class="auth-panel" id="auth-diagnostic-panel">
      <div class="auth-panel-header">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 0.35rem;">
          <h2 class="auth-panel-title" style="margin: 0; display: flex; align-items: center; gap: 8px;">
            <span>⚡</span> Baseline Diagnostic &amp; Recommendation Engine
          </h2>
          <span style="font-size: 0.72rem; color: #818cf8; background: rgba(99,102,241,0.12); padding: 3px 8px; border-radius: 4px; border: 1px solid rgba(99,102,241,0.3); font-weight: 700;">
            Person 1 Engine • MoSPI Standard
          </span>
        </div>
        <p class="auth-panel-desc">
          Take this rapid baseline assessment or adjust your starting competencies (0–5 scale).
          Our AI engine calculates your role readiness score, identifies critical skill gaps, and recommends courses instantly!
        </p>
      </div>

      <!-- Category Selector for Diagnostic Target -->
      <div class="category-selector" style="margin-bottom: 1.25rem;">
        <div class="category-selector-label">Target Evaluation Role</div>
        <div class="category-tabs" id="diag-category-tabs">
          ${CATEGORIES.map(c => `
            <div class="category-tab ${_category === c.key ? 'active' : ''}" 
                 data-diagcat="${c.key}"
                 style="${_category === c.key ? `border-color: ${c.color}; background: ${c.color}18;` : ''}">
              <span>${c.icon}</span>
              <span style="${_category === c.key ? `color: ${c.color};` : ''}">${c.label}</span>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Rapid 4-Question Diagnostic Quiz -->
      <div class="reg-diagnostic-quiz-box" style="background: rgba(15,23,42,0.7); border: 1px dashed rgba(56,189,248,0.35); border-radius: 10px; padding: 1.2rem; margin-bottom: 1.25rem;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem; flex-wrap: wrap; gap: 0.5rem;">
          <div style="font-weight: 700; font-size: 0.9rem; color: #7dd3fc; display: flex; align-items: center; gap: 6px;">
            <span>⚡</span> Step 1: Rapid Baseline Diagnostic Questions
          </div>
          <span id="onboarding-quiz-score-badge" style="font-size: 0.75rem; color: #38bdf8; background: rgba(56,189,248,0.12); padding: 3px 10px; border-radius: 4px; font-weight: 700;">
            0 / 4 Answered
          </span>
        </div>
        <p style="font-size: 0.76rem; color: var(--text-muted); margin-bottom: 0.85rem; line-height: 1.4;">
          Objective statistical evaluation. Correct answers immediately calibrate your competencies to Intermediate (Level 3)!
        </p>

        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
          <!-- Question 1 -->
          <div class="diag-q-card" style="background: rgba(30,41,59,0.5); padding: 0.75rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
            <div style="font-size: 0.8rem; font-weight: 600; color: #f1f5f9; margin-bottom: 0.35rem;">
              1. (Sampling) In NSSO rural sample design, what are the First Stage Units (FSUs)?
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem; font-size: 0.75rem;">
              <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                <input type="radio" name="onboard_q1" value="A" class="onboard-radio" data-skill="2" data-correct="false" /> A. Agricultural blocks
              </label>
              <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                <input type="radio" name="onboard_q1" value="B" class="onboard-radio" data-skill="2" data-correct="true" /> B. Census villages ✓
              </label>
            </div>
          </div>

          <!-- Question 2 -->
          <div class="diag-q-card" style="background: rgba(30,41,59,0.5); padding: 0.75rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
            <div style="font-size: 0.8rem; font-weight: 600; color: #f1f5f9; margin-bottom: 0.35rem;">
              2. (National Accounts) Under SNA 2008, how is GDP at market prices derived from GVA?
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem; font-size: 0.75rem;">
              <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                <input type="radio" name="onboard_q2" value="A" class="onboard-radio" data-skill="3" data-correct="true" /> A. GVA + Product Taxes - Subsidies ✓
              </label>
              <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                <input type="radio" name="onboard_q2" value="B" class="onboard-radio" data-skill="3" data-correct="false" /> B. GVA - Intermediate Cost
              </label>
            </div>
          </div>

          <!-- Question 3 -->
          <div class="diag-q-card" style="background: rgba(30,41,59,0.5); padding: 0.75rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
            <div style="font-size: 0.8rem; font-weight: 600; color: #f1f5f9; margin-bottom: 0.35rem;">
              3. (Data Analysis) Which Python library handles tabular survey microdata in MoSPI?
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem; font-size: 0.75rem;">
              <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                <input type="radio" name="onboard_q3" value="A" class="onboard-radio" data-skill="11" data-correct="false" /> A. Tkinter Window
              </label>
              <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                <input type="radio" name="onboard_q3" value="B" class="onboard-radio" data-skill="11" data-correct="true" /> B. Pandas &amp; NumPy ✓
              </label>
            </div>
          </div>

          <!-- Question 4 -->
          <div class="diag-q-card" style="background: rgba(30,41,59,0.5); padding: 0.75rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
            <div style="font-size: 0.8rem; font-weight: 600; color: #f1f5f9; margin-bottom: 0.35rem;">
              4. (Governance) Which statutory provision in India governs citizen data confidentiality &amp; privacy in statistical surveys?
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem; font-size: 0.75rem;">
              <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                <input type="radio" name="onboard_q4" value="A" class="onboard-radio" data-skill="23" data-correct="true" /> A. DPDP Act 2023 &amp; Statistics Act ✓
              </label>
              <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                <input type="radio" name="onboard_q4" value="B" class="onboard-radio" data-skill="23" data-correct="false" /> B. Patents &amp; Trademarks Act
              </label>
            </div>
          </div>
        </div>
      </div>

      <!-- Step 2: Fine-Tune Starting Competencies (0 to 5) -->
      <div style="margin-bottom: 1.25rem;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.4rem; flex-wrap: wrap; gap: 0.5rem;">
          <div style="font-weight: 700; font-size: 0.88rem; color: #e2e8f0;">
            Step 2: Review or Adjust Starting Competencies (0 - 5 Scale)
          </div>
          <div style="display: flex; gap: 0.4rem;">
            <button type="button" class="btn btn-secondary btn-sm" id="btn-diag-preset-zero" style="font-size: 0.72rem; padding: 2px 8px;">
              Reset to 0
            </button>
            <button type="button" class="btn btn-secondary btn-sm" id="btn-diag-preset-foundational" style="font-size: 0.72rem; padding: 2px 8px;">
              Foundational (1/5)
            </button>
          </div>
        </div>
        <p style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.65rem;">
          Scale: <strong>0 (Unskilled / Clean Slate)</strong> to <strong>5 (Expert / Master)</strong>. Drag sliders to reflect your background.
        </p>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.6rem;">
          ${INITIAL_REG_SKILLS.map(sk => `
            <div style="background: rgba(15,23,42,0.6); padding: 0.55rem 0.75rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.06);">
              <div style="display: flex; justify-content: space-between; font-size: 0.78rem; font-weight: 600; margin-bottom: 0.25rem;">
                <span style="color:#cbd5e1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 140px;" title="${sk.name}">${sk.name}</span>
                <span id="diag-val-${sk.id}" style="color: var(--saffron); font-weight: 700;">0 / 5</span>
              </div>
              <input type="range" class="diag-slider" data-skill-id="${sk.id}" data-skill-name="${sk.name}" min="0" max="5" value="0" style="width: 100%; cursor: pointer;" />
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Step 3: Real-Time Evaluated Profile & Recommendations (Person 1 Spec) -->
      <div class="glass-panel" id="diag-live-result-box" style="padding: 1.25rem; border-color: rgba(99,102,241,0.35); background: linear-gradient(135deg, rgba(99,102,241,0.1), rgba(16,185,129,0.05)); margin-bottom: 1.25rem;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 0.5rem;">
          <div style="font-weight: 700; font-size: 0.88rem; color: #818cf8; display: flex; align-items: center; gap: 6px;">
            <span>🎯</span> Evaluated Baseline Profile (Person 1 Engine)
          </div>
          <div id="diag-readiness-badge" style="font-size: 0.8rem; font-weight: 800; color: #34d399; background: rgba(16,185,129,0.15); padding: 3px 10px; border-radius: 4px; border: 1px solid rgba(16,185,129,0.3);">
            Readiness: 0%
          </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 0.75rem;">
          <div>
            <div style="font-size: 0.74rem; font-weight: 700; color: #94a3b8; text-transform: uppercase; margin-bottom: 0.35rem;">Top Skill Gaps</div>
            <div id="diag-gaps-list" style="display: flex; flex-direction: column; gap: 0.35rem; font-size: 0.76rem;">
              <span style="color: var(--text-muted);">Sampling Techniques (Gap: -3), Python (Gap: -3)</span>
            </div>
          </div>
          <div>
            <div style="font-size: 0.74rem; font-weight: 700; color: #94a3b8; text-transform: uppercase; margin-bottom: 0.35rem;">Recommended Courses</div>
            <div id="diag-recs-list" style="display: flex; flex-direction: column; gap: 0.35rem; font-size: 0.76rem;">
              <span style="color: var(--text-muted);">Survey Sampling &amp; Estimation ([NSSTA TPAC Priority])</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Action Buttons -->
      <div style="display: flex; gap: 0.75rem; flex-direction: column;">
        <button type="button" class="auth-btn primary" id="btn-diag-proceed-login" style="background: ${cat.gradient};">
          <span>🔐</span> Sign In with These Calibrated Levels →
        </button>
        <button type="button" class="btn btn-secondary" id="btn-diag-proceed-reg" style="width: 100%; padding: 0.75rem; font-size: 0.85rem;">
          <span>✨</span> Register as New Officer with These Calibrated Levels
        </button>
      </div>
    </div>
  `;

  const renderRegisterPanel = (state, regCat) => {
    const isRegLearner = (_regCategory === "statistical_officer");
    const isRegAnalyst = (_regCategory === "data_analyst");

    return `
    <div class="auth-panel" id="auth-register-panel">
      <div class="auth-panel-header">
        <h2 class="auth-panel-title">New Officer Registration</h2>
        <p class="auth-panel-desc">Register your official profile — data stored in MoSPI Skill Database</p>
      </div>

      <!-- Role Category Selector -->
      <div class="category-selector">
        <div class="category-selector-label">Select Your Role Category</div>
        <div class="category-tabs" id="reg-category-tabs">
          ${CATEGORIES.map(c => `
            <div class="category-tab ${_regCategory === c.key ? 'active' : ''}"
                 data-regcat="${c.key}"
                 style="${_regCategory === c.key ? `border-color: ${c.color}; background: ${c.color}18;` : ''}">
              <span>${c.icon}</span>
              <span style="${_regCategory === c.key ? `color: ${c.color};` : ''}">${c.label}</span>
            </div>
          `).join('')}
        </div>
        <div class="category-desc-bar" style="border-left-color: ${regCat.color}; color: ${regCat.color};">
          ${regCat.icon} ${regCat.description}
        </div>
      </div>

      <!-- Registration Form -->
      <form id="register-form" class="auth-form register-form">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Employee Code <span class="required">*</span></label>
            <input type="text" id="reg-employee_code" class="form-input"
              placeholder="e.g. MOSPI2026001" required />
          </div>
          <div class="form-group">
            <label class="form-label">Full Name <span class="required">*</span></label>
            <input type="text" id="reg-name" class="form-input"
              placeholder="e.g. Ramesh Kumar Sharma" required />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Official Email <span class="required">*</span></label>
            <input type="email" id="reg-email" class="form-input"
              placeholder="e.g. officer@mospi.gov.in" required />
          </div>
          <div class="form-group">
            <label class="form-label">Password <span class="required">*</span></label>
            <div class="input-with-toggle">
              <input type="password" id="reg-password" class="form-input"
                placeholder="Min. 8 chars" required minlength="8" />
              <button type="button" class="password-toggle" id="reg-pwd-toggle">👁</button>
            </div>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Designation</label>
            <input type="text" id="reg-designation" class="form-input"
              placeholder="${regCat.defaultDesignation}"
              value="${regCat.defaultDesignation}" />
          </div>
          <div class="form-group">
            <label class="form-label">Department / Ministry</label>
            <select id="reg-department_name" class="form-input form-select">
              ${DEPARTMENTS.map(d => `<option value="${d}">${d}</option>`).join('')}
            </select>
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Qualification</label>
            <input type="text" id="reg-qualification" class="form-input"
              placeholder="e.g. M.Sc. Statistics / MBA" />
          </div>
          <div class="form-group">
            <label class="form-label">Work Experience (Years)</label>
            <input type="number" id="reg-work_experience_years" class="form-input"
              placeholder="e.g. 5" min="0" max="45" value="0" />
          </div>
        </div>

        <!-- Role Category (hidden, set automatically) -->
        <input type="hidden" id="reg-role_name" value="${regCat.roleName}" />

        ${isRegLearner ? `
        <!-- Initial Competencies Self-Rating (0 to 5 Scale) -->
        <div class="reg-skills-assessment-box" style="margin-top: 1.25rem; margin-bottom: 1.25rem; background: rgba(30,41,59,0.5); border: 1px solid rgba(99,102,241,0.25); border-radius: 10px; padding: 1.15rem;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem; flex-wrap: wrap; gap: 0.5rem;">
            <div style="font-weight: 700; font-size: 0.95rem; color: #c7d2fe; display: flex; align-items: center; gap: 0.5rem;">
              <span>🎯</span> Declare Your Initial Skills (0 - 5 Scale)
            </div>
            <span style="font-size: 0.75rem; color: #818cf8; background: rgba(99,102,241,0.15); padding: 3px 8px; border-radius: 4px; border: 1px solid rgba(99,102,241,0.3);">
              Scale: 0 (Unskilled) → 5 (Expert)
            </span>
          </div>
          <p style="font-size: 0.78rem; color: var(--text-muted); margin-bottom: 0.85rem; line-height: 1.4;">
            Rate your starting competency level below. Leave at <strong>0</strong> to begin fresh. Your initial percentage and MySQL profile will accurately reflect these levels!
          </p>

          <div style="display: flex; gap: 0.5rem; margin-bottom: 1rem; flex-wrap: wrap;">
            <button type="button" class="btn btn-secondary btn-sm" id="btn-preset-all-zero" style="font-size: 0.75rem; padding: 4px 10px;">
              Reset All to 0 (Fresh Official)
            </button>
            <button type="button" class="btn btn-secondary btn-sm" id="btn-preset-foundational" style="font-size: 0.75rem; padding: 4px 10px;">
              Foundational (All 1 / 5)
            </button>
          </div>

          <div class="reg-skills-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem;">
            ${INITIAL_REG_SKILLS.map(sk => `
              <div style="background: rgba(15,23,42,0.6); padding: 0.65rem 0.85rem; border-radius: 8px; border: 1px solid rgba(255,255,255,0.06);">
                <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 600; margin-bottom: 0.35rem;">
                  <span style="color:#e2e8f0;">${sk.name}</span>
                  <span id="reg-skill-val-${sk.id}" style="color: var(--saffron); font-weight: 700;">0 / 5</span>
                </div>
                <input type="range" class="reg-skill-slider" data-skill-id="${sk.id}" data-skill-name="${sk.name}" min="0" max="5" value="0" style="width: 100%; cursor: pointer;" />
              </div>
            `).join('')}
          </div>

          <!-- Rapid Baseline Diagnostic Quiz (Person 1 / Person 2 Feature) -->
          <div class="reg-diagnostic-quiz-box" style="margin-top: 1rem; background: rgba(15,23,42,0.7); border: 1px dashed rgba(56,189,248,0.35); border-radius: 8px; padding: 1rem;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem; flex-wrap: wrap; gap: 0.5rem;">
              <div style="font-weight: 700; font-size: 0.88rem; color: #7dd3fc; display: flex; align-items: center; gap: 6px;">
                <span>⚡</span> Rapid Diagnostic Quiz (Auto-Calibrate Skill Levels)
              </div>
              <span id="diagnostic-quiz-score-badge" style="font-size: 0.72rem; color: #38bdf8; background: rgba(56,189,248,0.12); padding: 2px 8px; border-radius: 4px; font-weight: 700;">
                0 / 3 Answered
              </span>
            </div>
            <p style="font-size: 0.75rem; color: var(--text-muted); margin-bottom: 0.75rem; line-height: 1.35;">
              Answer these 3 quick statistical questions to objectively evaluate your starting level. Correct answers automatically raise your corresponding skill sliders!
            </p>

            <div style="display: flex; flex-direction: column; gap: 0.75rem;">
              <!-- Question 1 -->
              <div class="diag-q-card" style="background: rgba(30,41,59,0.5); padding: 0.7rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
                <div style="font-size: 0.78rem; font-weight: 600; color: #f1f5f9; margin-bottom: 0.35rem;">
                  1. (Sampling) In PLFS/NSSO rural surveys, what are First Stage Units (FSUs)?
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem; font-size: 0.74rem;">
                  <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                    <input type="radio" name="diag_q1" value="A" class="diag-radio" data-skill="2" data-correct="false" /> A. District blocks
                  </label>
                  <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                    <input type="radio" name="diag_q1" value="B" class="diag-radio" data-skill="2" data-correct="true" /> B. Census villages ✓
                  </label>
                </div>
              </div>

              <!-- Question 2 -->
              <div class="diag-q-card" style="background: rgba(30,41,59,0.5); padding: 0.7rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
                <div style="font-size: 0.78rem; font-weight: 600; color: #f1f5f9; margin-bottom: 0.35rem;">
                  2. (National Accounts) Under SNA 2008, how is GDP at market prices derived from GVA?
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem; font-size: 0.74rem;">
                  <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                    <input type="radio" name="diag_q2" value="A" class="diag-radio" data-skill="3" data-correct="true" /> A. GVA + Taxes - Subsidies ✓
                  </label>
                  <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                    <input type="radio" name="diag_q2" value="B" class="diag-radio" data-skill="3" data-correct="false" /> B. GVA - Intermediate Cost
                  </label>
                </div>
              </div>

              <!-- Question 3 -->
              <div class="diag-q-card" style="background: rgba(30,41,59,0.5); padding: 0.7rem; border-radius: 6px; border: 1px solid rgba(255,255,255,0.05);">
                <div style="font-size: 0.78rem; font-weight: 600; color: #f1f5f9; margin-bottom: 0.35rem;">
                  3. (Data Analysis) Which Python library handles tabular survey microdata in MoSPI?
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.35rem; font-size: 0.74rem;">
                  <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                    <input type="radio" name="diag_q3" value="A" class="diag-radio" data-skill="11" data-correct="false" /> A. Tkinter Window
                  </label>
                  <label style="display: flex; align-items: center; gap: 5px; cursor: pointer; color: var(--text-secondary);">
                    <input type="radio" name="diag_q3" value="B" class="diag-radio" data-skill="11" data-correct="true" /> B. Pandas &amp; NumPy ✓
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
        ` : isRegAnalyst ? `
        <!-- Examiner / Staff Info Box -->
        <div style="margin-top: 1.25rem; margin-bottom: 1.25rem; background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.3); border-radius: 10px; padding: 1.15rem;">
          <div style="font-weight: 700; font-size: 0.95rem; color: #7dd3fc; display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.35rem;">
            <span>💻</span> Examiner &amp; Faculty Registration
          </div>
          <p style="font-size: 0.78rem; color: var(--text-secondary); margin: 0; line-height: 1.45;">
            Data Analyst accounts are granted examiner &amp; evaluation privileges (creating official AI assessments, uploading curriculum, and monitoring workforce competencies). <em>No learner diagnostic baseline test required.</em>
          </p>
        </div>
        ` : `
        <!-- Administrator Info Box -->
        <div style="margin-top: 1.25rem; margin-bottom: 1.25rem; background: rgba(249, 115, 22, 0.08); border: 1px solid rgba(249, 115, 22, 0.3); border-radius: 10px; padding: 1.15rem;">
          <div style="font-weight: 700; font-size: 0.95rem; color: #fdba74; display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.35rem;">
            <span>🛡️</span> Administrator Registration
          </div>
          <p style="font-size: 0.78rem; color: var(--text-secondary); margin: 0; line-height: 1.45;">
            Administrator accounts govern the NSSTA academy, manage official credentials, and audit database records. <em>Diagnostic quizzes and baseline skill calibration are reserved for learner profiles.</em>
          </p>
        </div>
        `}

        <button type="submit" class="auth-btn primary" id="btn-submit-register"
                style="background: ${regCat.gradient};">
          <span>✨</span> Register as ${regCat.label} — Save to MoSPI Database
        </button>

        <!-- Switch to Login Link -->
        <div style="text-align: center; margin-top: 1rem; padding: 0.75rem 1rem; background: rgba(99,102,241,0.08); border: 1px dashed rgba(99,102,241,0.3); border-radius: 8px;">
          <span style="color: var(--text-muted); font-size: 0.85rem;">Already have an authorized MoSPI / NSSTA account?</span>
          <button type="button" id="btn-goto-login" style="display: block; margin: 0.35rem auto 0; background: none; border: none; color: #818cf8; font-weight: 700; cursor: pointer; text-decoration: underline; font-size: 0.9rem;">
            🔐 Sign In with Existing Official Credentials →
          </button>
        </div>
      </form>

      <!-- Data Storage Info -->
      <div class="db-info-card">
        <div class="db-info-icon">🗄️</div>
        <div class="db-info-text">
          <strong>Data Stored Securely in MySQL 8.x Database (InnoDB ACID)</strong>
          <p>Your profile, baseline competencies, quiz records, and learning progress are committed to the MoSPI Skill Intelligence MySQL database ('sih_skill_platform') and synchronized with iGOT Karmayogi.</p>
        </div>
      </div>

      <div class="auth-legal">
        🛡️ Registration is restricted to authorized MoSPI / State DES / NSSTA officials.
        DPDP Act 2023 compliant.
      </div>
    </div>
    `;
  };

  const getDemoEmail = (categoryKey) => {
    const map = {
      statistical_officer: "karthikeya@mospi.gov.in",
      data_analyst: "priya.nair@mospi.gov.in",
      admin: "admin@nssta.gov.in"
    };
    return map[categoryKey] || "karthikeya@mospi.gov.in";
  };

  // --------------------------------------------------------------- EVENTS --
  const setMode = (newMode) => {
    _mode = newMode;
    const tabLogin = document.getElementById("tab-login");
    const tabDiagnostic = document.getElementById("tab-diagnostic");
    const tabRegister = document.getElementById("tab-register");
    const mount = document.getElementById("auth-panel-mount");

    if (tabLogin) {
      if (_mode === "login") tabLogin.classList.add("active");
      else tabLogin.classList.remove("active");
    }
    if (tabDiagnostic) {
      if (_mode === "diagnostic") tabDiagnostic.classList.add("active");
      else tabDiagnostic.classList.remove("active");
    }
    if (tabRegister) {
      if (_mode === "register") tabRegister.classList.add("active");
      else tabRegister.classList.remove("active");
    }

    if (mount) {
      const state = store.getState();
      const cat = CATEGORIES.find(c => c.key === _category) || CATEGORIES[0];
      const regCat = CATEGORIES.find(c => c.key === _regCategory) || CATEGORIES[0];
      if (_mode === "login") mount.innerHTML = renderLoginPanel(state, cat);
      else if (_mode === "diagnostic") mount.innerHTML = renderDiagnosticPanel(state, cat);
      else mount.innerHTML = renderRegisterPanel(state, regCat);
      bindPanelEvents();
      if (_mode === "diagnostic") {
        setTimeout(triggerDiagnosticRecalculation, 60);
      }
    }
  };

  const triggerDiagnosticRecalculation = async () => {
    const skillsMap = {};
    document.querySelectorAll(".diag-slider").forEach(sl => {
      const sname = sl.getAttribute("data-skill-name");
      skillsMap[sname] = parseInt(sl.value, 10);
    });

    const roleName = _category === "data_analyst" ? "Data Analyst" : _category === "admin" ? "admin" : "Statistical Officer";

    try {
      const res = await API.calibrateDiagnosticSkills({
        role_name: roleName,
        skills: skillsMap
      });

      const readinessBadge = document.getElementById("diag-readiness-badge");
      if (readinessBadge) {
        readinessBadge.textContent = `Readiness: ${res.overall_score || 0}%`;
      }

      const gapsList = document.getElementById("diag-gaps-list");
      if (gapsList) {
        const topGaps = (res.gaps || []).slice(0, 3);
        if (topGaps.length === 0) {
          gapsList.innerHTML = '<span style="color:#34d399; font-weight:600;">✓ Target Met for Role</span>';
        } else {
          gapsList.innerHTML = topGaps.map(g => `
            <div style="background: rgba(239,68,68,0.12); border: 1px solid rgba(239,68,68,0.25); padding: 4px 8px; border-radius: 4px; color: #fca5a5;">
              <strong>${g.skill_name}</strong> (Req: ${g.required_level}, Gap: -${g.gap})
            </div>
          `).join('');
        }
      }

      const recsList = document.getElementById("diag-recs-list");
      if (recsList) {
        const topRecs = (res.recommendations || []).slice(0, 2);
        if (topRecs.length === 0) {
          recsList.innerHTML = '<span style="color: var(--text-muted);">No immediate gaps identified.</span>';
        } else {
          recsList.innerHTML = topRecs.map(r => `
            <div style="background: rgba(99,102,241,0.12); border: 1px solid rgba(99,102,241,0.25); padding: 4px 8px; border-radius: 4px; color: #c7d2fe;">
              <strong>${r.title}</strong>
              <div style="font-size: 0.7rem; color: #a5b4fc; margin-top:2px;">${r.reason}</div>
            </div>
          `).join('');
        }
      }
    } catch (err) {
      console.warn("Live calibration fallback:", err);
    }
  };

  const bindEvents = () => {
    // Mode tabs
    const tabLogin = document.getElementById("tab-login");
    const tabDiagnostic = document.getElementById("tab-diagnostic");
    const tabRegister = document.getElementById("tab-register");
    if (tabLogin) {
      tabLogin.onclick = (e) => {
        e.preventDefault();
        setMode("login");
      };
    }
    if (tabDiagnostic) {
      tabDiagnostic.onclick = (e) => {
        e.preventDefault();
        setMode("diagnostic");
      };
    }
    if (tabRegister) {
      tabRegister.onclick = (e) => {
        e.preventDefault();
        setMode("register");
      };
    }

    bindPanelEvents();
  };

  const bindPanelEvents = () => {
    // Banner Diagnostic button
    const btnBannerDiag = document.getElementById("btn-banner-diagnostic");
    if (btnBannerDiag) {
      btnBannerDiag.addEventListener("click", () => setMode("diagnostic"));
    }

    // Diagnostic Category Tabs
    document.querySelectorAll("#diag-category-tabs .category-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        _category = tab.getAttribute("data-diagcat");
        setMode("diagnostic");
      });
    });

    // Diagnostic Question Radios
    document.querySelectorAll(".onboard-radio").forEach(radio => {
      radio.addEventListener("change", (e) => {
        const isCorrect = e.target.getAttribute("data-correct") === "true";
        const skillId = e.target.getAttribute("data-skill");
        if (isCorrect) {
          const slider = document.querySelector(`.diag-slider[data-skill-id="${skillId}"]`);
          if (slider) {
            slider.value = 3;
            const valEl = document.getElementById(`diag-val-${skillId}`);
            if (valEl) valEl.textContent = "3 / 5";
          }
        }

        let correctCount = 0;
        let answeredCount = 0;
        ["onboard_q1", "onboard_q2", "onboard_q3", "onboard_q4"].forEach(name => {
          const sel = document.querySelector(`input[name="${name}"]:checked`);
          if (sel) {
            answeredCount++;
            if (sel.getAttribute("data-correct") === "true") correctCount++;
          }
        });

        const badge = document.getElementById("onboarding-quiz-score-badge");
        if (badge) {
          badge.textContent = `${correctCount} / 4 Correct (${Math.round((correctCount / 4) * 100)}%)`;
          badge.style.color = correctCount > 0 ? "#10b981" : "#38bdf8";
        }

        triggerDiagnosticRecalculation();
      });
    });

    // Diagnostic Sliders
    document.querySelectorAll(".diag-slider").forEach(sl => {
      sl.addEventListener("input", (e) => {
        const skId = e.target.getAttribute("data-skill-id");
        const valEl = document.getElementById(`diag-val-${skId}`);
        if (valEl) valEl.textContent = `${e.target.value} / 5`;
        triggerDiagnosticRecalculation();
      });
    });

    const btnDiagZero = document.getElementById("btn-diag-preset-zero");
    if (btnDiagZero) {
      btnDiagZero.addEventListener("click", () => {
        document.querySelectorAll(".diag-slider").forEach(sl => {
          sl.value = 0;
          const skId = sl.getAttribute("data-skill-id");
          const valEl = document.getElementById(`diag-val-${skId}`);
          if (valEl) valEl.textContent = "0 / 5";
        });
        triggerDiagnosticRecalculation();
      });
    }

    const btnDiagFoundational = document.getElementById("btn-diag-preset-foundational");
    if (btnDiagFoundational) {
      btnDiagFoundational.addEventListener("click", () => {
        document.querySelectorAll(".diag-slider").forEach(sl => {
          sl.value = 1;
          const skId = sl.getAttribute("data-skill-id");
          const valEl = document.getElementById(`diag-val-${skId}`);
          if (valEl) valEl.textContent = "1 / 5";
        });
        triggerDiagnosticRecalculation();
      });
    }

    // Diagnostic Action Buttons
    const btnDiagLogin = document.getElementById("btn-diag-proceed-login");
    if (btnDiagLogin) {
      btnDiagLogin.addEventListener("click", () => {
        window._calibratedInitialSkills = {};
        document.querySelectorAll(".diag-slider").forEach(sl => {
          window._calibratedInitialSkills[sl.getAttribute("data-skill-id")] = parseInt(sl.value, 10);
        });
        store.showToast("Calibrated starting levels captured! Proceeding to Sign In...", "success");
        setMode("login");
      });
    }

    const btnDiagReg = document.getElementById("btn-diag-proceed-reg");
    if (btnDiagReg) {
      btnDiagReg.addEventListener("click", () => {
        window._calibratedInitialSkills = {};
        document.querySelectorAll(".diag-slider").forEach(sl => {
          window._calibratedInitialSkills[sl.getAttribute("data-skill-id")] = parseInt(sl.value, 10);
        });
        store.showToast("Calibrated levels applied to registration form!", "success");
        setMode("register");
        setTimeout(() => {
          if (window._calibratedInitialSkills) {
            Object.entries(window._calibratedInitialSkills).forEach(([skId, val]) => {
              const regSl = document.querySelector(`.reg-skill-slider[data-skill-id="${skId}"]`);
              if (regSl) {
                regSl.value = val;
                const valEl = document.getElementById(`reg-skill-val-${skId}`);
                if (valEl) valEl.textContent = `${val} / 5`;
              }
            });
          }
        }, 50);
      });
    }

    // Quick switcher shortcuts
    const btnGotoRegister = document.getElementById("btn-goto-register");
    if (btnGotoRegister) {
      btnGotoRegister.onclick = (e) => {
        e.preventDefault();
        setMode("register");
      };
    }
    const btnGotoLogin = document.getElementById("btn-goto-login");
    if (btnGotoLogin) {
      btnGotoLogin.onclick = (e) => {
        e.preventDefault();
        setMode("login");
      };
    }

    // Login Category Tabs
    document.querySelectorAll("#login-category-tabs .category-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        _category = tab.getAttribute("data-category");
        setMode("login");
      });
    });

    // Register Category Tabs
    document.querySelectorAll("#reg-category-tabs .category-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        _regCategory = tab.getAttribute("data-regcat");
        setMode("register");
      });
    });

    // Registration Initial Skill Sliders
    document.querySelectorAll(".reg-skill-slider").forEach(slider => {
      slider.addEventListener("input", (e) => {
        const skId = e.target.getAttribute("data-skill-id");
        const valEl = document.getElementById(`reg-skill-val-${skId}`);
        if (valEl) valEl.textContent = `${e.target.value} / 5`;
      });
    });

    const btnPresetZero = document.getElementById("btn-preset-all-zero");
    if (btnPresetZero) {
      btnPresetZero.addEventListener("click", () => {
        document.querySelectorAll(".reg-skill-slider").forEach(sl => {
          sl.value = 0;
          const skId = sl.getAttribute("data-skill-id");
          const valEl = document.getElementById(`reg-skill-val-${skId}`);
          if (valEl) valEl.textContent = "0 / 5";
        });
      });
    }

    const btnPresetFoundational = document.getElementById("btn-preset-foundational");
    if (btnPresetFoundational) {
      btnPresetFoundational.addEventListener("click", () => {
        document.querySelectorAll(".reg-skill-slider").forEach(sl => {
          sl.value = 1;
          const skId = sl.getAttribute("data-skill-id");
          const valEl = document.getElementById(`reg-skill-val-${skId}`);
          if (valEl) valEl.textContent = "1 / 5";
        });
      });
    }

    // Diagnostic Quiz Radio listeners
    document.querySelectorAll(".diag-radio").forEach(radio => {
      radio.addEventListener("change", (e) => {
        const isCorrect = e.target.getAttribute("data-correct") === "true";
        const skillId = e.target.getAttribute("data-skill");
        if (isCorrect) {
          const slider = document.querySelector(`.reg-skill-slider[data-skill-id="${skillId}"]`);
          if (slider) {
            slider.value = 3;
            const valEl = document.getElementById(`reg-skill-val-${skillId}`);
            if (valEl) valEl.textContent = "3 / 5";
          }
        }

        let correctCount = 0;
        let totalAnswered = 0;
        ["diag_q1", "diag_q2", "diag_q3"].forEach(name => {
          const sel = document.querySelector(`input[name="${name}"]:checked`);
          if (sel) {
            totalAnswered++;
            if (sel.getAttribute("data-correct") === "true") correctCount++;
          }
        });
        const badge = document.getElementById("diagnostic-quiz-score-badge");
        if (badge) {
          badge.textContent = `${correctCount} / 3 Correct (${Math.round((correctCount/3)*100)}%)`;
          badge.style.color = correctCount > 0 ? "#10b981" : "#38bdf8";
        }
      });
    });

    // Password toggles
    const loginPwdToggle = document.getElementById("login-pwd-toggle");
    if (loginPwdToggle) {
      loginPwdToggle.addEventListener("click", () => {
        const inp = document.getElementById("login-password");
        if (inp) inp.type = inp.type === "password" ? "text" : "password";
      });
    }
    const regPwdToggle = document.getElementById("reg-pwd-toggle");
    if (regPwdToggle) {
      regPwdToggle.addEventListener("click", () => {
        const inp = document.getElementById("reg-password");
        if (inp) inp.type = inp.type === "password" ? "text" : "password";
      });
    }

    // Login Skill Presets & Sliders
    const btnLoginPreset1 = document.getElementById("btn-login-preset-1");
    if (btnLoginPreset1) {
      btnLoginPreset1.addEventListener("click", () => {
        document.querySelectorAll(".login-skill-slider").forEach(sl => {
          sl.value = 1;
          const skId = sl.getAttribute("data-skill-id");
          const valEl = document.getElementById(`login-skill-val-${skId}`);
          if (valEl) valEl.textContent = "1 / 5";
          if (!window._calibratedInitialSkills) window._calibratedInitialSkills = {};
          window._calibratedInitialSkills[skId] = 1;
        });
      });
    }

    const btnLoginPreset3 = document.getElementById("btn-login-preset-3");
    if (btnLoginPreset3) {
      btnLoginPreset3.addEventListener("click", () => {
        document.querySelectorAll(".login-skill-slider").forEach(sl => {
          sl.value = 3;
          const skId = sl.getAttribute("data-skill-id");
          const valEl = document.getElementById(`login-skill-val-${skId}`);
          if (valEl) valEl.textContent = "3 / 5";
          if (!window._calibratedInitialSkills) window._calibratedInitialSkills = {};
          window._calibratedInitialSkills[skId] = 3;
        });
      });
    }

    const btnLoginPreset0 = document.getElementById("btn-login-preset-0");
    if (btnLoginPreset0) {
      btnLoginPreset0.addEventListener("click", () => {
        document.querySelectorAll(".login-skill-slider").forEach(sl => {
          sl.value = 0;
          const skId = sl.getAttribute("data-skill-id");
          const valEl = document.getElementById(`login-skill-val-${skId}`);
          if (valEl) valEl.textContent = "0 / 5";
          if (!window._calibratedInitialSkills) window._calibratedInitialSkills = {};
          window._calibratedInitialSkills[skId] = 0;
        });
      });
    }

    document.querySelectorAll(".login-skill-slider").forEach(slider => {
      slider.addEventListener("input", (e) => {
        const skId = e.target.getAttribute("data-skill-id");
        const valEl = document.getElementById(`login-skill-val-${skId}`);
        if (valEl) valEl.textContent = `${e.target.value} / 5`;
        if (!window._calibratedInitialSkills) window._calibratedInitialSkills = {};
        window._calibratedInitialSkills[skId] = parseInt(e.target.value, 10);
      });
    });

    // ======================== LOGIN FORM ========================
    const loginForm = document.getElementById("login-form");
    if (loginForm) {
      loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const email = document.getElementById("login-email").value.trim();
        const password = document.getElementById("login-password").value;
        const btnSubmit = document.getElementById("btn-submit-login");

        // Collect declared skills from login sliders
        const declaredSkillsMap = {};
        document.querySelectorAll(".login-skill-slider").forEach(sl => {
          const skId = sl.getAttribute("data-skill-id");
          const val = parseInt(sl.value, 10);
          const skObj = INITIAL_REG_SKILLS.find(s => s.id == skId);
          const name = skObj ? skObj.name : skId;
          declaredSkillsMap[name] = val;
          if (!window._calibratedInitialSkills) window._calibratedInitialSkills = {};
          window._calibratedInitialSkills[skId] = val;
        });
        window._userDeclaredSkills = declaredSkillsMap;
        window._pendingDiagnosticPrompt = true;
        try {
          localStorage.setItem("userDeclaredSkills", JSON.stringify(declaredSkillsMap));
        } catch(e) {}

        if (btnSubmit) {
          btnSubmit.innerHTML = `<span>⏳</span> Authenticating with MoSPI Server...`;
          btnSubmit.disabled = true;
        }

        try {
          const res = await API.login(email, password);
          if (res && res.access_token) {
            store.resetSession();
            localStorage.setItem("token", res.access_token);

            let personaKey = _category === "admin" ? "admin"
              : _category === "data_analyst" ? "analyst"
              : "official";
            if (email.includes("admin")) personaKey = "admin";
            else if (email.includes("priya")) personaKey = "analyst";
            else if (email.includes("rajesh")) personaKey = "senior";

            let userDisplayName = res.user?.name;
            if (!userDisplayName || userDisplayName.toLowerCase().includes("statistical officer") || userDisplayName === "null") {
              userDisplayName = (email.includes("karthikeya") || _category === "statistical_officer") ? "Officer Karthikeya Sharma, JSO" : email.split("@")[0];
            }

            const currentUserObj = {
              id: res.user?.id,
              employee_code: res.user?.employee_code,
              name: userDisplayName,
              email: email,
              designation: res.user?.designation || (_category === "admin" ? "System Administrator" : _category === "data_analyst" ? "Assistant Director / Data Analyst" : "Junior Statistical Officer (JSO)"),
              role_name: res.user?.role_name || (_category === "admin" ? "admin" : _category === "data_analyst" ? "Data Analyst" : "Statistical Officer")
            };

            const isLearner = (_category === "statistical_officer" && personaKey !== "admin" && personaKey !== "analyst");

            store.setState({
              token: res.access_token,
              isAuthenticated: true,
              currentUser: currentUserObj,
              activePersona: personaKey,
              activeTab: personaKey === "admin" ? "admin" : isLearner ? "quiz" : "learner",
              backendOnline: true
            });

            // If learner calibrated skills during diagnostic onboarding, commit them to MySQL now
            if (isLearner && window._calibratedInitialSkills && Object.keys(window._calibratedInitialSkills).length > 0) {
              try {
                await API.updateCompetenciesBatch(window._calibratedInitialSkills);
              } catch (e) {
                console.warn("Could not sync diagnostic skills to DB:", e);
              }
            }

            await refreshBackendData();

            if (isLearner) {
              store.showToast(`✅ Welcome, ${currentUserObj.name}! Starting skills captured. Starting your Baseline Diagnostic Quiz...`, "success", 5000);
              // Auto-launch role-specific diagnostic quiz based on declared skills
              if (window.QuizComponent && window.QuizComponent.startBasicDiagnosticQuiz) {
                await window.QuizComponent.startBasicDiagnosticQuiz(declaredSkillsMap);
              } else if (window.switchTab) {
                window.switchTab("quiz");
              }
            } else if (personaKey === "admin") {
              store.showToast(`🛡️ Administrator Access: Welcome ${currentUserObj.name}! Opened NSSTA Admin Console.`, "success", 5000);
              if (window.switchTab) window.switchTab("admin");
            } else {
              store.showToast(`💻 Examiner Access: Welcome ${currentUserObj.name}! Direct access to Exam Management & Analytics.`, "success", 5000);
              if (window.switchTab) window.switchTab("learner");
            }
          }
        } catch (err) {
          console.warn("Login error:", err);
          store.showToast(`❌ Authentication failed: ${err.message || 'Invalid credentials'}`, "danger");
          if (btnSubmit) {
            btnSubmit.innerHTML = `<span>🔐</span> Sign In to Statistical Learning Portal`;
            btnSubmit.disabled = false;
          }
        }
      });
    }

    // ======================== REGISTER FORM ========================
    const registerForm = document.getElementById("register-form");
    if (registerForm) {
      registerForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const btn = document.getElementById("btn-submit-register");

        const payload = {
          employee_code: document.getElementById("reg-employee_code").value.trim(),
          name: document.getElementById("reg-name").value.trim(),
          email: document.getElementById("reg-email").value.trim(),
          password: document.getElementById("reg-password").value,
          designation: document.getElementById("reg-designation").value.trim(),
          department_name: document.getElementById("reg-department_name").value,
          qualification: document.getElementById("reg-qualification").value.trim() || "Master's in Statistics / Economics",
          work_experience_years: parseFloat(document.getElementById("reg-work_experience_years").value) || 0,
          role_name: document.getElementById("reg-role_name").value,
          initial_skills: {}
        };

        // Collect initial skills
        document.querySelectorAll(".reg-skill-slider").forEach(sl => {
          const skId = sl.getAttribute("data-skill-id");
          payload.initial_skills[skId] = parseInt(sl.value, 10);
        });

        // Basic validation
        if (!payload.employee_code || !payload.name || !payload.email || !payload.password) {
          store.showToast("⚠️ Please fill in all required fields (Employee Code, Name, Email, Password).", "warning");
          return;
        }
        if (payload.password.length < 8) {
          store.showToast("⚠️ Password must be at least 8 characters.", "warning");
          return;
        }

        if (btn) {
          btn.innerHTML = `<span>⏳</span> Registering in MySQL Database...`;
          btn.disabled = true;
        }

        try {
          const res = await API.register(payload);
          if (res && (res.access_token || res.id)) {
            store.resetSession();
            if (res.access_token) {
              localStorage.setItem("token", res.access_token);
            }

            const personaKey = _regCategory === "admin" ? "admin"
              : _regCategory === "data_analyst" ? "analyst"
              : "official";

            const registeredUser = {
              id: res.id,
              employee_code: res.employee_code || payload.employee_code,
              name: res.name || payload.name,
              email: res.email || payload.email,
              designation: res.designation || payload.designation,
              department_name: res.department_name || payload.department_name,
              role_name: res.role_name || payload.role_name
            };

            store.setState({
              token: res.access_token || null,
              isAuthenticated: !!res.access_token,
              currentUser: registeredUser,
              activePersona: personaKey,
              activeTab: personaKey === "admin" ? "admin" : "learner",
              backendOnline: true
            });

            store.showToast(
              `✅ ${registeredUser.name} registered in MySQL! Employee code: ${registeredUser.employee_code}.`,
              "success",
              5000
            );

            if (res.access_token) {
              await refreshBackendData();
              const isRegLearner = (_regCategory === "statistical_officer");
              if (isRegLearner) {
                if (window.QuizComponent && window.QuizComponent.startBasicDiagnosticQuiz) {
                  await window.QuizComponent.startBasicDiagnosticQuiz(payload.initial_skills);
                } else if (window.switchTab) {
                  window.switchTab("quiz");
                }
              } else if (_regCategory === "admin") {
                store.showToast(`🛡️ Administrator Account Active! Opened NSSTA Admin Console.`, "success");
                if (window.switchTab) window.switchTab("admin");
              } else {
                store.showToast(`💻 Examiner Account Active! Direct access to Exam Management & Analytics.`, "success");
                if (window.switchTab) window.switchTab("learner");
              }
            } else {
              setMode("login");
            }
          }
        } catch (err) {
          console.warn("Registration error:", err);
          store.showToast(`❌ Registration failed: ${err.message || 'Please try again.'}`, "danger");
          if (btn) {
            btn.innerHTML = `<span>✨</span> Register as ${CATEGORIES.find(c => c.key === _regCategory)?.label} — Save to MoSPI Database`;
            btn.disabled = false;
          }
        }
      });
    }

    // ======================== 1-CLICK DEMO CARDS ========================
    document.querySelectorAll(".demo-card").forEach(card => {
      card.addEventListener("click", async () => {
        const personaKey = card.getAttribute("data-persona");
        const persona = CONFIG.DEMO_USERS[personaKey];
        if (!persona) return;

        const emailInput = document.getElementById("login-email");
        const pwdInput = document.getElementById("login-password");
        if (emailInput) emailInput.value = persona.email;
        if (pwdInput) pwdInput.value = persona.password;

        store.showToast(`⚡ Signing into MySQL as ${persona.name} (${persona.designation})...`, "info");

        const isLearnerPersona = (personaKey === "official" || personaKey === "senior");
        const targetTab = personaKey === "admin" ? "admin" : isLearnerPersona ? "quiz" : "learner";

        try {
          const res = await API.login(persona.email, persona.password);
          if (res && res.access_token) {
            store.resetSession();
            localStorage.setItem("token", res.access_token);
            store.setState({
              token: res.access_token,
              isAuthenticated: true,
              currentUser: res.user || {
                name: persona.name,
                email: persona.email,
                designation: persona.designation,
                role_name: persona.role
              },
              activePersona: personaKey,
              activeTab: targetTab,
              backendOnline: true
            });

            await refreshBackendData();

            if (isLearnerPersona) {
              store.showToast(`✅ Logged in as ${persona.name} (Learner Officer). Starting Baseline Diagnostic Quiz...`, "success");
              if (window.QuizComponent && window.QuizComponent.startBasicDiagnosticQuiz) {
                await window.QuizComponent.startBasicDiagnosticQuiz();
              } else if (window.switchTab) {
                window.switchTab("quiz");
              }
            } else if (personaKey === "admin") {
              store.showToast(`🛡️ Administrator Access: Welcome Dr. Arun Mehra! Opened NSSTA Admin Console.`, "success");
              if (window.switchTab) window.switchTab("admin");
            } else {
              store.showToast(`💻 Examiner Access: Welcome Priya Nair! Opened Exam Management & Analytics.`, "success");
              if (window.switchTab) window.switchTab("learner");
            }
          }
        } catch (err) {
          store.resetSession();
          store.setState({
            isAuthenticated: true,
            currentUser: {
              name: persona.name,
              email: persona.email,
              designation: persona.designation,
              role_name: persona.role
            },
            activePersona: personaKey,
            activeTab: targetTab
          });

          if (isLearnerPersona) {
            store.showToast(`✅ Demo mode: ${persona.name} (Learner Officer)`, "success");
            if (window.QuizComponent && window.QuizComponent.startBasicDiagnosticQuiz) {
              await window.QuizComponent.startBasicDiagnosticQuiz();
            } else if (window.switchTab) {
              window.switchTab("quiz");
            }
          } else if (personaKey === "admin") {
            store.showToast(`🛡️ Administrator Access: Welcome Dr. Arun Mehra! Opened Admin Console.`, "success");
            if (window.switchTab) window.switchTab("admin");
          } else {
            store.showToast(`💻 Examiner Access: Welcome Priya Nair! Opened Exam Management.`, "success");
            if (window.switchTab) window.switchTab("learner");
          }
        }
      });
    });

    // ======================== JAN PARICHAY SSO ========================
    const btnSso = document.getElementById("btn-jan-parichay-sso");
    if (btnSso) {
      btnSso.addEventListener("click", async () => {
        store.showToast("🔒 Connecting to Jan Parichay (National SSO)...", "info");
        setTimeout(async () => {
          const persona = CONFIG.DEMO_USERS.official;
          try {
            const res = await API.login(persona.email, persona.password);
            if (res && res.access_token) {
              localStorage.setItem("token", res.access_token);
            }
          } catch (e) {}
          store.setState({
            isAuthenticated: true,
            activePersona: "official",
            activeTab: "learner"
          });
          store.showToast("✅ Jan Parichay SSO Token Verified. Welcome Karthikeya Sharma!", "success");
        }, 1200);
      });
    }
  };

  return { render, bindEvents };
})();

window.LoginComponent = LoginComponent;
