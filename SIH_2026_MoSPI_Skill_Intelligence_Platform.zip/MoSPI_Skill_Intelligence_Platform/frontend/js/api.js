/**
 * API Service Layer for connecting with the FastAPI Backend
 * Base URL: http://localhost:8000
 */

const API = (() => {
  const getHeaders = (isJson = true) => {
    const headers = {};
    if (isJson) {
      headers["Content-Type"] = "application/json";
    }
    const token = localStorage.getItem("token");
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }
    return headers;
  };

  const handleResponse = async (response) => {
    if (!response.ok) {
      const errData = await response.json().catch(() => ({ detail: response.statusText }));
      throw new Error(errData.detail || `HTTP Error ${response.status}`);
    }
    return response.json();
  };

  return {
    async checkHealth() {
      try {
        const res = await fetch(`${CONFIG.API_BASE}/health`, { method: "GET" });
        return res.ok;
      } catch (err) {
        return false;
      }
    },

    async login(email, password) {
      const res = await fetch(`${CONFIG.API_BASE}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      return handleResponse(res);
    },

    async register(payload) {
      const res = await fetch(`${CONFIG.API_BASE}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      return handleResponse(res);
    },

    async getProfile() {
      const res = await fetch(`${CONFIG.API_BASE}/profile`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async updateProfile(payload) {
      const res = await fetch(`${CONFIG.API_BASE}/profile`, {
        method: "PUT",
        headers: getHeaders(),
        body: JSON.stringify(payload)
      });
      return handleResponse(res);
    },

    async getSkillGaps() {
      const res = await fetch(`${CONFIG.API_BASE}/skill-gaps`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async updateCompetency(skillId, currentLevel) {
      const res = await fetch(`${CONFIG.API_BASE}/competencies/me`, {
        method: "PUT",
        headers: getHeaders(),
        body: JSON.stringify({ skill_id: skillId, current_level: currentLevel })
      });
      return handleResponse(res);
    },

    async updateCompetenciesBatch(items) {
      const res = await fetch(`${CONFIG.API_BASE}/competencies/me/batch`, {
        method: "PUT",
        headers: getHeaders(),
        body: JSON.stringify(items)
      });
      return handleResponse(res);
    },

    async getRecommendations() {
      const res = await fetch(`${CONFIG.API_BASE}/recommendations`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async getCourses() {
      const res = await fetch(`${CONFIG.API_BASE}/integration/igot/courses`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async getLearnerDashboard() {
      const res = await fetch(`${CONFIG.API_BASE}/dashboard/learner`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async getAdminDashboard() {
      const res = await fetch(`${CONFIG.API_BASE}/dashboard/admin`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async generateQuiz(payload) {
      const res = await fetch(`${CONFIG.API_BASE}/quiz/generate`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(payload)
      });
      return handleResponse(res);
    },

    async submitQuiz(payload) {
      const res = await fetch(`${CONFIG.API_BASE}/quiz/submit`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(payload)
      });
      return handleResponse(res);
    },

    async getAvailableQuizzes() {
      const res = await fetch(`${CONFIG.API_BASE}/quiz/list`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async getQuizDetail(quizId) {
      const res = await fetch(`${CONFIG.API_BASE}/quiz/${quizId}`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async chatWithAssistant(question, context = "") {
      const res = await fetch(`${CONFIG.API_BASE}/assistant/chat`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify({ question, context })
      });
      return handleResponse(res);
    },

    async uploadDocument(file, title) {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("title", title || file.name);

      const res = await fetch(`${CONFIG.API_BASE}/documents/upload`, {
        method: "POST",
        headers: getHeaders(false), // don't set application/json for multipart
        body: formData
      });
      return handleResponse(res);
    },

    async getDbStatus() {
      const res = await fetch(`${CONFIG.API_BASE}/system/db-status`, {
        method: "GET",
        headers: getHeaders()
      });
      return handleResponse(res);
    },

    async calibrateDiagnosticSkills(payload) {
      const res = await fetch(`${CONFIG.API_BASE}/assessment/diagnostic/calibrate`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(payload)
      });
      return handleResponse(res);
    },

    async generateDiagnosticQuiz(payload) {
      const res = await fetch(`${CONFIG.API_BASE}/ai/diagnostic-quiz/generate`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(payload)
      });
      return handleResponse(res);
    },

    async evaluateDiagnosticQuiz(payload) {
      const res = await fetch(`${CONFIG.API_BASE}/ai/diagnostic-quiz/evaluate`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(payload)
      });
      return handleResponse(res);
    }
  };
})();

window.API = API;
