/**
 * Central Reactive State Management for the Platform
 */

class StateStore {
  constructor() {
    this.listeners = [];
    this.state = {
      // Authentication & Profile
      token: localStorage.getItem("token") || null,
      isAuthenticated: !!localStorage.getItem("token"),
      currentUser: {
        name: "Karthikeya Sharma",
        email: "karthikeya@mospi.gov.in",
        designation: "Junior Statistical Officer (JSO)",
        department_name: "National Statistical Systems Training Academy (NSSTA)",
        role_name: "Statistical Officer"
      },
      activePersona: "official", // "official", "analyst", "senior", "admin"
      
      // Current View Navigation
      activeTab: "learner", // "learner", "skill-gap", "quiz", "courses", "assistant", "admin"
      theme: localStorage.getItem("theme") || "light",
      
      // Learner Dashboard Data
      learnerDashboard: null,
      
      // Competency & Gaps
      skills: [],
      domains: [],
      skillGaps: [],
      overallScore: 0,
      
      // Course Recommendations & Catalogue
      recommendations: [],
      courses: [],
      enrolledCourses: [1, 3], // mock pre-enrolled IDs
      
      // Quiz & Assessment Engine
      activeQuiz: null,
      quizAnswers: {},
      quizResult: null,
      isGeneratingQuiz: false,
      
      // AI Assistant Chat
      chatMessages: [
        {
          sender: "assistant",
          text: "Namaste! I am the MoSPI AI Learning Assistant. How may I assist you with your statistical upskilling, iGOT course pathways, or methodological questions today?",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sources: ["MoSPI Training Framework", "iGOT Karmayogi"]
        }
      ],
      
      // Admin Dashboard Data
      adminDashboard: null,
      
      // Live Toast Notifications
      toasts: [],
      
      // Loading & Network State
      isLoading: false,
      backendOnline: true
    };
  }

  getState() {
    return this.state;
  }

  setState(partialState) {
    this.state = { ...this.state, ...partialState };
    this.notify();
  }

  subscribe(listener) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  notify() {
    this.listeners.forEach(listener => listener(this.state));
  }

  resetSession() {
    this.state = {
      ...this.state,
      token: null,
      isAuthenticated: false,
      currentUser: null,
      activePersona: "official",
      learnerDashboard: null,
      adminDashboard: null,
      skills: [],
      domains: [],
      skillGaps: [],
      overallScore: 70,
      recommendations: [],
      courses: [],
      activeQuiz: null,
      quizAnswers: {},
      quizResult: null,
      isGeneratingQuiz: false,
      chatMessages: [
        {
          sender: "assistant",
          text: "Namaste! I am the MoSPI AI Learning Assistant. How may I assist you with your statistical upskilling, iGOT course pathways, or methodological questions today?",
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sources: ["MoSPI Training Framework", "iGOT Karmayogi"]
        }
      ]
    };
    localStorage.removeItem("token");
  }

  logout() {
    this.resetSession();
    this.notify();
    this.showToast("Signed out successfully. Session purged from browser memory.", "info");
  }

  showToast(message, type = "info", duration = 3500) {
    let container = document.getElementById("toast-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "toast-container";
      container.className = "toast-container";
      document.body.appendChild(container);
    }
    const toastElem = document.createElement("div");
    toastElem.className = `toast toast-${type}`;
    const icon = type === "success" ? "✓" : (type === "danger" || type === "error") ? "✕" : type === "warning" ? "⚠️" : "ℹ️";
    toastElem.innerHTML = `
      <span class="toast-icon">${icon}</span>
      <span class="toast-msg">${message}</span>
    `;
    container.appendChild(toastElem);

    setTimeout(() => {
      toastElem.style.opacity = "0";
      toastElem.style.transform = "translateX(20px)";
      toastElem.style.transition = "all 0.3s ease";
      setTimeout(() => toastElem.remove(), 320);
    }, duration);
  }
}

window.store = new StateStore();
