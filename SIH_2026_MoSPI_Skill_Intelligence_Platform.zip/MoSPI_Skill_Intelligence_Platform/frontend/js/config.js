/**
 * AI-Enabled Skill Intelligence & Learning Platform
 * MoSPI / NSSTA / iGOT Karmayogi Hackathon Frontend Configuration
 */

const CONFIG = {
  // FastAPI Backend Base URL
  API_BASE: "http://localhost:8000",

  // Demo User Personas for 1-Click Presentation
  DEMO_USERS: {
    official: {
      email: "karthikeya@mospi.gov.in",
      password: "SecurePassword123!",
      name: "Karthikeya Sharma",
      designation: "Junior Statistical Officer (JSO)",
      department: "National Statistical Systems Training Academy (NSSTA)",
      role: "Statistical Officer",
      roleType: "OFFICIAL"
    },
    analyst: {
      email: "priya.nair@mospi.gov.in",
      password: "SecurePassword123!",
      name: "Priya Nair",
      designation: "Assistant Director / Data Analyst",
      department: "MoSPI - Data Informatics & Innovation Division (DIID)",
      role: "Data Analyst",
      roleType: "OFFICIAL"
    },
    senior: {
      email: "rajesh.verma@mospi.gov.in",
      password: "SecurePassword123!",
      name: "Rajesh Verma",
      designation: "Senior Statistical Officer (SSO)",
      department: "MoSPI - National Accounts Division (NAD)",
      role: "Senior Statistical Officer",
      roleType: "OFFICIAL"
    },
    admin: {
      email: "admin@nssta.gov.in",
      password: "ChangeMe123!",
      name: "Dr. Arun Mehra (Director General)",
      designation: "Head of Academy / System Administrator",
      department: "NSSTA / MoSPI Central Administration",
      role: "admin",
      roleType: "ADMIN"
    }
  },

  // 4 Core Competency Domains in India's Official Statistical System
  DOMAINS: [
    {
      id: "statistical",
      title: "Statistical Competencies",
      icon: "📊",
      description: "Survey Design, Sampling, National Accounts, Price/Labour/Agri Statistics, SDG Indicators, SDMX, and DQAF."
    },
    {
      id: "technical",
      title: "Technical Competencies",
      icon: "💻",
      description: "Python, R, SQL, Stata, SPSS, SAS, Spatial GIS, Power BI, AI/ML Data Quality, and Cloud Big Data."
    },
    {
      id: "digital_governance",
      title: "Digital Governance",
      icon: "🛡️",
      description: "Cybersecurity, DPDP Act 2023 compliance, Digital Signatures, MeghRaj Government Cloud, and DPI."
    },
    {
      id: "behavioural",
      title: "Behavioural & Managerial",
      icon: "🤝",
      description: "Leadership, Statistical Dissemination, Field Project Management, Ethics, and Change Management."
    }
  ],

  // Sample Documents for AI Assessment Generation
  SAMPLE_DOCUMENTS: [
    {
      id: "sample-1",
      title: "NSSO Stratified Multi-Stage Sampling & Estimation Manual",
      category: "Sampling & Methodology",
      content: `The National Sample Survey (NSS) employs a stratified multi-stage sampling design. First Stage Units (FSUs) are Census villages in the rural sector and Urban Frame Survey (UFS) blocks in the urban sector. Ultimate Stage Units (USUs) are households in both sectors. 
Within each district, strata are formed based on population size and agrarian characteristics. In each stratum, FSUs are selected with Probability Proportional to Size with Replacement (PPSWR) or Circular Systematic Sampling.
Household selection within sample FSUs is performed after listing and stratification into affluent and general households to ensure adequate representation of all socioeconomic strata.
Sampling weights (multipliers) are assigned to each sample household: the base weight is inversely proportional to the selection probability. Post-stratification adjustments and ratio-to-benchmark calibrations are applied to align estimated totals with projected census population aggregates, minimizing both sampling variance and non-sampling biases. Non-sampling errors are monitored using the Data Quality Assessment Framework (DQAF).`
    },
    {
      id: "sample-2",
      title: "National Accounts Statistics & GDP Compilation (SNA 2008)",
      category: "National Accounts",
      content: `National Accounts Statistics in India are compiled by the National Accounts Division (NAD) of the Ministry of Statistics and Programme Implementation (MoSPI) in strict conformity with the United Nations System of National Accounts (SNA 2008). 
Gross Domestic Product (GDP) is estimated through both the Production Approach (Gross Value Added at basic prices plus taxes on products less subsidies on products) and the Expenditure Approach (Private Final Consumption Expenditure, Government Final Consumption Expenditure, Gross Fixed Capital Formation, Change in Stocks, Valuables, and Net Exports).
Institutional sectors are categorized into Financial Corporations, Non-Financial Corporations, General Government, Households, and Non-Profit Institutions Serving Households (NPISH).
Supply and Use Tables (SUT) serve as the overarching diagnostic framework to reconcile discrepancy between supply and disposition of commodities. Constant price estimates use base-year pricing with double deflation methodology where practicable, ensuring accurate inflation-adjusted economic growth figures.`
    },
    {
      id: "sample-3",
      title: "Digital Personal Data Protection (DPDP) Act 2023 & Microdata Safeguards",
      category: "Digital Governance",
      content: `The Digital Personal Data Protection Act 2023 establishes comprehensive statutory guidelines for processing citizen personal data in India. For official statistical agencies, including MoSPI and state DES units, the collection of primary survey microdata requires clear purpose limitation, data minimization, and robust anonymization prior to public dissemination.
Under CERT-In and government cybersecurity directives, survey microdata must be encrypted in transit using TLS 1.3 and at rest utilizing AES-256 standard encryption.
Personal identifiers (such as Aadhaar, phone numbers, exact geocoordinates of dwellings) must be masked, perturbed, or stripped using k-anonymity and l-diversity techniques before microdata release to researchers.
Government cloud deployments on MeghRaj must comply with ISO/IEC 27001 data residency and strict role-based access control (RBAC) protocols.`
    }
  ]
};

// Expose globally for browser usage
window.CONFIG = CONFIG;
