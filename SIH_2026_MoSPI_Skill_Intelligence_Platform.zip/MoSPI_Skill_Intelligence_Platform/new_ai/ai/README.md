# Person 2 — GenAI / LLM Module (`ai/`)

This module provides document parsing, quiz generation, and Q&A assistant functions for the backend (Person 5).

## 📁 Directory Structure
```text
ai/
├── __init__.py          # Main exports
├── document_parser.py   # Text & PDF extraction + paragraph chunking
├── quiz_generator.py   # MCQ generation + JSON validation
├── assistant.py        # Q&A grounded in course content
├── prompts.py          # System prompts for Gemini
└── README.md
```

## 🚀 Fast API Integration Guide (For Person 5)

### 1. Import Functions
```python
from ai import extract_text, chunk_text, generate_quiz, answer_question
```

### 2. Usage Examples in FastAPI Endpoints

#### Endpoint: `POST /documents/upload` or `POST /quiz/generate`
```python
# 1. Parse uploaded document
text = extract_text("path/to/file.pdf")  # or .txt

# 2. Generate MCQs
quiz_json = generate_quiz(text, num_questions=5)
# Returns list of dicts:
# [
#   {
#     "question": "...",
#     "options": ["A...", "B...", "C...", "D..."],
#     "answer": "B...",
#     "explanation": "...",
#     "difficulty": "medium"
#   }
# ]
```

#### Endpoint: `POST /assistant/chat`
```python
# Context-grounded Q&A
reply = answer_question(question="What is ISS?", context=text)
```

## ⚙️ Environment Setup
Ensure `GEMINI_API_KEY` is present in your backend `.env` file:
```env
GEMINI_API_KEY=your_gemini_api_key_here
```
