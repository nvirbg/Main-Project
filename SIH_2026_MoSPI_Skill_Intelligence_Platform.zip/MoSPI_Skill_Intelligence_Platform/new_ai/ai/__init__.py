"""Person 2 - GenAI / LLM Lead - AI Services Package
Exposes Document Parser, MCQ Quiz Generator, and MoSPI AI Learning Assistant.
"""
from ai.document_parser import extract_text, infer_file_type, chunk_text
from ai.quiz_generator import generate_quiz
from ai.assistant import answer_question
from ai.prompts import MCQ_SYSTEM_PROMPT, MCQ_USER_PROMPT, ASSISTANT_SYSTEM_PROMPT

__all__ = [
    "extract_text",
    "infer_file_type",
    "chunk_text",
    "generate_quiz",
    "answer_question",
    "MCQ_SYSTEM_PROMPT",
    "MCQ_USER_PROMPT",
    "ASSISTANT_SYSTEM_PROMPT",
]
