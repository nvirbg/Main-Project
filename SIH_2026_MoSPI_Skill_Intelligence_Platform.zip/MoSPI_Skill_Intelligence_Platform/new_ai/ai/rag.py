"""
Lightweight RAG (Retrieval-Augmented Generation) module.
Ranks document chunks by keyword relevance to a user question,
allowing the assistant to handle long documents efficiently.
"""

import re
from .document_parser import chunk_text


def retrieve_relevant_chunks(question, text, top_k=3, chunk_size=1000, overlap=200):
    """
    Splits text into chunks and ranks them by relevance to the question.

    Args:
        question: The user's question.
        text: The full document text.
        top_k: Number of most relevant chunks to return.
        chunk_size: Maximum characters per chunk.
        overlap: Character overlap between chunks.

    Returns:
        Concatenated top-k relevant text chunks.
    """
    chunks = chunk_text(text, chunk_size=chunk_size, overlap=overlap)
    if not chunks:
        return ""

    # Extract keywords (words longer than 2 characters)
    keywords = set(re.findall(r"\w{3,}", question.lower()))

    if not keywords:
        # Fallback to initial chunks if question has no key terms
        return "\n\n---\n\n".join(chunks[:top_k])

    scored_chunks = []
    for chunk in chunks:
        chunk_lower = chunk.lower()
        # Score chunk based on keyword frequency
        score = sum(chunk_lower.count(kw) for kw in keywords)
        scored_chunks.append((score, chunk))

    # Sort chunks by score in descending order
    scored_chunks.sort(key=lambda x: x[0], reverse=True)

    # Return top_k best matching chunks
    best_chunks = [chunk for score, chunk in scored_chunks[:top_k]]
    return "\n\n---\n\n".join(best_chunks)


# Quick test
if __name__ == "__main__":
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

    from ai.document_parser import extract_text

    doc = extract_text("data/sample_learning_material.txt")
    question = "What is Wholesale Price Index?"
    context = retrieve_relevant_chunks(question, doc, top_k=2)

    print(f"Question: {question}")
    print(f"Retrieved Context:\n{context}")
