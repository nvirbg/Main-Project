"""Person 1 - AI/ML Lead - Skill Gap Engine
Analyzes an official's current competencies against role requirements.
"""

def calculate_skill_gaps(user_skills: dict[str, int], role_requirements: dict[str, dict]) -> list[dict]:
    """
    user_skills: {skill_name: current_level (1-5)}
    role_requirements: {skill_name: {"required_level": int, "priority": str ("critical", "high", "medium")}}
    returns list of gaps sorted by priority and gap size
    """
    gaps = []
    priority_weights = {"critical": 3.0, "high": 2.0, "medium": 1.0, "low": 0.5}

    for skill_name, req in role_requirements.items():
        req_level = req.get("required_level", 3)
        priority = req.get("priority", "medium").lower()
        curr_level = user_skills.get(skill_name, 0)
        gap = max(0, req_level - curr_level)

        if gap > 0:
            weight = priority_weights.get(priority, 1.0)
            weighted_score = gap * weight
            gaps.append({
                "skill_name": skill_name,
                "current_level": curr_level,
                "required_level": req_level,
                "gap": gap,
                "priority": priority,
                "weighted_priority": weighted_score,
            })

    gaps.sort(key=lambda x: (x["weighted_priority"], x["gap"]), reverse=True)
    return gaps


def calculate_overall_competency(user_skills: dict[str, int], role_requirements: dict[str, dict]) -> float:
    """Calculates overall readiness percentage against role requirements (0 - 100)."""
    if not role_requirements:
        return 100.0

    total_required = 0
    total_acquired = 0
    for skill_name, req in role_requirements.items():
        req_level = req.get("required_level", 3)
        curr_level = user_skills.get(skill_name, 0)
        total_required += req_level
        total_acquired += min(curr_level, req_level)

    if total_required == 0:
        return 100.0

    return round((total_acquired / total_required) * 100.0, 1)


def get_priority_gaps(gaps: list[dict], top_n: int = 5) -> list[dict]:
    """Returns the top N most urgent skill gaps."""
    return gaps[:top_n]
