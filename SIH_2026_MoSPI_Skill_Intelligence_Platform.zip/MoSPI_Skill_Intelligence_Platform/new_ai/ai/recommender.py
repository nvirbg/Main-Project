"""Person 1 - AI/ML Lead - Course Recommender Engine
Scores courses against skill gaps, role relevance, and TPAC priorities.
"""
import math


def score_course(course: dict, gaps: list[dict], role: str = "", history: list[int] = None) -> tuple[float, str]:
    """
    Computes a composite recommendation score (0.0 to 1.0) and human-readable explanation.
    """
    if not gaps:
        return 0.1, "General professional development course"

    course_skills = set(s.lower() for s in course.get("skills", []))
    course_id = course.get("id")

    # If user already completed this course, deprioritize
    if history and course_id in history:
        return 0.0, "Already completed"

    matched_skills = []
    gap_score = 0.0
    total_gap_weight = sum(g.get("weighted_priority", 1.0) for g in gaps) or 1.0

    for gap in gaps:
        g_name = gap["skill_name"].lower()
        # Direct match or partial match
        if any(g_name in cs or cs in g_name for cs in course_skills):
            matched_skills.append(gap["skill_name"])
            gap_score += gap.get("weighted_priority", 1.0)

    coverage_ratio = gap_score / total_gap_weight

    # TPAC bonus (Official NSSTA training committee recommendation)
    tpac_bonus = 0.20 if course.get("is_tpac_recommended") else 0.0

    # Level fit bonus (if intermediate/advanced matches high gap)
    level_bonus = 0.05 if course.get("level") in ("intermediate", "advanced") else 0.0

    final_score = min(1.0, round(0.70 * coverage_ratio + tpac_bonus + level_bonus, 3))

    explanation = explain_recommendation(course, matched_skills, course.get("is_tpac_recommended", False))
    return final_score, explanation


def explain_recommendation(course: dict, matched_skills: list[str], is_tpac: bool) -> str:
    """Generates transparent rationale for judges and officials."""
    parts = []
    if is_tpac:
        parts.append("[NSSTA TPAC Priority]")

    if matched_skills:
        parts.append(f"Closes critical gaps in: {', '.join(matched_skills[:3])}")
    else:
        parts.append("Broadens statistical and digital governance domain knowledge")

    return " ".join(parts)


def recommend_courses(courses: list[dict], gaps: list[dict], role: str = "", history: list[int] = None, top_n: int = 5) -> list[dict]:
    """Ranks courses and returns top N recommendations with scores and explanations."""
    ranked = []
    for c in courses:
        score, reason = score_course(c, gaps, role, history)
        if score > 0:
            ranked.append({
                "course_id": c.get("id"),
                "title": c.get("title"),
                "provider": c.get("provider", "iGOT Karmayogi"),
                "level": c.get("level", "intermediate"),
                "duration_hours": c.get("duration_hours", 0),
                "is_tpac_recommended": c.get("is_tpac_recommended", False),
                "score": score,
                "reason": reason,
            })

    ranked.sort(key=lambda x: x["score"], reverse=True)
    return ranked[:top_n]
