"""Person 2 - GenAI / LLM Lead - Document Parser
Extracts text from PDF, DOCX, PPTX, and TXT files for MCQ generation.
"""
import os


def infer_file_type(filename: str) -> str:
    """Infers file extension from filename."""
    return os.path.splitext(filename)[1].lstrip(".").lower()


def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 150) -> list[str]:
    """Splits extracted text into clean contextual chunks for LLM processing."""
    if not text or not text.strip():
        return []

    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks = []
    current_chunk = []
    current_length = 0

    for p in paragraphs:
        if current_length + len(p) > chunk_size and current_chunk:
            chunks.append("\n\n".join(current_chunk))
            current_chunk = [p]
            current_length = len(p)
        else:
            current_chunk.append(p)
            current_length += len(p)

    if current_chunk:
        chunks.append("\n\n".join(current_chunk))

    return chunks


def extract_text(file_path: str, file_type: str = None) -> str:
    """Extracts plain text from PDF, DOCX, PPTX, TXT, or MD files."""
    if not file_type:
        file_type = infer_file_type(file_path)
    file_type = file_type.lower().lstrip(".")

    if file_type == "pdf":
        return _extract_pdf(file_path)
    if file_type == "docx":
        return _extract_docx(file_path)
    if file_type == "pptx":
        return _extract_pptx(file_path)
    if file_type in ("txt", "md", ""):
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    raise ValueError(f"Unsupported file type for text extraction: {file_type}")


def _extract_pdf(path: str) -> str:
    # Try pdfplumber first
    try:
        import pdfplumber
        text_chunks = []
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text_chunks.append(page_text)
        if text_chunks:
            return "\n".join(text_chunks)
    except Exception:
        pass

    # Fallback to pypdf
    try:
        import pypdf
        reader = pypdf.PdfReader(path)
        chunks = [page.extract_text() or "" for page in reader.pages]
        return "\n".join(chunks)
    except Exception as exc:
        raise RuntimeError(f"Failed to extract text from PDF: {exc}")


def _extract_docx(path: str) -> str:
    import docx
    doc = docx.Document(path)
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())


def _extract_pptx(path: str) -> str:
    from pptx import Presentation
    prs = Presentation(path)
    chunks = []
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                chunks.append(shape.text)
    return "\n".join(chunks)


__all__ = ["extract_text", "infer_file_type", "chunk_text"]
