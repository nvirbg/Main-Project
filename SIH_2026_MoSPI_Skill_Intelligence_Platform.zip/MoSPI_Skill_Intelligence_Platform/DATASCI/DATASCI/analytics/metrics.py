"""
analytics/metrics.py
--------------------
Lightweight analytics functions for the SIH Data Science competency
dashboard.  All helpers operate on plain Python lists / dicts parsed
from the JSON seed files — no pandas or ML libraries required.
"""

from typing import Any


# ---------------------------------------------------------------------------
# 1. Average Competency
# ---------------------------------------------------------------------------
def average_competency(users: list[dict[str, Any]]) -> dict[str, Any]:
    """Return the organisation-wide average proficiency score (1-5 scale).

    Only users whose ``assessment_status`` is ``"completed"`` (or who have
    at least one skill entry) are included.  Users with empty ``skills``
    lists are skipped gracefully.

    Args:
        users: list of user dicts, each containing a ``skills`` array of
               ``{"skill_id": "SK-xxx", "proficiency": int}`` objects.

    Returns:
        ``{"average": float, "total_users": int, "total_ratings": int,
           "pending_users": int}``
    """
    total_score = 0
    total_ratings = 0
    assessed_users = 0
    pending_users = 0

    for user in users:
        # Skip users who haven't taken the diagnostic quiz yet
        if user.get("assessment_status") == "pending":
            pending_users += 1
            continue
        skills = user.get("skills", [])
        if not skills:
            pending_users += 1
            continue
        for skill in skills:
            total_score += skill.get("proficiency", 0)
            total_ratings += 1
        assessed_users += 1

    average = round(total_score / total_ratings, 2) if total_ratings else 0.0

    return {
        "average": average,
        "total_users": assessed_users,
        "total_ratings": total_ratings,
        "pending_users": pending_users,
    }


# ---------------------------------------------------------------------------
# 2. Top Skill Gaps
# ---------------------------------------------------------------------------
def top_skill_gaps(
    users: list[dict[str, Any]],
    roles_data: list[dict[str, Any]],
    top_n: int = 10,
) -> list[dict[str, Any]]:
    """Identify the largest skill gaps across the workforce.

    For every user, each required skill for their role is compared against
    their current proficiency.  ``gap = required_level - proficiency``
    (clamped to >= 0).  Gaps are aggregated per skill and the top *n* are
    returned sorted descending.

    Args:
        users:      parsed user list (``statistical_officials.json``).
        roles_data: parsed role list (``roles.json``).
        top_n:      number of top gaps to return (default 10).

    Returns:
        Sorted list of ``{"skill_id", "total_gap", "user_count", "avg_gap"}``
        dicts, largest gap first.
    """
    # Build a lookup: role_id -> list of required skill dicts
    role_requirements: dict[str, list[dict]] = {}
    for role in roles_data:
        role_requirements[role["id"]] = role.get("required_skills", [])

    # Aggregate gaps per skill_id
    gap_accumulator: dict[str, dict] = {}  # skill_id -> {total_gap, count}

    for user in users:
        # Skip users who haven't completed the diagnostic assessment
        if user.get("assessment_status") == "pending":
            continue
        role_id = user.get("role_id")
        required_skills = role_requirements.get(role_id, [])

        # Build a quick lookup of the user's current proficiency
        user_proficiency: dict[str, int] = {
            s["skill_id"]: s.get("proficiency", 0)
            for s in user.get("skills", [])
        }

        for req in required_skills:
            sid = req["skill_id"]
            required_level = req.get("required_level", 0)
            current_level = user_proficiency.get(sid, 0)
            gap = max(required_level - current_level, 0)

            if sid not in gap_accumulator:
                gap_accumulator[sid] = {"total_gap": 0, "user_count": 0}

            gap_accumulator[sid]["total_gap"] += gap
            gap_accumulator[sid]["user_count"] += 1

    # Flatten, compute average, sort
    results = []
    for skill_id, data in gap_accumulator.items():
        avg_gap = round(data["total_gap"] / data["user_count"], 2) if data["user_count"] else 0
        results.append({
            "skill_id": skill_id,
            "total_gap": data["total_gap"],
            "user_count": data["user_count"],
            "avg_gap": avg_gap,
        })

    results.sort(key=lambda x: x["total_gap"], reverse=True)
    return results[:top_n]


# ---------------------------------------------------------------------------
# 3. Completion Rate
# ---------------------------------------------------------------------------
def completion_rate(progress_data: list[dict[str, Any]]) -> dict[str, Any]:
    """Calculate course / module completion rate.

    Args:
        progress_data: list of dicts with at least a ``status`` field whose
                       value is one of ``"completed"``, ``"in_progress"``,
                       or ``"not_started"``.

    Returns:
        ``{"completed": int, "in_progress": int, "not_started": int,
           "total": int, "completion_pct": float}``
    """
    counts = {"completed": 0, "in_progress": 0, "not_started": 0}

    for entry in progress_data:
        status = entry.get("status", "not_started").lower()
        if status in counts:
            counts[status] += 1
        else:
            counts["not_started"] += 1

    total = len(progress_data)
    completion_pct = round((counts["completed"] / total) * 100, 1) if total else 0.0

    return {
        **counts,
        "total": total,
        "completion_pct": completion_pct,
    }


# ---------------------------------------------------------------------------
# 4. Average Quiz Score
# ---------------------------------------------------------------------------
def average_quiz_score(quiz_results: list[dict[str, Any]]) -> dict[str, Any]:
    """Compute the average quiz score across all results.

    Args:
        quiz_results: list of dicts each containing at least ``score``
                      (numeric) and ``max_score`` (numeric) fields.

    Returns:
        ``{"average_score": float, "average_pct": float,
           "total_attempts": int, "status": str}``
    """
    if not quiz_results:
        return {
            "average_score": 0.0,
            "average_pct": 0.0,
            "total_attempts": 0,
            "status": "No quiz attempts recorded yet",
        }

    total_score = 0.0
    total_max = 0.0

    for result in quiz_results:
        total_score += result.get("score", 0)
        total_max += result.get("max_score", 0)

    total_attempts = len(quiz_results)
    average_score = round(total_score / total_attempts, 2) if total_attempts else 0.0
    average_pct = round((total_score / total_max) * 100, 1) if total_max else 0.0

    return {
        "average_score": average_score,
        "average_pct": average_pct,
        "total_attempts": total_attempts,
        "status": "ok",
    }


# ---------------------------------------------------------------------------
# 5. Skill Distribution
# ---------------------------------------------------------------------------
def skill_distribution(users: list[dict[str, Any]]) -> dict[str, dict[str, int]]:
    """Count how many users hold each proficiency level for every skill.

    Args:
        users: parsed user list.

    Returns:
        Dict keyed by ``skill_id``, each value being a dict of
        ``{level_str: count}`` e.g.
        ``{"SK-001": {"1": 2, "2": 1, "3": 3, "4": 1, "5": 0}}``.
    """
    distribution: dict[str, dict[str, int]] = {}

    for user in users:
        for skill in user.get("skills", []):
            sid = skill.get("skill_id")
            level = skill.get("proficiency", 0)

            if sid not in distribution:
                distribution[sid] = {"1": 0, "2": 0, "3": 0, "4": 0, "5": 0}

            level_key = str(level)
            if level_key in distribution[sid]:
                distribution[sid][level_key] += 1

    return distribution


# ---------------------------------------------------------------------------
# 6. Category-level Competency Breakdown  (uses competency_framework.json)
# ---------------------------------------------------------------------------
def category_competency_breakdown(
    users: list[dict[str, Any]],
    skills_data: list[dict[str, Any]],
    framework: dict[str, Any] | list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    """Aggregate average proficiency by competency category.

    Maps each skill to its category (from ``skills.json``), then computes
    the average proficiency per category for assessed users.

    Args:
        users:     parsed user list.
        skills_data: parsed skills list (``skills.json``).
        framework: parsed ``competency_framework.json`` — used to ensure
                   every defined category appears in the output, even if
                   no skills have ratings yet.

    Returns:
        Dict keyed by category name, each value:
        ``{"average": float, "total_ratings": int, "description": str}``
    """
    # Build skill_id -> category lookup
    skill_category: dict[str, str] = {}
    for skill in skills_data:
        skill_category[skill["id"]] = skill.get("category", "Uncategorised")

    # Ensure all framework categories appear in output
    categories = framework.get("categories", []) if isinstance(framework, dict) else framework
    result: dict[str, dict[str, Any]] = {}
    for cat in categories:
        cat_name = cat["name"] if isinstance(cat, dict) else str(cat)
        cat_desc = cat.get("description", "") if isinstance(cat, dict) else ""
        result[cat_name] = {"total_score": 0, "total_ratings": 0, "description": cat_desc}

    # Accumulate scores
    for user in users:
        if user.get("assessment_status") == "pending":
            continue
        for skill in user.get("skills", []):
            sid = skill.get("skill_id")
            cat = skill_category.get(sid, "Uncategorised")
            prof = skill.get("proficiency", 0)
            if cat not in result:
                result[cat] = {"total_score": 0, "total_ratings": 0, "description": ""}
            result[cat]["total_score"] += prof
            result[cat]["total_ratings"] += 1

    # Compute averages
    output: dict[str, dict[str, Any]] = {}
    for cat_name, data in result.items():
        avg = round(data["total_score"] / data["total_ratings"], 2) if data["total_ratings"] else 0.0
        output[cat_name] = {
            "average": avg,
            "total_ratings": data["total_ratings"],
            "description": data["description"],
        }

    return output


# ---------------------------------------------------------------------------
# 7. NSSTA Training Recommendations  (uses nssta_training.json)
# ---------------------------------------------------------------------------
def recommend_nssta_programs(
    users: list[dict[str, Any]],
    nssta_programs: list[dict[str, Any]],
    skills_data: list[dict[str, Any]],
    roles_data: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Recommend NSSTA training programs based on workforce skill gaps and roles.

    Matching is done in two ways:
    1. **Role/audience match** — the program's ``target_audience`` is matched
       against the officers' designations (e.g. Probationers vs. Directors).
    2. **Skill-gap match** — the program's ``skills_covered`` are matched
       against the top skill gaps identified across the workforce.

    Args:
        users:          parsed user list.
        nssta_programs: parsed ``nssta_training.json``.
        skills_data:    parsed ``skills.json`` (maps skill IDs to names).
        roles_data:     parsed ``roles.json``.

    Returns:
        List of recommendation dicts, each containing the program info plus
        ``match_reason`` and ``matched_officers_count``.
    """
    # Build skill name -> id lookup
    skill_name_to_id: dict[str, str] = {}
    for skill in skills_data:
        skill_name_to_id[skill["name"].lower()] = skill["id"]

    # Identify top skill gaps (by name)
    gap_results = top_skill_gaps(users, roles_data, top_n=30)
    gap_skill_ids = {g["skill_id"] for g in gap_results}

    # Build designation-based audience counts
    audience_counts: dict[str, int] = {}
    for user in users:
        desig = user.get("designation", "").lower()
        audience_counts[desig] = audience_counts.get(desig, 0) + 1

    recommendations = []
    for program in nssta_programs:
        match_reasons = []
        matched_count = 0

        # --- Audience matching ---
        target = program.get("target_audience", "").lower()
        for desig, count in audience_counts.items():
            # Fuzzy match: check if target audience appears within designation
            if target and (target in desig or desig in target):
                match_reasons.append(f"Audience match: {count} officers with designation '{desig}'")
                matched_count += count

        # --- Skill gap matching ---
        covered = program.get("skills_covered", [])
        matched_skills = []
        for skill_name in covered:
            sid = skill_name_to_id.get(skill_name.lower())
            if sid and sid in gap_skill_ids:
                matched_skills.append(skill_name)
        if matched_skills:
            match_reasons.append(f"Addresses skill gaps: {', '.join(matched_skills)}")

        recommendations.append({
            "program_id": program.get("id"),
            "program_name": program.get("program_name"),
            "target_audience": program.get("target_audience"),
            "duration_days": program.get("duration_days"),
            "skills_covered": covered,
            "match_reasons": match_reasons if match_reasons else ["No direct match — general enrichment"],
            "matched_officers_count": matched_count,
        })

    # Sort: programs with skill gap matches first, then by officer count
    recommendations.sort(
        key=lambda r: (len(r["match_reasons"]) > 1, r["matched_officers_count"]),
        reverse=True,
    )
    return recommendations


# ---------------------------------------------------------------------------
# Quick smoke-test when run directly
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import json
    import os

    DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data")

    def _load(filename: str):
        path = os.path.join(DATA_DIR, filename)
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _load_users():
        """Load users with backward compatibility."""
        primary = os.path.join(DATA_DIR, "statistical_officials.json")
        fallback = os.path.join(DATA_DIR, "mock_users.json")
        target = primary if os.path.exists(primary) else fallback
        print(f"  Loading users from: {os.path.basename(target)}")
        with open(target, "r", encoding="utf-8") as f:
            return json.load(f)

    users = _load_users()
    roles = _load("roles.json")
    skills = _load("skills.json")
    framework = _load("competency_framework.json")
    nssta_programs = _load("nssta_training.json")

    # --- Assessment Status ---
    assessed = sum(1 for u in users if u.get("assessment_status") == "completed")
    pending = sum(1 for u in users if u.get("assessment_status") == "pending")
    print(f"=== Assessment Status ===")
    print(f"  Total officers: {len(users)}")
    print(f"  Assessed:       {assessed}")
    print(f"  Pending:        {pending}")

    # --- Average Competency ---
    print("\n=== Average Competency ===")
    print(average_competency(users))

    # --- Category Competency Breakdown ---
    print("\n=== Competency by Category ===")
    breakdown = category_competency_breakdown(users, skills, framework)
    if any(v["total_ratings"] > 0 for v in breakdown.values()):
        for cat, info in breakdown.items():
            print(f"  {cat}: avg={info['average']}  ratings={info['total_ratings']}")
    else:
        print("  No assessed data yet — category breakdowns will appear after diagnostic quizzes.")
    for cat, info in breakdown.items():
        if info["description"]:
            print(f"    -> {cat}: {info['description'][:80]}...")

    # --- Top Skill Gaps ---
    print("\n=== Top Skill Gaps ===")
    gaps = top_skill_gaps(users, roles, top_n=5)
    if gaps:
        for gap in gaps:
            print(f"  {gap['skill_id']}: total_gap={gap['total_gap']}  "
                  f"avg_gap={gap['avg_gap']}  users={gap['user_count']}")
    else:
        print("  No assessed users yet — skill gaps will appear after diagnostic quizzes.")

    # --- Skill Distribution ---
    print("\n=== Skill Distribution (first 3) ===")
    dist = skill_distribution(users)
    if dist:
        for sid in list(dist.keys())[:3]:
            print(f"  {sid}: {dist[sid]}")
    else:
        print("  No skill data yet — awaiting diagnostic assessments.")

    # --- Completion Rate ---
    print("\n=== Completion Rate ===")
    progress_data = []
    for user in users:
        status = user.get("assessment_status", "pending")
        if status == "completed":
            progress_data.append({"user_id": user["id"], "status": "completed"})
        elif status == "in_progress":
            progress_data.append({"user_id": user["id"], "status": "in_progress"})
        else:
            progress_data.append({"user_id": user["id"], "status": "not_started"})
    print(completion_rate(progress_data))

    # --- Average Quiz Score ---
    print("\n=== Average Quiz Score ===")
    all_quiz_attempts = []
    for user in users:
        for attempt in user.get("quiz_attempts", []):
            all_quiz_attempts.append(attempt)
    print(average_quiz_score(all_quiz_attempts))

    # --- NSSTA Training Recommendations ---
    print("\n=== NSSTA Training Recommendations ===")
    recs = recommend_nssta_programs(users, nssta_programs, skills, roles)
    for rec in recs:
        print(f"\n  [{rec['program_id']}] {rec['program_name']}")
        print(f"    Target: {rec['target_audience']}  |  Duration: {rec['duration_days']} days")
        print(f"    Skills: {', '.join(rec['skills_covered'])}")
        for reason in rec["match_reasons"]:
            print(f"    -> {reason}")
        if rec["matched_officers_count"] > 0:
            print(f"    Officers matched: {rec['matched_officers_count']}")
