import glob
import json
import os
import pandas as pd

# ---------------------------------------------------------------------------
# Resolve paths relative to THIS script, not the working directory.
# This prevents the 0-record bug when running from a different CWD.
# ---------------------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, 'data')

# Find all CSV files inside the data folder
csv_files = glob.glob(os.path.join(DATA_DIR, '*.csv'))
json_path = os.path.join(DATA_DIR, 'statistical_officials.json')

all_users = []
seen_names = set()  # To prevent duplicate entries across different files
user_counter = 1

for file_path in csv_files:
    # Skip output files if any happen to be in the folder
    if 'mock' in os.path.basename(file_path).lower():
        continue
    if 'statistical_officials' in os.path.basename(file_path).lower():
        continue
        
    print(f"Cleaning and processing {file_path}...")
    try:
        df = pd.read_csv(file_path)
        # Strip whitespace from column names
        df.columns = df.columns.str.strip()
        
        # Drop rows where the name column is completely empty/null
        if 'name' in df.columns:
            df = df.dropna(subset=['name'])
            
        for _, row in df.iterrows():
            # Clean name string
            name = str(row.get('name', '')).strip()
            
            # Filter out unwanted metadata rows, headers, or NaNs
            if not name or name.lower() in ['nan', 'none', 'unnamed', 'name', 's.no']:
                continue
                
            # Normalize name formatting and check for duplicates
            name_clean = ' '.join(name.split()).title()
            if name_clean in seen_names:
                continue
            seen_names.add(name_clean)
            
            # Standardize gender formatting
            raw_gender = str(row.get('gender', '')).strip().upper()
            if raw_gender in ['F', 'FEMALE']:
                gender = "Female"
            elif raw_gender in ['M', 'MALE']:
                gender = "Male"
            else:
                gender = "Not Specified"
            
            # Clean designation and batch fields
            designation = str(row.get('designation', 'Statistical Official')).strip()
            if designation.lower() in ['nan', 'none', '']:
                designation = "Statistical Official"
                
            batch = str(row.get('batch_name', row.get('category', 'Standard Batch'))).strip()
            if batch.lower() in ['nan', 'none', '']:
                batch = "General Batch"
            
            # Dynamic role assignment based on designation
            desig_upper = designation.upper()
            if any(kw in desig_upper for kw in ['DIRECTOR', 'ASST. DIRECTOR', 'ASSISTANT DIRECTOR']):
                role_id = "ROLE-DIRECTOR"
            elif any(kw in desig_upper for kw in ['ISS (P)', 'PROBATIONER', 'ISS PROBATIONER']):
                role_id = "ROLE-PROBATIONER"
            else:
                role_id = "ROLE-OFFICER"

            all_users.append({
                "id": f"NSSTA-OFFICER-{user_counter}",
                "name": name_clean,
                "gender": gender,
                "designation": designation,
                "batch": batch,
                "role_id": role_id,
                "skills": [],  # Populated after diagnostic quiz
                "assessment_status": "pending",
                "assessment_completed": False,
                "quiz_attempts": []
            })
            user_counter += 1
            
    except Exception as e:
        print(f"Error processing {file_path}: {e}")

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

# Save clean combined records to statistical_officials.json
with open(json_path, 'w', encoding='utf-8') as f:
    json.dump(all_users, f, indent=2)

print(f"\nSuccessfully cleaned and combined into {len(all_users)} unique, high-quality records in '{json_path}'!")