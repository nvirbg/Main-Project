import json
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def load_json_file(filename):
    """Safely loads a JSON file from the data directory."""
    filepath = os.path.join(BASE_DIR, filename)
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Error: Could not find {filename}")
        return []
    except json.JSONDecodeError:
        print(f"Error: {filename} is not valid JSON")
        return []

def get_all_seed_data():
    """Loads all prototype datasets for the backend database seed."""
    return {
        "skills": load_json_file('skills.json'),
        "roles": load_json_file('roles.json'),
        "courses": load_json_file('courses.json'),
        "competency_framework": load_json_file('competency_framework.json'),
        "nssta_training": load_json_file('nssta_training.json'),
    }

def load_users():
    """Load statistical officials with backward compatibility.

    Tries ``statistical_officials.json`` first; falls back to
    ``mock_users.json`` if the new file hasn't been generated yet.
    """
    primary = os.path.join(BASE_DIR, 'statistical_officials.json')
    fallback = os.path.join(BASE_DIR, 'mock_users.json')
    target = primary if os.path.exists(primary) else fallback
    try:
        with open(target, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Error loading users: {e}")
        return []

if __name__ == "__main__":
    print("Testing data loading...")
    data = get_all_seed_data()
    print(f"Loaded {len(data['skills'])} skills")
    print(f"Loaded {len(data['roles'])} roles")
    print(f"Loaded {len(data['courses'])} courses")
    framework = data['competency_framework']
    cats = framework.get('categories', []) if isinstance(framework, dict) else framework
    print(f"Loaded {len(cats)} competency categories")
    print(f"Loaded {len(data['nssta_training'])} NSSTA training programs")

    users = load_users()
    print(f"Loaded {len(users)} statistical officials")