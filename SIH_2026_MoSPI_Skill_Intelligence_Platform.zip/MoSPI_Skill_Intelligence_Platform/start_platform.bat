@echo off
title AI-Enabled Skill Intelligence & Learning Platform (MoSPI / iGOT)
color 0A

echo ======================================================================
echo   MoSPI & iGOT Karmayogi - AI Skill Intelligence & Learning Platform
echo   Smart India Hackathon (SIH) 2026
echo ======================================================================
echo.

cd /d "%~dp0sih_backend\sih_backend"

set PY_CMD=python
if exist "venv\Scripts\python.exe" (
    set PY_CMD=.\venv\Scripts\python.exe
    echo [*] Using project virtual environment (venv)
) else (
    echo [*] Using system Python environment
)

echo [*] Launching FastAPI Backend on http://localhost:8000 ...
echo [*] Frontend is mounted at http://localhost:8000/
echo [*] Interactive API Docs: http://localhost:8000/docs
echo.

:: Open default browser after a short delay
start "" cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:8000"

%PY_CMD% -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload

pause
