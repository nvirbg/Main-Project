# Security & RBAC Architecture Specification

**Project:** AI-Enabled Skill Intelligence & Learning Platform  
**Target Organization:** Ministry of Statistics & Programme Implementation (MoSPI) / NSSTA  
**Standard Compliance:** CERT-In Cybersecurity Directives, Digital Personal Data Protection (DPDP) Act 2023, MeghRaj GI Cloud Guidelines  
**Author:** Person 4 — Cybersecurity Lead  

---

## 1. Executive Summary

This document establishes the defense-in-depth security framework for the AI-Enabled Skill Intelligence & Learning Platform. Designed for India's Official Statistical System, the architecture enforces rigorous identity verification, least-privilege role-based authorization, cryptographic token management, comprehensive audit logging, and strict data sanitization for survey microdata and assessment materials.

---

## 2. Authentication Architecture & Token Lifecycle

### 2.1 Cryptographic Algorithms & Standards
- **Password Storage:** Salted and hashed using `bcrypt` (work factor $\ge 12$). Passwords are never logged or transmitted in plain text.
- **Token Signing:** JSON Web Tokens (JWT) signed via HMAC-SHA256 (`HS256`) using high-entropy secrets loaded exclusively from server environment variables (`.env`).
- **Token Nonce:** Every token embeds a cryptographic unique identifier (`jti` claim via UUIDv4) preventing token collision or replay attacks.

### 2.2 Token Expiration & Rotation Policy
- **Access Tokens:** Short-lived (30 minutes expiry) to minimize vulnerability windows if compromised in transit.
- **Refresh Tokens:** Long-lived (7 days expiry), persisted in the database `refresh_tokens` table.
- **Rotation Mechanism:** Each call to `/auth/refresh` revokes the old refresh token (`revoked = True`) and issues an atomic new access + refresh pair. Revoked tokens cannot be reused.

```mermaid
sequenceDiagram
    participant Client as Frontend Browser
    participant API as FastAPI Gateway
    participant DB as MySQL Database

    Client->>API: POST /auth/login (email, password)
    API->>DB: Query official & verify bcrypt hash
    API->>API: Generate Access Token (30m) & Refresh Token (7d)
    API->>DB: Insert RefreshToken record
    API-->>Client: 200 OK {access_token, refresh_token}
    
    Note over Client,API: Subsequent Requests Include Header: Authorization: Bearer <access_token>
```

---

## 3. Role-Based Access Control (RBAC) Matrix

The platform classifies users into three canonical administrative tiers, enforced at the routing layer via FastAPI dependency injection (`app.deps::require_roles`):

| Resource / Endpoint | HTTP Method | Minimum Role Required | Security Constraint |
| :--- | :--- | :--- | :--- |
| `/auth/login`, `/auth/register` | `POST` | Public / Anonymous | Rate-limited, schema-validated |
| `/profile` | `GET`, `PUT` | `OFFICIAL` | Restricted to authenticated self |
| `/skill-gaps` | `GET` | `OFFICIAL` | Evaluates gaps against user's target role |
| `/recommendations` | `GET` | `OFFICIAL` | Tailored to user's identified skill gaps |
| `/courses`, `/integration/igot/courses` | `GET` | Authenticated / Public | Read-only course catalog |
| `/documents/upload` | `POST` | `OFFICIAL` / `TRAINER` | Validated MIME type, max 25MB limit |
| `/quiz/generate` | `POST` | `OFFICIAL` / `TRAINER` | Sanitized prompt input, JSON output verification |
| `/quiz/submit` | `POST` | `OFFICIAL` | Atomic attempt logging and score computation |
| `/dashboard/learner` | `GET` | `OFFICIAL` | Scoped exclusively to current user |
| `/dashboard/admin` | `GET` | `ADMIN` | Organization-wide aggregated analytics |
| `/audit-logs` | `GET` | `ADMIN` | Immutable compliance tracking log |

---

## 4. Input Validation & Content Protection

1. **File Upload Hardening:**
   - Whitelist of permitted extensions: `.pdf`, `.docx`, `.pptx`, `.txt`, `.md`.
   - Explicit payload size threshold: enforced at 25MB (`MAX_UPLOAD_MB`).
   - File renaming: Uploaded files are stored with random UUIDv4 prefixes (`uuid.uuid4().hex_{filename}`) to eliminate directory traversal attacks (`../`).
2. **LLM Output Sanitization:**
   - AI-generated assessment questions are strictly parsed using JSON schema validators.
   - Any raw markdown or triple backtick fences are stripped prior to storage.
   - Fallback deterministic generator activates if parsing fails or rate limits are encountered.

---

## 5. Tamper-Proof Audit Logging

Every critical platform event generates an immutable record in the `audit_logs` table:
- **Captured Fields:** `id`, `official_id`, `action` (e.g. `LOGIN`, `COMPETENCY_UPDATE`, `QUIZ_GENERATE`), `entity_type`, `entity_id`, `details` (JSON), `ip_address`, `timestamp`.
- **Retention Policy:** Retained for $\ge 3$ years in accordance with government audit compliance.

---

## 6. Government Cloud & DPDP Act 2023 Alignment

1. **Data Residency:** All data stored within sovereign Indian cloud infrastructure (MeghRaj / NIC).
2. **Microdata Privacy:** Primary survey microdata is masked using $k$-anonymity principles; no personal citizen identifiers are exposed in LLM prompts or client responses.
3. **Transport Security:** All communication encrypted with TLS 1.3 in transit and AES-256 at rest.
