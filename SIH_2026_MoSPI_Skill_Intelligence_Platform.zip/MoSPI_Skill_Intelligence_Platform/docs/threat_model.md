# STRIDE Threat Model & Risk Mitigation Matrix

**Platform:** AI-Enabled Skill Intelligence & Learning Platform (MoSPI / NSSTA)  
**Methodology:** STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege)  
**Author:** Person 4 — Cybersecurity Lead  

---

## 1. Threat Identification & Mitigation Matrix

| Threat Category (STRIDE) | Specific Attack Vector | Potential Impact | Architecture Mitigation | Status |
| :--- | :--- | :--- | :--- | :--- |
| **Spoofing Identity** | Attacker impersonates an official or administrator using forged credentials or stolen JWTs. | Unauthorized access to personnel competency profiles and administrative analytics. | 1. Salted bcrypt password hashing.<br>2. Short-lived (30m) access tokens.<br>3. Unique cryptographic `jti` nonces preventing token reuse.<br>4. Prepared for Jan Parichay National SSO. | **Mitigated** |
| **Tampering with Data** | Official alters competency scores directly via intercepted API calls. | Inflated readiness scores resulting in unqualified promotion or pathway bypass. | 1. Server-side validation of all score calculations in `ai/skill_gap.py`.<br>2. Parameter bounds checking (current level $0 \le x \le 5$).<br>3. Assessment scores generated and stored atomically by the backend. | **Mitigated** |
| **Repudiation** | User denies having taken an assessment, altered competency, or accessed confidential documents. | Lack of accountability in government workforce evaluation. | 1. Centralized immutable `audit_logs` capturing user ID, IP address, timestamp, and action payload.<br>2. Read-only access to audit logs restricted strictly to administrators. | **Mitigated** |
| **Information Disclosure** | Leakage of citizen survey microdata or employee evaluation records. | Breach of Digital Personal Data Protection (DPDP) Act 2023 and citizen trust. | 1. TLS 1.3 enforced for all transmission.<br>2. Role-scoped endpoint serialization (`OfficialOut`, `CompetencyOut`).<br>3. API keys stored strictly in `.env`, never in frontend code. | **Mitigated** |
| **Denial of Service (DoS)** | Malicious user uploads massive files to exhaust server disk space and RAM. | API latency, server crashes, disruption of academy training operations. | 1. Strict 25MB upload ceiling enforced at gateway.<br>2. Memory-efficient streaming file parser.<br>3. Rate limiting and CORS restrictions on public endpoints. | **Mitigated** |
| **Elevation of Privilege** | Statistical Officer attempts to access Administrator Workforce Dashboard or modify role permissions. | Unauthorized visibility into organization-wide capacity and administrative configurations. | 1. Route-level authorization using `require_roles("admin")` dependency.<br>2. Case-insensitive cryptographic role verification on every protected request. | **Mitigated** |

---

## 2. Production Security Hardening Roadmap

1. **Jan Parichay (National SSO) Federation:**
   - Implement OpenID Connect (OIDC) authentication with National Informatics Centre (NIC) Single Sign-On.
2. **Automated Security Scanning:**
   - Integrate SAST/DAST scanning (e.g., OWASP ZAP, Bandit) into the CI/CD deployment pipeline.
3. **Database Encryption:**
   - Enable Transparent Data Encryption (TDE) for all MySQL tablespaces hosting employee records.
4. **WAF & Rate Limiting:**
   - Deploy behind a reverse proxy (Nginx / Cloudflare) with rate-limiting at 100 req/min per IP to prevent brute-force attacks.
