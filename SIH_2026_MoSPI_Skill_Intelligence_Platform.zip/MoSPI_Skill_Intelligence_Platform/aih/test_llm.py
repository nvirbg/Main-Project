from ai.question_generator import generate_questions


skills = [
    "SK-001",
    "SK-005",
    "SK-011"
]

questions = generate_questions(
    skills=skills,
    role="Statistical Officer",
    num_questions=3
)

print("\n========== GENERATED QUESTIONS ==========\n")

for question in questions["questions"]:
    print("ID:", question["id"])
    print("Question:", question["question"])
    print("Options:", question["options"])
    print("Correct:", question["correct_answer"])
    print("Skill:", question["skill"])
    print()