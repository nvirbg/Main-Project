# AI Competency & Learning Recommendation Engine

AI-powered competency assessment and course recommendation system for official government statistical workflows.

## Features
- **Competency Gap Analysis**: Computes proficiency levels, gap scores, and role priorities.
- **Course Recommender**: Intelligent ranking of courses based on target skills, difficulty fit, and domain relevance.
- **LLM-Powered Question Generator**: Dynamically generates role-based multiple-choice assessment questions using Groq / LLMs.
- **FastAPI Endpoints**: Full REST API for user analysis, on-demand assessment generation, and submission.

---

## Project Structure
```text
├── ai/
│   ├── assessment.py         # Evaluates assessment answers into skill levels
│   ├── engine.py             # Main pipeline connecting gaps to recommendations
│   ├── question_generator.py # Dynamic question generation via LLM
│   ├── recommender.py        # Course ranking and scoring algorithm
│   └── skill_gap.py          # Skill gap calculations and competency scoring
├── api/
│   └── main.py               # FastAPI backend with REST endpoints
├── data/
│   ├── course_metadata.json
│   ├── courses.json
│   ├── questions.json
│   ├── role_priorities.json
│   ├── roles.json
│   ├── skills.json
│   └── users.json
├── tests/
│   ├── test_assessment.py
│   ├── test_engine.py
│   ├── test_recommendation.py
│   └── test_skill_gap.py
├── test_assessment_now.py
├── test_engine_now.py
├── test_llm.py
├── test_adaptive.py
├── requirements.txt
├── .env.example
└── README.md
```

---

## Setup & Installation

### 1. Clone & create virtual environment
```bash
git clone <your-repo-url>
cd sih
python -m venv venv
# On Windows:
.\venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure environment variables
Copy `.env.example` to `.env`:
```bash
copy .env.example .env
```
Add your free Groq API key:
```env
GROQ_API_KEY=gsk_your_groq_api_key_here
```

---

## Running the API
Start the FastAPI development server:
```bash
uvicorn api.main:app --reload
```
Interactive API docs are available at `http://127.0.0.1:8000/docs`.

---

## Running Tests & Scripts
- **Test LLM Question Generation**:
  ```bash
  python test_llm.py
  ```
- **Test AI Recommendation Engine**:
  ```bash
  python test_engine_now.py
  ```
- **Test Assessment Flow**:
  ```bash
  python test_assessment_now.py
  ```
