import json

from ai.engine import analyze_user

with open("data/roles.json") as f:
    roles = json.load(f)

with open("data/courses.json") as f:
    courses = json.load(f)

user = {
    "id": "U001",
    "name": "Demo Statistical Officer",
    "role": "Statistical Officer",
    "skills": {
        "SK-001": 2,
        "SK-005": 2,
        "SK-011": 1
    },
    "completed_courses": []
}

role = roles[0]

result = analyze_user(
    user,
    role,
    courses
)

assert "overall_competency" in result
assert "skill_gaps" in result
assert "priority_gaps" in result
assert "recommendations" in result

print("Engine tests passed!")