import json
from ai.skill_gap import calculate_skill_gaps
from ai.recommender import recommend_courses

with open("data/roles.json") as f:
    roles = json.load(f)

with open("data/courses.json") as f:
    courses = json.load(f)

role = roles[0]

user_skills = {
    "SK-001": 2,
    "SK-005": 2,
    "SK-011": 1
}

gaps = calculate_skill_gaps(
    user_skills,
    role["required_skills"]
)

recommendations = recommend_courses(
    courses,
    gaps,
    role["name"],
    [],
    top_n=5
)

assert len(recommendations) > 0
assert recommendations[0]["score"] > 0
assert "reason" in recommendations[0]

print("Recommendation tests passed!")