from ai.skill_gap import calculate_skill_gaps, get_priority_gaps

user_skills = {
    "SK-001": 2,
    "SK-005": 2,
    "SK-011": 1
}

role_requirements = [
    {"skill_id": "SK-001", "required_level": 4, "priority": 1.0},
    {"skill_id": "SK-005", "required_level": 3, "priority": 0.8},
    {"skill_id": "SK-011", "required_level": 2, "priority": 0.7}
]

gaps = calculate_skill_gaps(user_skills, role_requirements)
priority_gaps = get_priority_gaps(gaps)

assert gaps[0]["gap"] == 2
assert gaps[1]["gap"] == 1
assert gaps[2]["gap"] == 1

assert priority_gaps[0]["skill_id"] == "SK-001"

print("Skill gap tests passed!")