from ai.assessment import (
    evaluate_assessment,
    assessment_to_skills
)

questions = [
    {
        "id": "Q001",
        "question": "Test question",
        "options": ["A", "B", "C", "D"],
        "correct_answer": "A",
        "skill": "SK-001"
    },
    {
        "id": "Q002",
        "question": "Test question",
        "options": ["A", "B", "C", "D"],
        "correct_answer": "B",
        "skill": "SK-005"
    }
]

answers = {
    "Q001": "A",
    "Q002": "B"
}

result = evaluate_assessment(answers, questions)

skills = assessment_to_skills(answers, questions)

assert result["overall_score"] == 100
assert result["correct_answers"] == 2
assert skills["SK-001"] == 5
assert skills["SK-005"] == 5

print("Assessment tests passed!")