# pyrefly: ignore [missing-import]
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from ai.engine import analyze_user
from ai.assessment import assessment_to_skills
from ai.question_generator import generate_questions

import json


app = FastAPI()
# Stores active assessment sessions
# assessment_id -> generated questions
assessment_sessions = {}


# -----------------------------
# Load datasets
# -----------------------------

with open("data/users.json", "r") as f:
    users = json.load(f)

with open("data/roles.json", "r") as f:
    roles = json.load(f)

with open("data/courses.json", "r") as f:
    courses = json.load(f)


# -----------------------------
# Health check
# -----------------------------

@app.get("/health")
def health_check():
    return {
        "status": "AI service is running"
    }


# -----------------------------
# Analyze existing user
# -----------------------------

@app.get("/analyze/{user_id}")
def analyze(user_id: str):

    user = next(
        (u for u in users if u["id"] == user_id),
        None
    )

    if user is None:
        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    role = next(
        (r for r in roles if r["name"] == user["role"]),
        None
    )

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role not found"
        )

    result = analyze_user(
        user,
        role,
        courses
    )

    return result


# -----------------------------
# Analyze custom user
# -----------------------------

class AnalyzeRequest(BaseModel):
    user_id: str
    role: str
    skills: dict
    completed_courses: list = []


@app.post("/analyze")
def analyze_post(request: AnalyzeRequest):

    user = {
        "id": request.user_id,
        "name": request.user_id,
        "role": request.role,
        "skills": request.skills,
        "completed_courses": request.completed_courses
    }

    role = next(
        (r for r in roles if r["name"] == request.role),
        None
    )

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role not found"
        )

    result = analyze_user(
        user,
        role,
        courses
    )

    return result


# -----------------------------
# Assessment
# -----------------------------

class AssessmentRequest(BaseModel):
    user_id: str
    role: str
    answers: dict
    completed_courses: list = []


@app.post("/assess")
def assess_user(request: AssessmentRequest):

    # Load assessment questions
    with open("data/questions.json", "r") as f:
        questions = json.load(f)

    # Convert answers into skill levels
    skills = assessment_to_skills(
        request.answers,
        questions
    )

    role = next(
        (r for r in roles if r["name"] == request.role),
        None
    )

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role not found"
        )

    user = {
        "id": request.user_id,
        "name": request.user_id,
        "role": request.role,
        "skills": skills,
        "completed_courses": request.completed_courses
    }

    result = analyze_user(
        user,
        role,
        courses
    )

    return {
        "assessment_skills": skills,
        "analysis": result
    }


# -----------------------------
# Generate AI Assessment
# -----------------------------

# -----------------------------
# Generate AI Assessment
# -----------------------------

class GenerateAssessmentRequest(BaseModel):
    user_id: str
    role: str
    num_questions: int = 10


@app.post("/generate-assessment")
def generate_assessment(request: GenerateAssessmentRequest):

    # Find the selected role
    role = next(
        (r for r in roles if r["name"] == request.role),
        None
    )

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role not found"
        )

    # Get required skill IDs for this role
    skill_ids = [
        skill["skill_id"]
        for skill in role["required_skills"]
    ]

    # Generate questions using LLM
    generated = generate_questions(
        skill_ids=skill_ids,
        role=request.role,
        num_questions=request.num_questions
    )

    questions = generated["questions"]

    # Create a simple assessment ID
    assessment_id = f"{request.user_id}_assessment"

    # Store questions privately
    assessment_sessions[assessment_id] = {
        "user_id": request.user_id,
        "role": request.role,
        "questions": questions
    }

    # Remove correct answers before sending to frontend
    public_questions = []

    for question in questions:
        public_questions.append({
            "id": question["id"],
            "question": question["question"],
            "options": question["options"],
            "skill": question["skill"]
        })

    return {
        "assessment_id": assessment_id,
        "user_id": request.user_id,
        "role": request.role,
        "questions": public_questions
    }

# -----------------------------
# Submit AI Assessment
# -----------------------------

class SubmitAssessmentRequest(BaseModel):
    assessment_id: str
    answers: dict
    completed_courses: list = []


@app.post("/submit-assessment")
def submit_assessment(request: SubmitAssessmentRequest):

    # Find the assessment session
    session = assessment_sessions.get(
        request.assessment_id
    )

    if session is None:
        raise HTTPException(
            status_code=404,
            detail="Assessment not found"
        )

    # Get the exact questions that were generated
    questions = session["questions"]

    # Convert answers into skill levels
    skills = assessment_to_skills(
        request.answers,
        questions
    )

    # Find the role
    role = next(
        (
            r for r in roles
            if r["name"] == session["role"]
        ),
        None
    )

    if role is None:
        raise HTTPException(
            status_code=404,
            detail="Role not found"
        )

    # Create user profile using assessment results
    user = {
        "id": session["user_id"],
        "name": "Demo Statistical Officer",
        "role": session["role"],
        "skills": skills,
        "completed_courses": request.completed_courses
    }

    # Run skill-gap + recommendation engine
    result = analyze_user(
        user,
        role,
        courses
    )

    return {
        "assessment_id": request.assessment_id,
        "assessment_skills": skills,
        "analysis": result
    }