import json
import os

def _find_data_file(filename):
    candidates = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", filename),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", filename),
        os.path.join(os.getcwd(), "data", filename),
        os.path.join(os.getcwd(), "aih", "data", filename),
        os.path.join(os.getcwd(), "sih_backend", "sih_backend", "data", filename),
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return os.path.join("data", filename)

def load_course_metadata():
    """
    Load role relevance and future demand
    information for courses.
    """
    path = _find_data_file("course_metadata.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def calculate_skill_match(course, skill_gaps):
    """
    Measures how well a course addresses the learner's
    current skill gaps.
    """

    total_priority_gap = 0
    matched_priority_gap = 0

    course_skills = course.get("skills", [])

    for gap in skill_gaps:
        if gap["gap"] <= 0:
            continue

        skill_id = gap["skill_id"]
        priority_gap = gap["gap"] * gap["priority"]

        total_priority_gap += priority_gap

        if skill_id in course_skills:
            matched_priority_gap += priority_gap

    if total_priority_gap == 0:
        return 0

    return matched_priority_gap / total_priority_gap


def calculate_difficulty_fit(course, skill_gaps):
    """
    Checks whether the course difficulty is appropriate
    for the learner's current skill level.
    """

    relevant_levels = []

    for gap in skill_gaps:
        if gap["skill_id"] in course.get("skills", []):
            relevant_levels.append(gap["current_level"])

    if not relevant_levels:
        return 0

    average_level = sum(relevant_levels) / len(relevant_levels)

    course_level = course.get("level", 3)

    difference = abs(course_level - average_level)

    if difference <= 1:
        return 1.0
    elif difference <= 2:
        return 0.7
    else:
        return 0.4


def calculate_category_match(course, skill_gaps):
    """
    Gives a small bonus when the course directly addresses
    at least one current skill gap.
    """

    for gap in skill_gaps:
        if gap["gap"] > 0:
            if gap["skill_id"] in course.get("skills", []):
                return 1.0

    return 0


def score_course(course, skill_gaps, role_name):
    """
    Calculate the final recommendation score.

    Factors:
    - Skill gap match: 60%
    - Role relevance: 20%
    - Future demand: 10%
    - Difficulty fit: 10%
    """

    skill_match = calculate_skill_match(
        course,
        skill_gaps
    )

    # Never recommend a course that does not
    # address an actual skill gap.
    if skill_match == 0:
        return 0

    metadata = load_course_metadata()

    course_metadata = metadata.get(
        course["id"],
        {}
    )

    role_relevance = course_metadata.get(
        "role_relevance",
        {}
    ).get(
        role_name,
        0
    )

    future_demand = course_metadata.get(
        "future_demand",
        0
    )

    difficulty_fit = calculate_difficulty_fit(
        course,
        skill_gaps
    )

    score = (
        skill_match * 0.60
        + role_relevance * 0.20
        + future_demand * 0.10
        + difficulty_fit * 0.10
    )

    return round(score * 100, 2)

def explain_recommendation(course, skill_gaps):
    """
    Generate a human-readable explanation
    using actual skill names.
    """

    # Load skill definitions
    skills_path = _find_data_file("skills.json")
    skills = []
    if os.path.exists(skills_path):
        with open(skills_path, "r", encoding="utf-8") as f:
            skills = json.load(f)

    skill_names = {
        skill["id"]: skill["name"]
        for skill in skills
    }

    matched_skills = []

    for gap in skill_gaps:
        if gap["gap"] > 0:
            skill_id = gap["skill_id"]

            if skill_id in course.get("skills", []):
                skill_name = skill_names.get(
                    skill_id,
                    skill_id
                )

                matched_skills.append(
                    f"{skill_name} "
                    f"(gap: {gap['gap']})"
                )

    if matched_skills:
        return (
            "Recommended because it addresses "
            "your skill gaps in "
            + ", ".join(matched_skills)
            + "."
        )

    return (
        "This course has limited alignment "
        "with your current skill gaps."
    )

def recommend_courses(
    courses,
    skill_gaps,
    role_name,
    completed_courses=None,
    top_n=5
):
    """
    Rank courses according to the learner's
    skill gaps and return the best recommendations.
    """

    if completed_courses is None:
        completed_courses = []

    recommendations = []

    for course in courses:

        # Don't recommend a course already completed
        if course["id"] in completed_courses:
            continue

        score = score_course(
    course,
    skill_gaps,
    role_name
)

        # Ignore courses that don't address
        # any current skill gap
        if score == 0:
            continue

        reason = explain_recommendation(
            course,
            skill_gaps
        )

        recommendations.append({
            "course_id": course["id"],
            "title": course["title"],
            "provider": course["provider"],
            "score": score,
            "reason": reason,
            "skills": course["skills"],
            "duration_hours": course["duration_hours"],
            "category": course["category"]
        })

    recommendations.sort(
        key=lambda x: x["score"],
        reverse=True
    )

    return recommendations[:top_n]