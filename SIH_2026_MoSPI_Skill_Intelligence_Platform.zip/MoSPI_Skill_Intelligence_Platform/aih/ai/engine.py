from ai.skill_gap import (
    calculate_skill_gaps,
    calculate_overall_competency,
    get_priority_gaps
)

from ai.recommender import recommend_courses


def analyze_user(
    user,
    role,
    courses,
    top_n=5
):
    """
    Complete competency analysis for a user.

    Flow:
    User skills
        ↓
    Skill gaps
        ↓
    Priority gaps
        ↓
    Course recommendations
    """

    # 1. Calculate skill gaps
    gaps = calculate_skill_gaps(
        user["skills"],
        role["required_skills"]
    )

    # 2. Calculate overall competency
    overall_score = calculate_overall_competency(
        user["skills"],
        role["required_skills"]
    )

    # 3. Find highest-priority gaps
    priority_gaps = get_priority_gaps(gaps)

    # 4. Get completed courses
    completed_courses = user.get(
        "completed_courses",
        []
    )

    # 5. Recommend courses
    recommendations = recommend_courses(
    courses,
    gaps,
    user["role"],
    completed_courses,
    top_n=top_n
)

    return {
        "user_id": user["id"],
        "user_name": user["name"],
        "role": user["role"],
        "overall_competency": overall_score,
        "skill_gaps": gaps,
        "priority_gaps": priority_gaps,
        "recommendations": recommendations
    }