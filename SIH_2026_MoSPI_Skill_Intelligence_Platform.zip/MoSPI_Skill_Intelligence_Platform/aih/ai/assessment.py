def evaluate_assessment(answers, questions):
    """
    Evaluate a learner's answers using the questions
    that were actually given to the learner.
    """

    total_questions = len(questions)
    correct_answers = 0

    skill_results = {}

    for question in questions:

        question_id = question["id"]
        skill = question["skill"]
        correct_answer = question["correct_answer"]

        learner_answer = answers.get(question_id)
        if learner_answer is None:
            learner_answer = answers.get(str(question_id))
        if learner_answer is None and str(question_id).isdigit():
            learner_answer = answers.get(int(question_id))

        if skill not in skill_results:
            skill_results[skill] = {
                "correct": 0,
                "total": 0
            }

        skill_results[skill]["total"] += 1

        is_correct = False
        if learner_answer is not None and correct_answer is not None:
            la_clean = str(learner_answer).strip().lower()
            ca_clean = str(correct_answer).strip().lower()
            if la_clean == ca_clean:
                is_correct = True
            elif len(la_clean) == 1 and ca_clean.startswith(la_clean + "."):
                is_correct = True
            elif len(ca_clean) == 1 and la_clean.startswith(ca_clean + "."):
                is_correct = True
            elif la_clean in ca_clean or ca_clean in la_clean:
                is_correct = True

        if is_correct:
            correct_answers += 1
            skill_results[skill]["correct"] += 1

    skill_scores = {}

    for skill, result in skill_results.items():

        percentage = (
            result["correct"] /
            result["total"]
        ) * 100

        skill_scores[skill] = round(
            percentage,
            2
        )

    overall_score = (
        correct_answers /
        total_questions
    ) * 100 if total_questions > 0 else 0

    return {
        "total_questions": total_questions,
        "correct_answers": correct_answers,
        "overall_score": round(
            overall_score,
            2
        ),
        "skill_scores": skill_scores
    }


def score_to_level(score):
    """
    Convert a percentage score into
    a competency level from 1 to 5.
    """

    if score < 20:
        return 1
    elif score < 40:
        return 2
    elif score < 60:
        return 3
    elif score < 80:
        return 4
    else:
        return 5


def get_skill_levels(skill_scores):
    """
    Convert skill percentages into
    competency levels from 1 to 5.
    """

    skill_levels = {}

    for skill, score in skill_scores.items():

        skill_levels[skill] = score_to_level(score)

    return skill_levels


def assessment_to_skills(answers, questions):
    """
    Convert assessment answers into
    competency levels that the skill-gap
    engine can use.
    """

    result = evaluate_assessment(
        answers,
        questions
    )

    skill_levels = get_skill_levels(
        result["skill_scores"]
    )

    return skill_levels