"""Person 2 - GenAI Lead - Competency Assessment Question Generator
Generates accurate competency assessment questions using Groq / OpenAI LLM,
with a robust domain-aware fallback for hackathon presentations and offline testing.
"""
import os
import json

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def load_skills():
    """
    Load the official competency definitions from skills.json.
    """
    candidates = [
        os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "skills.json"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "skills.json"),
        os.path.join(os.getcwd(), "data", "skills.json"),
        os.path.join(os.getcwd(), "sih_backend", "sih_backend", "data", "skills.json"),
    ]
    for p in candidates:
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
    return []


def generate_questions(skills=None, role="Statistical Officer", num_questions=10, skill_ids=None):
    """
    Generate competency assessment questions using an LLM or domain fallback.

    The LLM receives the actual skill ID, name,
    and category so that questions match the
    correct competency.
    """
    selected_ids = skill_ids if skill_ids is not None else (skills or [])
    all_skills = load_skills()

    # Select skills requested for this assessment (by id, code, or name)
    selected_skills = []
    for skill in all_skills:
        sk_id = skill.get("id", "")
        sk_name = skill.get("name", "")
        if (
            sk_id in selected_ids
            or sk_name in selected_ids
            or any(str(s).strip().lower() in sk_name.lower() or str(s).strip().lower() == str(sk_id).lower() for s in selected_ids)
        ):
            selected_skills.append(skill)
    if not selected_skills and all_skills:
        selected_skills = all_skills[:num_questions]

    # Try LLM if API key and openai package are present
    api_key = os.getenv("GROQ_API_KEY") or os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(
                base_url="https://api.groq.com/openai/v1" if os.getenv("GROQ_API_KEY") else None,
                api_key=api_key,
            )
            prompt = f"""
You are an expert competency assessment designer for India's official statistical system (MoSPI / NSSTA).
Generate exactly {num_questions} high-quality multiple-choice assessment questions for the role: {role}
You MUST assess ONLY these competencies:
{json.dumps(selected_skills, indent=2)}

Return exactly this JSON structure:
{{
    "questions": [
        {{
            "id": "Q001",
            "question": "Question text",
            "options": ["A. ...", "B. ...", "C. ...", "D. ..."],
            "correct_answer": "A. ...",
            "skill": "Skill Name or ID",
            "explanation": "Official explanation of why this option is correct and others are incorrect."
        }}
    ]
}}
"""
            response = client.chat.completions.create(
                model="openai/gpt-oss-120b" if os.getenv("GROQ_API_KEY") else "gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": "You generate accurate, rigorous competency assessment questions for government statistical officers. Always respond with valid JSON."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"},
                temperature=0.7
            )
            content = response.choices[0].message.content.strip()
            if content.startswith("```json"):
                content = content[7:]
            if content.startswith("```"):
                content = content[3:]
            if content.endswith("```"):
                content = content[:-3]
            parsed = json.loads(content.strip())
            if "questions" in parsed and len(parsed["questions"]) > 0:
                return parsed
        except Exception as exc:
            print(f"LLM question generation failed: {exc}, using domain question bank.")

    # Comprehensive domain question bank tailored for MoSPI / NSSTA roles:
    # 1. Statistical Officer (Surveys, Sampling, National Accounts, Price Indices, Ethics)
    # 2. Data Analyst (Python, SQL, Power BI, Machine Learning, Data Quality, R)
    # 3. Administrator (Cybersecurity, CERT-In, DPDP Act, MeghRaj Cloud, IAM, RBAC, e-Office)
    q_bank = [
        # ==================== DATA ANALYST COMPETENCIES ====================
        {
            "roles": ["data_analyst", "Data Analyst", "analyst"],
            "skills": ["Python for Statistical Computing", "Python Programming", "Python", "SK-009", "Data Analysis", "Pandas"],
            "question": "In Python pandas, which method is most effective for performing vectorized split-apply-combine computations (e.g., mean, median, standard deviation) across survey strata?",
            "options": ["A. df.groupby(['stratum']).agg({'expenditure': ['mean', 'std']})", "B. df.pivot_table(columns='all')", "C. for row in df.iterrows(): calculate()", "D. df.applymap(lambda x: x.mean())"],
            "correct_answer": "A. df.groupby(['stratum']).agg({'expenditure': ['mean', 'std']})",
            "explanation": "df.groupby().agg() is the optimized vectorized pandas approach for calculating stratified statistics, avoiding sluggish Python iteration loops.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["data_analyst", "Data Analyst", "analyst"],
            "skills": ["Python for Statistical Computing", "Python Programming", "Python", "Pandas", "Data Cleaning"],
            "question": "When preprocessing census microdata with missing numerical records, why is stratified median imputation typically preferred over mean imputation?",
            "options": ["A. Median is robust to extreme outliers in skewed socio-economic distributions", "B. Mean cannot be calculated on float numbers", "C. Median imputation automatically balances the sample weights", "D. Pandas does not support mean imputation on dataframes"],
            "correct_answer": "A. Median is robust to extreme outliers in skewed socio-economic distributions",
            "explanation": "Income and wealth distributions are heavily right-skewed; the median provides a measure of central tendency uncorrupted by extreme wealth outliers.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["data_analyst", "Data Analyst", "analyst", "admin"],
            "skills": ["SQL & Relational Databases", "SQL & Database Management", "SQL", "SK-011", "Database"],
            "question": "Which SQL window function allows ranking household consumption within each state without skipping ranking numbers in the event of ties?",
            "options": ["A. DENSE_RANK() OVER (PARTITION BY state_id ORDER BY consumption DESC)", "B. RANK() OVER (ORDER BY consumption)", "C. ROW_NUMBER() OVER (PARTITION BY state_id)", "D. GROUP BY state_id HAVING RANK() > 1"],
            "correct_answer": "A. DENSE_RANK() OVER (PARTITION BY state_id ORDER BY consumption DESC)",
            "explanation": "DENSE_RANK() assigns consecutive rank numbers (1, 2, 2, 3) without gaps for ties within partitions, whereas RANK() leaves gaps (1, 2, 2, 4).",
            "difficulty": "advanced"
        },
        {
            "roles": ["data_analyst", "Data Analyst", "analyst"],
            "skills": ["SQL & Relational Databases", "SQL & Database Management", "SQL", "Database"],
            "question": "To combine survey respondent metadata with individual module questionnaires while retaining ALL registered respondents even if they did not complete the module, which JOIN is required?",
            "options": ["A. LEFT OUTER JOIN", "B. INNER JOIN", "C. CROSS JOIN", "D. FULL DISJOINT JOIN"],
            "correct_answer": "A. LEFT OUTER JOIN",
            "explanation": "A LEFT OUTER JOIN preserves all rows from the primary respondent registry table and fills NULLs for records with no matching questionnaire responses.",
            "difficulty": "foundational"
        },
        {
            "roles": ["data_analyst", "Data Analyst", "analyst"],
            "skills": ["AI / Machine Learning for Data Quality", "Machine Learning", "SK-012", "AI"],
            "question": "When evaluating an AI model designed to detect rare anomalies and fraudulent entries in official statistical surveys (where anomalies represent < 1% of data), which evaluation metric is most reliable?",
            "options": ["A. Area Under the Precision-Recall Curve (PR-AUC) / F1-Score", "B. Overall Accuracy Score", "C. Mean Squared Error (MSE)", "D. R-Squared (Coefficient of Determination)"],
            "correct_answer": "A. Area Under the Precision-Recall Curve (PR-AUC) / F1-Score",
            "explanation": "In severe class imbalance (<1%), high accuracy is deceptive (a naive model predicting 'normal' achieves 99% accuracy). PR-AUC and F1-score specifically evaluate performance on minority anomaly cases.",
            "difficulty": "advanced"
        },
        {
            "roles": ["data_analyst", "Data Analyst", "analyst"],
            "skills": ["AI / Machine Learning for Data Quality", "Machine Learning", "SK-012"],
            "question": "To prevent data leakage during machine learning model training on socio-economic time-series indicators, which cross-validation strategy must be applied?",
            "options": ["A. Temporal / TimeSeriesSplit (Walk-forward validation)", "B. Standard random k-fold cross validation", "C. Stratified k-fold with random shuffle", "D. Leave-one-out cross validation with random permutation"],
            "correct_answer": "A. Temporal / TimeSeriesSplit (Walk-forward validation)",
            "explanation": "Randomly shuffling time-series data leaks future information into training sets. Walk-forward time-series splits train strictly on past intervals to forecast future ones.",
            "difficulty": "advanced"
        },
        {
            "roles": ["data_analyst", "Data Analyst", "analyst"],
            "skills": ["Data Visualization & Power BI / Tableau", "Data Visualization", "SK-013", "Power BI", "Tableau"],
            "question": "In Microsoft Power BI, which DAX function computes the previous year's total index value for dynamic YoY comparisons against the active filter context?",
            "options": ["A. CALCULATE([Total Index], SAMEPERIODLASTYEAR('Calendar'[Date]))", "B. PREVIOUSYEAR([Total Index])", "C. FILTER([Total Index], Date - 365)", "D. LOOKUPVALUE([Total Index], -1)"],
            "correct_answer": "A. CALCULATE([Total Index], SAMEPERIODLASTYEAR('Calendar'[Date]))",
            "explanation": "CALCULATE modifies the filter context, allowing SAMEPERIODLASTYEAR to shift the active date range exactly 12 months backward for official statistical reporting.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["data_analyst", "Data Analyst", "analyst"],
            "skills": ["Data Quality Assurance Frameworks", "Data Quality", "SK-010"],
            "question": "Under MoSPI's Data Quality Assurance Framework, which non-parametric technique detects statistical outliers without assuming a Gaussian bell-curve distribution?",
            "options": ["A. Tukey's Interquartile Range (IQR) Fences (Q1 - 1.5*IQR to Q3 + 1.5*IQR)", "B. Standard Z-Score with 3 standard deviations", "C. Linear Pearson Correlation coefficient", "D. Simple moving average threshold"],
            "correct_answer": "A. Tukey's Interquartile Range (IQR) Fences (Q1 - 1.5*IQR to Q3 + 1.5*IQR)",
            "explanation": "Tukey's IQR method relies on percentiles (Q1 and Q3) and is robust for non-normal, skewed socio-economic survey data, unlike Z-score which assumes normality.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["data_analyst", "Data Analyst", "analyst"],
            "skills": ["R Programming & R-Studio", "R Programming", "SK-010", "R"],
            "question": "In R tidyverse / dplyr, which command pipeline aggregates survey weights by district to compute total estimated population?",
            "options": ["A. df %>% group_by(district) %>% summarise(pop = sum(sampling_weight))", "B. df.sum(weight, group=district)", "C. aggregate.all(df, weight)", "D. select(df, district) + sum(weight)"],
            "correct_answer": "A. df %>% group_by(district) %>% summarise(pop = sum(sampling_weight))",
            "explanation": "The tidyverse pipeline idiom `group_by() %>% summarise()` is the standard R grammar for computing weighted survey estimates.",
            "difficulty": "foundational"
        },

        # ==================== ADMINISTRATOR COMPETENCIES ====================
        {
            "roles": ["admin", "Administrator", "System Administrator"],
            "skills": ["Cybersecurity & CERT-In Guidelines", "Cybersecurity Fundamentals", "SK-022", "Cybersecurity"],
            "question": "Under CERT-In Directives (April 2022) issued by MeitY, within what mandatory timeframe must government entities report identified cybersecurity incidents (ransomware, unauthorized system access, data breach)?",
            "options": ["A. Within 6 hours of notice", "B. Within 24 hours of confirmation", "C. Within 7 working days", "D. At the end of the fiscal quarter"],
            "correct_answer": "A. Within 6 hours of notice",
            "explanation": "Under Section 70B of the IT Act and CERT-In directions of April 2022, all government departments and cloud operators must mandatorily report cybersecurity incidents within 6 hours.",
            "difficulty": "foundational"
        },
        {
            "roles": ["admin", "Administrator", "System Administrator"],
            "skills": ["Cybersecurity & CERT-In Guidelines", "Cybersecurity Fundamentals", "SK-022"],
            "question": "What is the foundational premise of Zero Trust Architecture (ZTA) mandated for Indian government digital infrastructure?",
            "options": ["A. 'Never trust, always verify' with continuous identity and device posture validation", "B. Trust all devices connecting from inside the internal government office LAN", "C. Disabling all multi-factor authentication on administrative consoles", "D. Relying exclusively on perimeter firewalls without internal segmentation"],
            "correct_answer": "A. 'Never trust, always verify' with continuous identity and device posture validation",
            "explanation": "Zero Trust assumes threats exist both inside and outside network perimeters, requiring explicit verification of every access request regardless of source location.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["admin", "Administrator", "System Administrator"],
            "skills": ["Data Privacy & DPDP Act 2023", "Data Privacy & Protection", "SK-018", "DPDP Act"],
            "question": "Under the Digital Personal Data Protection (DPDP) Act 2023, what is the statutory obligation of a government 'Data Fiduciary' upon discovering a personal data breach?",
            "options": ["A. Intimate the Data Protection Board of India and each affected Data Principal in the prescribed form", "B. Delete all system logs immediately to prevent unauthorized discovery", "C. Issue a public press apology within 30 days without informing individual principals", "D. Pay an informal settlement directly to the affected employees"],
            "correct_answer": "A. Intimate the Data Protection Board of India and each affected Data Principal in the prescribed form",
            "explanation": "Section 8(6) of DPDP Act 2023 mandates that in the event of a personal data breach, the Data Fiduciary shall give the Data Protection Board and each affected Data Principal intimation of such breach.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["admin", "Administrator", "System Administrator"],
            "skills": ["Data Privacy & DPDP Act 2023", "Data Privacy & Protection", "SK-018"],
            "question": "Under the DPDP Act 2023 Schedule, what is the maximum financial penalty that may be imposed on a Data Fiduciary for failure to take reasonable security safeguards to prevent a personal data breach?",
            "options": ["A. Up to ₹250 Crores", "B. Up to ₹50 Lakhs", "C. Up to ₹5 Crores", "D. Up to ₹10,000"],
            "correct_answer": "A. Up to ₹250 Crores",
            "explanation": "The Schedule to the DPDP Act 2023 prescribes penalties up to ₹250 Crores for significant breaches in implementing reasonable security safeguards.",
            "difficulty": "advanced"
        },
        {
            "roles": ["admin", "Administrator", "System Administrator"],
            "skills": ["Government Cloud (MeghRaj)", "Cloud Computing", "SK-015", "Infrastructure"],
            "question": "In the MeghRaj (GI Cloud) disaster recovery framework for national statistical portals, what does Recovery Point Objective (RPO) specify?",
            "options": ["A. The maximum acceptable volume/duration of data loss measured in time preceding a disaster event", "B. The maximum time allowed to restart virtual machines after an outage", "C. The physical distance between primary and secondary data centres", "D. The maximum budget allocation for cloud subscription tiers"],
            "correct_answer": "A. The maximum acceptable volume/duration of data loss measured in time preceding a disaster event",
            "explanation": "RPO defines the maximum targeted period in which data might be lost due to a major incident (e.g., an RPO of 15 minutes means backups must guarantee no more than 15 minutes of lost data).",
            "difficulty": "advanced"
        },
        {
            "roles": ["admin", "Administrator", "System Administrator"],
            "skills": ["Government Cloud (MeghRaj)", "Cloud Computing", "SK-015"],
            "question": "How do system administrators ensure zero-downtime high availability during database upgrades on government cloud platforms?",
            "options": ["A. Deploying Multi-Availability Zone Active-Standby replication with automated failover", "B. Shutting down the server over the weekend and applying patches directly", "C. Keeping only one database instance with increased CPU cores", "D. Disabling database transactions during maintenance windows"],
            "correct_answer": "A. Deploying Multi-Availability Zone Active-Standby replication with automated failover",
            "explanation": "Active-standby synchronous replication across separate physical availability zones allows seamless failover without service interruption.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["admin", "Administrator", "System Administrator"],
            "skills": ["Cybersecurity & CERT-In Guidelines", "Cybersecurity Fundamentals", "Audit"],
            "question": "According to CERT-In cybersecurity directives, for what minimum rolling duration must system, application, and security audit logs be mandatorily preserved within Indian jurisdiction?",
            "options": ["A. At least 180 days (6 months)", "B. At least 30 days", "C. Exactly 14 days", "D. Logs may be discarded once disk capacity reaches 90%"],
            "correct_answer": "A. At least 180 days (6 months)",
            "explanation": "CERT-In mandates that all service providers, intermediaries, data centres, and government bodies maintain system logs securely for a rolling period of at least 180 days.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["admin", "Administrator", "System Administrator"],
            "skills": ["Digital Signatures & e-Office Operations", "e-Governance Systems", "SK-023", "Governance"],
            "question": "Under Section 5 of the Information Technology Act 2000, what technical mechanism establishes legal equivalence between an electronic signature and a physical handwritten signature?",
            "options": ["A. Cryptographic Digital Signature Certificate (DSC) issued by a licensed Certifying Authority (CCA)", "B. Typing an officer's name in bold italic text at the bottom of a PDF", "C. Scanning a physical signature and pasting the PNG image into the document", "D. Forwarding an email with an officer's official signature disclaimer block"],
            "correct_answer": "A. Cryptographic Digital Signature Certificate (DSC) issued by a licensed Certifying Authority (CCA)",
            "explanation": "Only digital signatures issued by licensed Certifying Authorities under the Controller of Certifying Authorities (CCA) provide non-repudiation and legal validity under the IT Act.",
            "difficulty": "foundational"
        },

        # ==================== STATISTICAL OFFICER COMPETENCIES ====================
        {
            "roles": ["statistical_officer", "Statistical Officer", "official", "Senior Statistical Officer"],
            "skills": ["Sampling Techniques & Estimation", "Survey Sampling Methods", "SK-007", "SK-001", "Sampling"],
            "question": "In the NSS multi-stage stratified sampling design, what serves as the primary sampling frame for rural First Stage Units (FSUs)?",
            "options": ["A. Decennial Census List of Villages", "B. Gram Panchayat Electoral Rolls", "C. Agricultural Land Revenue Records", "D. Postal Pincode Directory"],
            "correct_answer": "A. Decennial Census List of Villages",
            "explanation": "In NSSO rural household surveys, the Decennial Population Census list of villages serves as the primary sampling frame for First Stage Units (FSUs). Urban FSUs use Urban Frame Survey (UFS) blocks.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["statistical_officer", "Statistical Officer", "official", "Senior Statistical Officer"],
            "skills": ["Sampling Techniques & Estimation", "Inferential Statistics", "SK-001", "Statistics"],
            "question": "In official sample survey inference, which property guarantees that the expected value of an estimator matches the true population parameter across repeated sampling?",
            "options": ["A. Unbiasedness", "B. Consistency", "C. Asymptotic Normality", "D. Minimal Kurtosis"],
            "correct_answer": "A. Unbiasedness",
            "explanation": "An estimator is strictly unbiased if its mathematical expectation E[θ̂] equals the true population parameter θ. This is the foundational criterion for probability sampling weights.",
            "difficulty": "foundational"
        },
        {
            "roles": ["statistical_officer", "Statistical Officer", "official", "Senior Statistical Officer"],
            "skills": ["National Accounts Statistics (SNA 2008)", "National Accounts", "Macroeconomic Statistics"],
            "question": "Under the System of National Accounts (SNA 2008) methodology adopted by MoSPI, how is Gross Value Added (GVA) at Basic Prices calculated from output?",
            "options": ["A. Output at basic prices minus Intermediate Consumption", "B. Output at basic prices plus Net Indirect Taxes", "C. Final Consumption Expenditure plus Gross Capital Formation", "D. Output at factor cost minus Depreciation"],
            "correct_answer": "A. Output at basic prices minus Intermediate Consumption",
            "explanation": "Under SNA 2008, GVA at basic prices equals Total Output (at basic prices) minus Intermediate Consumption (at purchasers' prices). Adding Net Taxes on Products yields GDP at market prices.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["statistical_officer", "Statistical Officer", "official", "Senior Statistical Officer"],
            "skills": ["Price Statistics (CPI & WPI)", "Price Statistics & Index Numbers", "Inflation", "CPI"],
            "question": "In India's Consumer Price Index (CPI) compiled by MoSPI, which formula is utilized for aggregating elementary item price relatives to subgroup indices?",
            "options": ["A. Modified Laspeyres Formula", "B. Paasche Index Formula", "C. Fisher's Ideal Index", "D. Marshall-Edgeworth Formula"],
            "correct_answer": "A. Modified Laspeyres Formula",
            "explanation": "MoSPI uses the Modified Laspeyres formula with base period expenditure shares as weights to compile All-India and State-level CPI numbers.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["statistical_officer", "Statistical Officer", "official", "Senior Statistical Officer"],
            "skills": ["Survey Design & Questionnaire Formulation", "Survey Design", "Questionnaire"],
            "question": "To minimize non-sampling errors arising from ambiguous terminology in large-scale socio-economic schedules, which step is essential before national rollout?",
            "options": ["A. Rigorous field pre-testing and pilot survey validation", "B. Increasing the sample size by 500%", "C. Omitting all skip instructions", "D. Shortening interviewer training to one hour"],
            "correct_answer": "A. Rigorous field pre-testing and pilot survey validation",
            "explanation": "Pre-testing and pilot surveys detect wording ambiguities, question-order biases, and non-response drivers, significantly reducing non-sampling error.",
            "difficulty": "intermediate"
        },
        {
            "roles": ["statistical_officer", "Statistical Officer", "official", "Senior Statistical Officer"],
            "skills": ["Statistical Ethics & Code of Practice", "Data Ethics & Responsible AI", "SK-021", "Ethics"],
            "question": "Under the UN Fundamental Principles of Official Statistics and India's National Statistical Commission guidelines, what is the core tenet regarding microdata confidentiality?",
            "options": ["A. Individual respondent data must be strictly confidential and used exclusively for statistical purposes", "B. Survey data may be shared with tax authorities for revenue recovery", "C. Respondent identities can be auctioned for research funding", "D. Confidentiality expires immediately upon survey report publication"],
            "correct_answer": "A. Individual respondent data must be strictly confidential and used exclusively for statistical purposes",
            "explanation": "Principle 6 of UN Fundamental Principles dictates that individual data collected by statistical agencies must be strictly confidential and used exclusively for statistical purposes.",
            "difficulty": "foundational"
        },
        {
            "roles": ["statistical_officer", "Statistical Officer", "official", "Senior Statistical Officer"],
            "skills": ["Labour Statistics & PLFS", "Labour Statistics", "PLFS"],
            "question": "In the Periodic Labour Force Survey (PLFS) conducted by MoSPI, how is an individual classified as employed under the Usual Principal Status (UPS) approach?",
            "options": ["A. If the person engaged in economic activity for a relatively long time (>= 183 days) during the 365 days preceding the date of survey", "B. If the person worked for at least 1 hour on any day during the reference week", "C. If the person is actively searching for employment via employment exchanges", "D. If the person holds a permanent government appointment"],
            "correct_answer": "A. If the person engaged in economic activity for a relatively long time (>= 183 days) during the 365 days preceding the date of survey",
            "explanation": "Usual Principal Activity status is determined using the major time criterion (183+ days) during the 365-day reference period.",
            "difficulty": "intermediate"
        }
    ]

    # Map requested skills and role to questions
    selected_lower = [str(s).strip().lower() for s in selected_ids]
    role_lower = str(role).strip().lower()
    is_analyst = "analyst" in role_lower
    is_admin = "admin" in role_lower

    matched_questions = []

    # Priority 1: Match on BOTH role and requested skills
    for item in q_bank:
        item_roles = [r.lower() for r in item.get("roles", [])]
        item_skills_lower = [s.lower() for s in item["skills"]]
        
        role_matches = (
            (is_analyst and any("analyst" in r for r in item_roles))
            or (is_admin and any("admin" in r for r in item_roles))
            or (not is_analyst and not is_admin and any("statistical_officer" in r or "official" in r for r in item_roles))
        )
        
        skill_matches = False
        if not selected_lower:
            skill_matches = True
        else:
            for req in selected_lower:
                if any(req in sk or sk in req for sk in item_skills_lower):
                    skill_matches = True
                    break
                    
        if role_matches and skill_matches and item not in matched_questions:
            matched_questions.append(item)

    # Priority 2: Match on skills across bank
    if len(matched_questions) < num_questions:
        for item in q_bank:
            item_skills_lower = [s.lower() for s in item["skills"]]
            skill_matches = False
            for req in selected_lower:
                if any(req in sk or sk in req for sk in item_skills_lower):
                    skill_matches = True
                    break
            if skill_matches and item not in matched_questions:
                matched_questions.append(item)

    # Priority 3: Fall back to role-matched questions
    if len(matched_questions) < num_questions:
        for item in q_bank:
            item_roles = [r.lower() for r in item.get("roles", [])]
            role_matches = (
                (is_analyst and any("analyst" in r for r in item_roles))
                or (is_admin and any("admin" in r for r in item_roles))
                or (not is_analyst and not is_admin and any("statistical_officer" in r or "official" in r for r in item_roles))
            )
            if role_matches and item not in matched_questions:
                matched_questions.append(item)

    # Priority 4: Fill remaining from any question in q_bank
    for item in q_bank:
        if len(matched_questions) >= num_questions:
            break
        if item not in matched_questions:
            matched_questions.append(item)

    final_questions = []
    for idx, item in enumerate(matched_questions[:num_questions], start=1):
        # Resolve skill name
        sk_label = item["skills"][0]
        for candidate in selected_ids:
            if any(str(candidate).lower() in s.lower() for s in item["skills"]):
                sk_label = str(candidate)
                break
        final_questions.append({
            "id": f"Q{idx:03d}",
            "question": item["question"],
            "options": item["options"],
            "correct_answer": item["correct_answer"],
            "skill": sk_label,
            "explanation": item.get("explanation", "MoSPI official methodological standard."),
            "difficulty": item.get("difficulty", "intermediate")
        })

    return {"questions": final_questions}


__all__ = ["generate_questions", "load_skills"]
