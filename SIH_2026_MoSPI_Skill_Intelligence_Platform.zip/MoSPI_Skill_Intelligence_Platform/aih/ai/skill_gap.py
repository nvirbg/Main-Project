def calculate_skill_gaps(user_skills, role_requirements):
    """
    Calculate the skill gap between a user's current level
    and the level required for their role.

    Proficiency levels:
    1 = Beginner
    2 = Basic
    3 = Intermediate
    4 = Advanced
    5 = Expert
    """

    gaps = []

    for requirement in role_requirements:
        skill_id = requirement["skill_id"]
        required_level = requirement["required_level"]
        priority = requirement["priority"]

        current_level = user_skills.get(skill_id, 0)

        gap = max(required_level - current_level, 0)

        gaps.append({
            "skill_id": skill_id,
            "current_level": current_level,
            "required_level": required_level,
            "gap": gap,
            "priority": priority
        })

    return gaps


def calculate_overall_competency(user_skills, role_requirements):
    """
    Calculate overall competency as a percentage
    against the requirements of the selected role.
    """

    if not role_requirements:
        return 0

    total_required = 0
    total_current = 0

    for requirement in role_requirements:
        skill_id = requirement["skill_id"]
        required_level = requirement["required_level"]

        current_level = user_skills.get(skill_id, 0)

        total_required += required_level
        total_current += min(current_level, required_level)

    if total_required == 0:
        return 0

    return round((total_current / total_required) * 100, 2)


def get_priority_gaps(gaps):
    """
    Rank skill gaps based on:
    
    gap × priority

    Higher value = more important skill gap.
    """

    for gap in gaps:
        gap["gap_priority"] = round(
            gap["gap"] * gap["priority"], 2
        )

    priority_gaps = [
        gap for gap in gaps
        if gap["gap"] > 0
    ]

    priority_gaps.sort(
        key=lambda x: x["gap_priority"],
        reverse=True
    )

    return priority_gaps