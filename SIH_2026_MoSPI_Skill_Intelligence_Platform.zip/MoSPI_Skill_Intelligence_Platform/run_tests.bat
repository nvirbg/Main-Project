@echo off
title Run All MVP & AI Test Suites
color 0B

echo ======================================================================
echo  Running All 9 MVP Test Suites Across AI, Data Science, and Backend
echo ======================================================================
echo.

cd /d "%~dp0sih_backend\sih_backend"

.\venv\Scripts\python.exe -c "
import subprocess, sys

tests = [
    ['.\\venv\\Scripts\\python.exe', 'tests/test_all_mvp.py'],
    ['.\\venv\\Scripts\\python.exe', 'tests/test_recommendation.py'],
    ['.\\venv\\Scripts\\python.exe', 'analytics/matrix.py'],
    ['.\\venv\\Scripts\\python.exe', 'analytics/metrics.py'],
    ['.\\venv\\Scripts\\python.exe', 'data/seed_data.py'],
    ['.\\venv\\Scripts\\python.exe', '..\\..\\aih\\test_adaptive.py'],
    ['.\\venv\\Scripts\\python.exe', '..\\..\\aih\\test_assessment_now.py'],
    ['.\\venv\\Scripts\\python.exe', '..\\..\\aih\\test_engine_now.py'],
    ['.\\venv\\Scripts\\python.exe', '..\\..\\aih\\test_llm.py'],
]

all_ok = True
for cmd in tests:
    print('RUNNING: ' + ' '.join(cmd))
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        print('FAILED: ' + (res.stderr or res.stdout))
        all_ok = False
    else:
        print('PASSED OK\n')

if all_ok:
    print('=========================================')
    print('ALL 9 TEST SUITES PASSED WITH 0 ERRORS!')
    print('=========================================')
else:
    sys.exit(1)
"

pause
