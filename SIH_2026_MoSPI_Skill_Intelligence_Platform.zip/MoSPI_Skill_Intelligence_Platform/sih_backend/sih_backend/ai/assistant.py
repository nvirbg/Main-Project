"""Person 2 - GenAI / LLM Lead - AI Learning Assistant
Answers official queries regarding statistical methodologies, iGOT modules, and course concepts.
"""
import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from ai.prompts import ASSISTANT_SYSTEM_PROMPT

try:
    from app.config import settings
except ImportError:
    settings = None


def answer_question(question: str, context: str = "", history: list[dict] = None) -> dict:
    """Answers learner questions using LLM (Gemini / Anthropic) or domain knowledge base."""
    if not question or not question.strip():
        return {"answer": "Please ask a question about official statistics, competencies, or courses.", "sources": []}

    history_str = ""
    if history:
        lines = []
        for h in history[-4:]:
            sender = "Learner" if h.get("sender") in ("user", "learner") else "MoSPI Assistant"
            txt = (h.get("text") or "").strip()
            if txt:
                lines.append(f"{sender}: {txt}")
        if lines:
            history_str = "--- PREVIOUS CHAT HISTORY ---\n" + "\n".join(lines) + "\n\n"

    # If Gemini API key is present
    gemini_key = os.getenv("GEMINI_API_KEY") or getattr(settings, "GEMINI_API_KEY", None)
    if gemini_key:
        try:
            from google import genai
            client = genai.Client(api_key=gemini_key)
            if context:
                prompt_content = (
                    f"{ASSISTANT_SYSTEM_PROMPT}\n\n"
                    f"{history_str}"
                    f"--- QUESTION CONTEXT ---\n{context}\n\n"
                    f"--- LEARNER QUERY ---\n{question}\n\n"
                    f"CRITICAL INSTRUCTIONS:\n"
                    f"1. Clearly state the correct answer and technical rationale.\n"
                    f"2. You MUST provide an in-depth breakdown for WHY IT IS NOT ANOTHER OPTION. Address each alternative option (e.g. Option A, C, D) individually, explaining why it is wrong for this question, what that term actually means, and why someone might mistakenly pick it.\n"
                    f"3. If the learner specifically asks why a particular option is not the answer, prioritize that option and contrast it directly with the correct choice.\n"
                    f"4. Include a quick comparative markdown table contrasting the options.\n"
                    f"5. Cite official MoSPI / NSSTA standards and recommend relevant iGOT courses."
                )
            else:
                prompt_content = (
                    f"{ASSISTANT_SYSTEM_PROMPT}\n\n"
                    f"{history_str}"
                    f"Learner Query: {question}\n\n"
                    f"CRITICAL INSTRUCTIONS:\n"
                    f"- If this query pertains to a multiple-choice question or asks why an option is or isn't correct, provide an in-depth pedagogical breakdown explaining why the correct choice is right and specifically why each alternative option is NOT the correct answer.\n"
                    f"- Cite official MoSPI / NSSTA standards and recommend relevant iGOT courses."
                )
            response = None
            for model_name in ["gemini-2.5-flash", "gemini-1.5-flash", "gemini-2.0-flash"]:
                try:
                    response = client.models.generate_content(
                        model=model_name,
                        contents=prompt_content
                    )
                    if response and response.text:
                        break
                except Exception:
                    continue
            if response and response.text:
                return {"answer": response.text, "sources": ["iGOT Karmayogi Course Material", "MoSPI / NSSTA Curriculum"]}
        except Exception as exc:
            print(f"Gemini assistant call failed: {exc}")

    # If Anthropic API key is configured, use LLM
    anthropic_key = getattr(settings, "ANTHROPIC_API_KEY", None) or os.getenv("ANTHROPIC_API_KEY")
    if anthropic_key:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=anthropic_key)
            if context:
                user_msg = (
                    f"{history_str}"
                    f"--- QUESTION CONTEXT ---\n{context}\n\n"
                    f"--- LEARNER QUERY ---\n{question}\n\n"
                    f"Please explain this question in detail, why the answer is correct, and specifically why each other option is NOT correct."
                )
            else:
                user_msg = f"{history_str}{question}"
            response = client.messages.create(
                model=settings.LLM_MODEL if settings else "claude-sonnet-4-6",
                max_tokens=1000,
                system=ASSISTANT_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            )
            ans = "".join(b.text for b in response.content if b.type == "text")
            return {"answer": ans, "sources": ["iGOT Karmayogi Course Material", "MoSPI / NSSTA Curriculum"]}
        except Exception as exc:
            print(f"Assistant LLM call failed: {exc}")


    # Domain Knowledge & Smart Context-Aware Fallback
    q_lower = question.lower()
    ctx_lower = context.lower() if context else ""
    combined = f"{q_lower} {ctx_lower}"

    # 1. If context is provided and user asks to explain
    if context and ("explain" in q_lower or "detail" in q_lower or "why" in q_lower or "how" in q_lower or "question" in q_lower or "what" in q_lower or "deatil" in q_lower or "not" in q_lower or "option" in q_lower):
        ans = (
            f"### 📋 Comprehensive Question Breakdown\n\n"
            f"**Provided Context / Question**:\n> {context.strip()}\n\n"
            f"#### 1. 🎯 Correct Answer & Core Concept\n"
            f"This question tests essential competencies under the **MoSPI Official Statistics & National Statistical Systems Training Academy (NSSTA)** curriculum.\n"
            f"The correct option directly reflects established methodological standards (e.g. multi-stage sampling protocols, SNA 2008 national accounting identities, or DPDP Act 2023 safeguards).\n\n"
            f"#### 2. 💡 Technical & Methodological Rationale\n"
            f"• In Indian official statistics, operational definitions are rigorously standardized to guarantee comparability across survey rounds and economic time-series.\n\n"
            f"#### 3. 🔍 Why It Is NOT Another Option (Distractor Breakdown)\n"
            f"• **Why alternative options are incorrect**: Distractor choices in MoSPI exams are designed to test boundary conditions—such as confusing an administrative stratum with an FSU, confusing intermediate consumption with final expenditure, or confusing an ultimate sampling unit (household) with a primary sampling unit (village).\n"
            f"• **Key Boundary Rule**: Always verify whether the term refers to the *First Stage Unit (FSU)*, *Intermediate Stage*, or *Ultimate Stage Unit (USU)*.\n\n"
            f"#### 4. 🏛️ Official Guidelines Reference\n"
            f"• **MoSPI Technical Documentation & NSSTA Competency Framework 2026**\n"
            f"• Reference Standard: National Sample Survey / National Accounts Division Operating Guidelines\n\n"
            f"#### 5. 📚 Recommended iGOT Karmayogi Learning Modules\n"
            f"• *'Modern Survey Sampling and Estimation Techniques'* (Course Code: `IGOT-STAT-001`)\n"
            f"• *'National Accounts Statistics & GDP Estimation (SNA 2008)'* (Course Code: `IGOT-STAT-002`)"
        )
        return {"answer": ans, "sources": ["MoSPI Methodological Standards", "NSSTA Training Manual", "iGOT Karmayogi"]}

    # 2. Topic-based intelligent matching
    if "national account" in combined or "gdp" in combined or "gva" in combined or "sna" in combined:
        ans = (
            "**National Accounts & GDP Compilation (SNA 2008)**:\n\n"
            "• **GVA at Basic Prices**: Total output value minus intermediate consumption.\n"
            "• **GDP at Market Prices**: GVA at Basic Prices + Product Taxes - Product Subsidies.\n"
            "• **Institutional Sectors**: Financial/Non-Financial Corporations, General Government, Households, and NPISH.\n\n"
            "For in-depth study, refer to course: *'National Accounts Statistics & GDP Estimation (SNA 2008)'* on iGOT Karmayogi."
        )
        sources = ["SNA 2008 Guidelines", "MoSPI NAD Handbook"]
    elif "sample" in combined or "sampling" in combined or "survey" in combined or "fsu" in combined or "plfs" in combined or "nsso" in combined:
        ans = (
            "**Official Survey Sampling Methodology (NSSO & PLFS)**:\n\n"
            "• **First Stage Units (FSUs)**: Census villages (rural sector) or Urban Frame Survey (UFS) blocks (urban sector).\n"
            "• **Ultimate Stage Units (USUs)**: Households selected using systematic random sampling after listing.\n"
            "• **Sampling Weights**: Base multipliers are calibrated using post-stratification to benchmark census aggregates.\n\n"
            "Recommended Course: *'Modern Survey Sampling and Estimation Techniques'* on iGOT Karmayogi."
        )
        sources = ["NSSO Survey Methodology Manual", "iGOT Course: Modern Survey Sampling"]
    elif "cpi" in combined or "wpi" in combined or "inflation" in combined or "price" in combined:
        ans = (
            "**Price Statistics (CPI & WPI)**:\n\n"
            "• **CPI**: Measures retail price changes experienced by households. Uses a modified Laspeyres formula.\n"
            "• **WPI**: Compiled by DPIIT to measure wholesale level price changes across primary articles, fuel, and manufactured products.\n\n"
            "Recommended Course: *'Price Statistics & Index Number Theory'* on NSSTA."
        )
        sources = ["MoSPI CPI Technical Manual"]
    elif "python" in combined or "r " in combined or "code" in combined or "pandas" in combined or "stata" in combined:
        ans = (
            "**Statistical Computing Workflows (Python & R)**:\n\n"
            "• **Python**: Pandas, NumPy, and SciPy for survey data cleaning, tabulation, and variance estimation.\n"
            "• **R**: `survey` package for weighted regression models and complex sampling designs.\n\n"
            "Recommended Course: *'Python for Official Statistics & Microdata Analysis'* on iGOT Karmayogi."
        )
        sources = ["iGOT Data Science Pathway"]
    elif "dpdp" in combined or "privacy" in combined or "cyber" in combined or "security" in combined:
        ans = (
            "**Digital Personal Data Protection (DPDP) Act 2023 & Microdata Safeguards**:\n\n"
            "• **Anonymization**: Identifiers (Aadhaar, phone, exact dwelling coordinates) must be masked using k-anonymity.\n"
            "• **Encryption**: Encrypted in transit (TLS 1.3) and at rest (AES-256) under CERT-In guidelines.\n\n"
            "Recommended Course: *'Data Privacy, DPDP Act 2023 & Cybersecurity in Government'* on iGOT."
        )
        sources = ["DPDP Act 2023 Standard Guidelines", "CERT-In Directives"]
    elif "explain" in q_lower or "detail" in q_lower or "deatil" in q_lower or "question" in q_lower or "why" in q_lower or "how" in q_lower or "what" in q_lower:
        ans = (
            "I'd be glad to give you a detailed pedagogical breakdown!\n\n"
            "• **To explain a specific question**: Please paste the question text and options here, or click **'💡 Ask AI Assistant'** on any quiz question to analyze it instantly.\n"
            "• **To learn a core concept**: Ask about official methodologies like *'Stratified Multi-Stage Sampling'*, *'GDP vs GVA in SNA 2008'*, *'CPI inflation computation'*, or *'DPDP Act 2023 for survey data'*.\n"
            "• **For iGOT courses**: Ask for recommendations tailored to your role and competency gaps."
        )
        sources = ["MoSPI AI Learning Assistant Help"]
    else:
        ans = (
            f"Regarding your query **'{question}'**:\n\n"
            "This pertains to official statistical principles under the Ministry of Statistics and Programme Implementation (MoSPI). "
            "You can explore relevant learning modules on your iGOT Course Catalogue tab or refer to the NSSTA Capacity Building Framework 2026."
        )
        sources = ["NSSTA Capacity Building Framework 2026"]

    return {"answer": ans, "sources": sources}
