"""Person 1 - AI/ML Lead - Skill Gap Engine
Analyzes an official's current competencies against role requirements.
Supports both dict-based requirements, list-based required_skills, skill_id, and skill_name lookups.
"""
import os
import json
from typing import Any, Dict, List, Union


_SKILLS_CACHE = None

def _get_skills_lookup() -> tuple[dict, dict]:
    """Returns (id_to_name, name_to_id) lookups from skills.json."""
    global _SKILLS_CACHE
    if _SKILLS_CACHE is not None:
        return _SKILLS_CACHE

    candidates = [
        os.path.join(os.path.dirname(__file__), "..", "data", "skills.json"),
        os.path.join(os.path.dirname(__file__), "data", "skills.json"),
        os.path.join(os.getcwd(), "data", "skills.json"),
        os.path.join(os.getcwd(), "sih_backend", "sih_backend", "data", "skills.json"),
    ]
    id_to_name = {}
    name_to_id = {}
    for p in candidates:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    skills_data = json.load(f)
                    for s in skills_data:
                        sid = s.get("id")
                        sname = s.get("name")
                        if sid and sname:
                            id_to_name[sid] = sname
                            name_to_id[sname.lower()] = sid
                break
            except Exception:
                pass
    _SKILLS_CACHE = (id_to_name, name_to_id)
    return _SKILLS_CACHE


def _normalize_priority(raw_p: Any) -> str:
    if isinstance(raw_p, (int, float)):
        if raw_p >= 0.9:
            return "critical"
        elif raw_p >= 0.7:
            return "high"
        elif raw_p >= 0.4:
            return "medium"
        else:
            return "low"
    if isinstance(raw_p, str):
        p_lower = raw_p.lower()
        if p_lower in ("critical", "high", "medium", "low"):
            return p_lower
    return "medium"


def calculate_skill_gaps(
    user_skills: Union[Dict[str, int], List[Dict[str, Any]]],
    role_requirements: Union[Dict[str, Any], List[Dict[str, Any]]],
) -> List[Dict[str, Any]]:
    """
    user_skills: {skill_name_or_id: current_level (1-5)} OR list of user skill dicts
    role_requirements: {skill_name: {"required_level": int, "priority": str}} OR list of required_skill dicts
    returns list of gaps sorted by priority and gap size
    """
    id_to_name, name_to_id = _get_skills_lookup()

    # Normalize user_skills to lookups
    user_skills_lookup = {}
    if isinstance(user_skills, list):
        for s in user_skills:
            sid = s.get("skill_id") or s.get("id")
            sname = s.get("skill_name") or s.get("name")
            lvl = s.get("current_level") or s.get("proficiency", 0)
            if sid:
                user_skills_lookup[sid] = lvl
            if sname:
                user_skills_lookup[sname] = lvl
                user_skills_lookup[sname.lower()] = lvl
    elif isinstance(user_skills, dict):
        for k, v in user_skills.items():
            user_skills_lookup[k] = v
            if isinstance(k, str):
                user_skills_lookup[k.lower()] = v
                if k in id_to_name:
                    user_skills_lookup[id_to_name[k]] = v
                    user_skills_lookup[id_to_name[k].lower()] = v
                if k.lower() in name_to_id:
                    user_skills_lookup[name_to_id[k.lower()]] = v

    # Normalize role_requirements into standard iterable items
    norm_reqs = []
    if isinstance(role_requirements, list):
        for req in role_requirements:
            sid = req.get("skill_id")
            sname = req.get("skill_name") or (id_to_name.get(sid) if sid else sid)
            req_lvl = req.get("required_level", 3)
            p = _normalize_priority(req.get("priority", "medium"))
            norm_reqs.append((sname or sid, sid, req_lvl, p))
    elif isinstance(role_requirements, dict):
        for skill_key, req in role_requirements.items():
            sid = req.get("skill_id") or name_to_id.get(skill_key.lower())
            sname = req.get("skill_name") or skill_key
            req_lvl = req.get("required_level", 3) if isinstance(req, dict) else int(req)
            p = _normalize_priority(req.get("priority", "medium") if isinstance(req, dict) else "medium")
            norm_reqs.append((sname, sid, req_lvl, p))

    gaps = []
    priority_weights = {"critical": 3.0, "high": 2.0, "medium": 1.0, "low": 0.5}

    for sname, sid, req_lvl, priority in norm_reqs:
        # Determine current level checking sid, sname, and lowercases
        curr_lvl = 0
        if sid and sid in user_skills_lookup:
            curr_lvl = user_skills_lookup[sid]
        elif sname and sname in user_skills_lookup:
            curr_lvl = user_skills_lookup[sname]
        elif sname and sname.lower() in user_skills_lookup:
            curr_lvl = user_skills_lookup[sname.lower()]

        gap = max(0, req_lvl - curr_lvl)
        if gap > 0:
            weight = priority_weights.get(priority, 1.0)
            weighted_score = gap * weight
            display_name = sname or (id_to_name.get(sid) if sid else sid) or "Unknown Skill"
            display_id = sid or name_to_id.get(display_name.lower()) or display_name
            gaps.append({
                "skill_id": display_id,
                "skill_name": display_name,
                "current_level": curr_lvl,
                "required_level": req_lvl,
                "gap": gap,
                "priority": priority,
                "weighted_priority": weighted_score,
            })

    gaps.sort(key=lambda x: (x["weighted_priority"], x["gap"]), reverse=True)
    return gaps


def calculate_overall_competency(
    user_skills: Union[Dict[str, int], List[Dict[str, Any]]],
    role_requirements: Union[Dict[str, Any], List[Dict[str, Any]]],
) -> float:
    """Calculates overall readiness percentage against role requirements (0 - 100)."""
    if not role_requirements:
        return 100.0

    id_to_name, name_to_id = _get_skills_lookup()

    user_skills_lookup = {}
    if isinstance(user_skills, list):
        for s in user_skills:
            sid = s.get("skill_id") or s.get("id")
            sname = s.get("skill_name") or s.get("name")
            lvl = s.get("current_level") or s.get("proficiency", 0)
            if sid:
                user_skills_lookup[sid] = lvl
            if sname:
                user_skills_lookup[sname] = lvl
                user_skills_lookup[sname.lower()] = lvl
    elif isinstance(user_skills, dict):
        for k, v in user_skills.items():
            user_skills_lookup[k] = v
            if isinstance(k, str):
                user_skills_lookup[k.lower()] = v
                if k in id_to_name:
                    user_skills_lookup[id_to_name[k]] = v
                    user_skills_lookup[id_to_name[k].lower()] = v
                if k.lower() in name_to_id:
                    user_skills_lookup[name_to_id[k.lower()]] = v

    norm_reqs = []
    if isinstance(role_requirements, list):
        for req in role_requirements:
            sid = req.get("skill_id")
            sname = req.get("skill_name") or (id_to_name.get(sid) if sid else sid)
            req_lvl = req.get("required_level", 3)
            norm_reqs.append((sname or sid, sid, req_lvl))
    elif isinstance(role_requirements, dict):
        for skill_key, req in role_requirements.items():
            sid = req.get("skill_id") or name_to_id.get(skill_key.lower())
            sname = req.get("skill_name") or skill_key
            req_lvl = req.get("required_level", 3) if isinstance(req, dict) else int(req)
            norm_reqs.append((sname, sid, req_lvl))

    total_required = 0
    total_acquired = 0
    for sname, sid, req_lvl in norm_reqs:
        curr_lvl = 0
        if sid and sid in user_skills_lookup:
            curr_lvl = user_skills_lookup[sid]
        elif sname and sname in user_skills_lookup:
            curr_lvl = user_skills_lookup[sname]
        elif sname and sname.lower() in user_skills_lookup:
            curr_lvl = user_skills_lookup[sname.lower()]

        total_required += req_lvl
        total_acquired += min(curr_lvl, req_lvl)

    if total_required == 0:
        return 100.0

    return round((total_acquired / total_required) * 100.0, 1)


def get_priority_gaps(gaps: list[dict], top_n: int = 5) -> list[dict]:
    """Returns the top N most urgent skill gaps."""
    return gaps[:top_n]


__all__ = [
    "calculate_skill_gaps",
    "calculate_overall_competency",
    "get_priority_gaps",
]
