"""AI services package for Skill Gap, Recommendations, Quiz Generation, and Assistant.
Owned by Person 1 (AI/ML Lead) and Person 2 (GenAI/LLM Lead).
"""
