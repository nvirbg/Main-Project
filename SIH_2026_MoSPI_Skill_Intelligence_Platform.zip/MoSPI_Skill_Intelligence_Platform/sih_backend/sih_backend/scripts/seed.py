"""Run once to initialize tables and seed comprehensive hackathon data:
  python -m scripts.seed

Seeds:
1. Canonical roles (admin, trainer, official, Statistical Officer, Data Analyst, Senior Statistical Officer)
2. MoSPI Departments
3. 4 Competency Domains & 32 Individual Skills
4. Role Requirements for all 3 demo statistical roles
5. 22 iGOT & NSSTA TPAC Courses tagged across all 4 domains
6. All 4 Demo Personas (admin, karthikeya, priya, rajesh) with role-aligned baseline competencies
7. Demo workforce officials, course progress, and quiz attempt benchmarks
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import Base, SessionLocal, engine
from app.models import (
    AttemptStatus, CompetencyDomain, Course, CourseSkillTag, Department,
    Official, OfficialCompetency, Progress, Quiz, QuizAttempt, Role,
    RoleRequirement, Skill
)
from app.security import hash_password

DEFAULT_ROLES = ["admin", "trainer", "official", "Statistical Officer", "Data Analyst", "Senior Statistical Officer"]

DEFAULT_DEPARTMENTS = [
    ("National Statistical Systems Training Academy", "NSSTA", "Premier national training academy for official statistics"),
    ("MoSPI - Data Informatics & Innovation Division", "DIID", "Data management, IT systems, and AI innovation"),
    ("MoSPI - National Accounts Division", "NAD", "Macroeconomic accounts, GDP compilation, and economic tables"),
    ("MoSPI - Prices & Cost of Living Division", "PCLD", "CPI and WPI inflation statistics compilation"),
    ("MoSPI - Agriculture Statistics Division", "ASD", "Agricultural surveys, crop estimation, and land-use data"),
    ("MoSPI - Social Statistics Division", "SSD", "PLFS, time-use surveys, health and education indicators"),
]

DEFAULT_DOMAINS = [
    ("Statistical Competencies", "statistical",
     "Survey Design, Sampling, National Accounts, Price/Labour/Agricultural/Industrial Statistics, SDG Indicators, Metadata Standards, Data Quality"),
    ("Technical Competencies", "technical",
     "Python, R, SQL, Stata, SPSS, SAS, GIS, Data Visualization, AI/ML, Cloud Computing, APIs, Open Data"),
    ("Digital Governance", "digital_governance",
     "Cybersecurity, Data Privacy, Digital Signatures, Government Cloud, Digital Public Infrastructure"),
    ("Behavioural & Managerial Competencies", "behavioural",
     "Leadership, Communication, Project Management, Ethics, Decision Making, Change Management"),
]

DEFAULT_SKILLS = {
    "Statistical Competencies": [
        ("Survey Design & Questionnaire Formulation", "Principles of designing household and enterprise sample surveys.", 5),
        ("Sampling Techniques & Estimation", "Simple random, stratified, multi-stage cluster sampling and variance estimation.", 5),
        ("National Accounts Statistics (SNA 2008)", "Compilation of GDP, GVA, institutional sector accounts, and capital formation.", 5),
        ("Price Statistics (CPI & WPI)", "Index number theory, Laspeyres/Paasche formula, weighting diagrams, price collection.", 5),
        ("Labour Statistics & PLFS", "Periodic Labour Force Survey concepts, activity status, unemployment rates.", 5),
        ("Agricultural Statistics & Crop Estimation", "General Crop Estimation Survey (GCES), land-use statistics, agricultural census.", 5),
        ("Industrial Statistics (IIP & ASI)", "Index of Industrial Production compilation and Annual Survey of Industries data processing.", 5),
        ("SDG Indicators & Monitoring Framework", "National Indicator Framework (NIF) tracking and data alignment with UN SDG targets.", 5),
        ("Metadata Standards (SDMX)", "Statistical Data and Metadata eXchange formats, code lists, data dissemination.", 5),
        ("Data Quality Assurance Frameworks", "DQAF standards, non-sampling error detection, data validation, imputation techniques.", 5),
    ],
    "Technical Competencies": [
        ("Python for Statistical Computing", "Data manipulation with Pandas/NumPy, survey analysis, and statistical tests.", 5),
        ("R Programming & R-Studio", "Applied statistical analysis, survey package, econometrics, and automated reporting.", 5),
        ("SQL & Relational Databases", "Complex queries, joins, window functions, and database management for survey data.", 5),
        ("Stata for Econometrics & Surveys", "Survey data weighting, svy commands, econometric modeling, panel data analysis.", 5),
        ("SPSS for Survey Analysis", "Descriptive statistics, cross-tabulations, factor analysis, hypothesis testing.", 5),
        ("SAS Programming", "Base SAS, macros, statistical procedures for large-scale microdata processing.", 5),
        ("GIS & Spatial Data Analysis (QGIS)", "Geo-tagging, spatial sampling, boundary mapping, and GIS integration with statistics.", 5),
        ("Data Visualization & Power BI / Tableau", "Interactive dashboards, charts, storytelling with official statistics.", 5),
        ("AI / Machine Learning for Data Quality", "Supervised classification, anomaly detection in microdata, predictive estimation.", 5),
        ("Cloud Computing & Big Data Analytics", "Distributed computing, data lakes, processing high-frequency data streams.", 5),
        ("Statistical APIs & Open Data Dissemination", "RESTful API consumption, open data standards, CKAN, automated data delivery.", 5),
    ],
    "Digital Governance": [
        ("Cybersecurity & CERT-In Guidelines", "Information security policies, threat mitigation, safe handling of sensitive survey records.", 5),
        ("Data Privacy & DPDP Act 2023", "Compliance with the Digital Personal Data Protection Act, anonymization, consent management.", 5),
        ("Digital Signatures & e-Office Operations", "DSC token management, document authentication, paperless office workflows.", 5),
        ("Government Cloud (MeghRaj)", "Cloud hosting standards, data residency, government cloud infrastructure security.", 5),
        ("Digital Public Infrastructure (DPI)", "India Stack components, Aadhaar authentication guidelines, API-driven e-governance.", 5),
    ],
    "Behavioural & Managerial Competencies": [
        ("Leadership & Team Management", "Leading field survey teams, motivation, conflict resolution, mentoring young officers.", 5),
        ("Communication & Statistical Dissemination", "Presenting data insights to policymakers, press releases, public data literacy.", 5),
        ("Project Management in Statistical Operations", "Timeline tracking, budget allocation, field inspection monitoring, risk mitigation.", 5),
        ("Statistical Ethics & Code of Practice", "Fundamental Principles of Official Statistics, integrity, neutrality, respondent confidentiality.", 5),
        ("Decision Making Under Uncertainty", "Evidence-based policymaking, statistical risk assessment, prioritization.", 5),
        ("Change Management & Technology Adoption", "Managing digital transformation, modernizing data collection from PAPI to CAPI.", 5),
    ],
}

DEFAULT_COURSES = [
    # 1. Statistical Courses
    {
        "igot_course_id": "IGOT-STAT-001",
        "title": "Modern Survey Sampling and Estimation Techniques",
        "description": "Comprehensive course covering stratified multistage sampling, cluster design, and weights calibration for official statistical surveys like NSSO and PLFS.",
        "provider": "iGOT Karmayogi",
        "duration_hours": 18.5,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/survey-sampling",
        "is_tpac_recommended": True,
        "skills": ["Sampling Techniques & Estimation", "Survey Design & Questionnaire Formulation"],
    },
    {
        "igot_course_id": "IGOT-STAT-002",
        "title": "National Accounts Statistics & GDP Estimation (SNA 2008)",
        "description": "In-depth guide to the System of National Accounts (SNA 2008), sequence of accounts, Gross Value Added (GVA), and sector balance sheets.",
        "provider": "NSSTA / MoSPI",
        "duration_hours": 24.0,
        "level": "advanced",
        "url": "https://igotkarmayogi.gov.in/learn/course/national-accounts",
        "is_tpac_recommended": True,
        "skills": ["National Accounts Statistics (SNA 2008)", "Industrial Statistics (IIP & ASI)"],
    },
    {
        "igot_course_id": "IGOT-STAT-003",
        "title": "Price Index Numbers: CPI & WPI Compilation",
        "description": "Index number theory, Laspeyres and Paasche formulas, weighting diagrams, price collection mechanisms, and headline inflation tracking.",
        "provider": "MoSPI Prices Wing",
        "duration_hours": 14.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/price-indices",
        "is_tpac_recommended": True,
        "skills": ["Price Statistics (CPI & WPI)"],
    },
    {
        "igot_course_id": "IGOT-STAT-004",
        "title": "Periodic Labour Force Survey (PLFS) Concepts & Estimation",
        "description": "Methodologies for estimating Worker Population Ratio (WPR), Labour Force Participation Rate (LFPR), and activity status.",
        "provider": "NSSO / NSSTA",
        "duration_hours": 16.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/plfs-methodology",
        "is_tpac_recommended": True,
        "skills": ["Labour Statistics & PLFS", "Sampling Techniques & Estimation"],
    },
    {
        "igot_course_id": "IGOT-STAT-005",
        "title": "Agricultural Statistics & Crop Estimation Methodologies",
        "description": "General Crop Estimation Survey (GCES), land-use classifications, and integration of remote sensing with agricultural surveys.",
        "provider": "MoSPI Agriculture Division",
        "duration_hours": 12.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/agricultural-statistics",
        "is_tpac_recommended": False,
        "skills": ["Agricultural Statistics & Crop Estimation"],
    },
    {
        "igot_course_id": "IGOT-STAT-006",
        "title": "SDG National Indicator Framework (NIF) Monitoring",
        "description": "Alignment of official indicators with UN Sustainable Development Goals, baseline setting, and periodic progress tracking.",
        "provider": "MoSPI Social Statistics",
        "duration_hours": 10.0,
        "level": "beginner",
        "url": "https://igotkarmayogi.gov.in/learn/course/sdg-monitoring",
        "is_tpac_recommended": True,
        "skills": ["SDG Indicators & Monitoring Framework", "Metadata Standards (SDMX)"],
    },
    {
        "igot_course_id": "IGOT-STAT-007",
        "title": "Data Quality Assurance Frameworks (DQAF) in Official Surveys",
        "description": "International quality frameworks, non-sampling error detection, imputation algorithms, and survey audit methodologies.",
        "provider": "NSSTA",
        "duration_hours": 15.0,
        "level": "advanced",
        "url": "https://igotkarmayogi.gov.in/learn/course/dqaf-quality-framework",
        "is_tpac_recommended": True,
        "skills": ["Data Quality Assurance Frameworks", "Survey Design & Questionnaire Formulation"],
    },

    # 2. Technical Courses
    {
        "igot_course_id": "IGOT-TECH-001",
        "title": "Python for Official Statistics & Microdata Analysis",
        "description": "Hands-on data cleaning, tabulation, and automated report generation for large sample survey microdata using Python, Pandas, and SciPy.",
        "provider": "iGOT Karmayogi",
        "duration_hours": 30.0,
        "level": "beginner",
        "url": "https://igotkarmayogi.gov.in/learn/course/python-statistics",
        "is_tpac_recommended": True,
        "skills": ["Python for Statistical Computing", "Data Visualization & Power BI / Tableau"],
    },
    {
        "igot_course_id": "IGOT-TECH-002",
        "title": "Applied Econometrics & Survey Analysis using R & Stata",
        "description": "Specialized course on survey-weighted regressions, instrumental variables, and impact evaluation using R and Stata for policy research.",
        "provider": "NSSTA",
        "duration_hours": 22.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/r-stata-econometrics",
        "is_tpac_recommended": True,
        "skills": ["R Programming & R-Studio", "Stata for Econometrics & Surveys"],
    },
    {
        "igot_course_id": "IGOT-TECH-003",
        "title": "SQL & Relational Databases for Large Microdata",
        "description": "SQL joins, window functions, database indexing, and query optimization for NSS and Census microdata tables.",
        "provider": "iGOT Karmayogi",
        "duration_hours": 16.0,
        "level": "beginner",
        "url": "https://igotkarmayogi.gov.in/learn/course/sql-microdata",
        "is_tpac_recommended": False,
        "skills": ["SQL & Relational Databases"],
    },
    {
        "igot_course_id": "IGOT-TECH-004",
        "title": "GIS & Spatial Sampling Boundaries with QGIS",
        "description": "Geotagging field locations, creating primary sampling units using satellite imagery, and spatial statistics in QGIS.",
        "provider": "NSSTA / Survey of India",
        "duration_hours": 20.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/qgis-spatial-statistics",
        "is_tpac_recommended": True,
        "skills": ["GIS & Spatial Data Analysis (QGIS)"],
    },
    {
        "igot_course_id": "IGOT-TECH-005",
        "title": "Interactive Data Visualization & Dashboards (Power BI)",
        "description": "Transforming static statistical releases into dynamic interactive executive dashboards for policymaker consumption.",
        "provider": "iGOT Karmayogi",
        "duration_hours": 15.0,
        "level": "beginner",
        "url": "https://igotkarmayogi.gov.in/learn/course/powerbi-visuals",
        "is_tpac_recommended": True,
        "skills": ["Data Visualization & Power BI / Tableau"],
    },
    {
        "igot_course_id": "IGOT-TECH-006",
        "title": "AI & Machine Learning for Survey Data Validation",
        "description": "Applying machine learning algorithms to detect anomalies, outliers, and fraudulent survey records in field microdata.",
        "provider": "MoSPI DIID",
        "duration_hours": 25.0,
        "level": "advanced",
        "url": "https://igotkarmayogi.gov.in/learn/course/ai-ml-data-quality",
        "is_tpac_recommended": True,
        "skills": ["AI / Machine Learning for Data Quality", "Python for Statistical Computing"],
    },
    {
        "igot_course_id": "IGOT-TECH-007",
        "title": "Statistical APIs & Open Data Dissemination (SDMX)",
        "description": "Developing REST APIs for official datasets, complying with NDAP and international SDMX data exchange specifications.",
        "provider": "MoSPI Computer Centre",
        "duration_hours": 12.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/statistical-apis-sdmx",
        "is_tpac_recommended": False,
        "skills": ["Statistical APIs & Open Data Dissemination", "Metadata Standards (SDMX)"],
    },

    # 3. Digital Governance Courses
    {
        "igot_course_id": "IGOT-GOV-001",
        "title": "Data Privacy, DPDP Act 2023 & Cybersecurity in Government",
        "description": "Mandatory training on the Digital Personal Data Protection Act, secure data handling, CERT-In compliance, and citizen data safeguards.",
        "provider": "iGOT Karmayogi",
        "duration_hours": 8.0,
        "level": "beginner",
        "url": "https://igotkarmayogi.gov.in/learn/course/dpdp-cybersecurity",
        "is_tpac_recommended": False,
        "skills": ["Data Privacy & DPDP Act 2023", "Cybersecurity & CERT-In Guidelines"],
    },
    {
        "igot_course_id": "IGOT-GOV-002",
        "title": "Government Cloud Computing on MeghRaj for Statistics",
        "description": "Hosting high-frequency economic pipelines on National Informatics Centre's MeghRaj GI Cloud securely.",
        "provider": "NIC / MeitY",
        "duration_hours": 14.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/meghraj-cloud",
        "is_tpac_recommended": True,
        "skills": ["Government Cloud (MeghRaj)", "Cloud Computing & Big Data Analytics"],
    },
    {
        "igot_course_id": "IGOT-GOV-003",
        "title": "Digital Signatures & Paperless e-Office Operations",
        "description": "Managing DSC tokens, document encryption, and automated workflow tracking inside the e-Office framework.",
        "provider": "iGOT Karmayogi",
        "duration_hours": 6.0,
        "level": "beginner",
        "url": "https://igotkarmayogi.gov.in/learn/course/e-office-operations",
        "is_tpac_recommended": False,
        "skills": ["Digital Signatures & e-Office Operations"],
    },
    {
        "igot_course_id": "IGOT-GOV-004",
        "title": "Digital Public Infrastructure (DPI) & India Stack Integration",
        "description": "Harnessing Aadhaar authentication, DigiLocker, and UPI transactional data streams for statistical compilation.",
        "provider": "iGOT Karmayogi",
        "duration_hours": 10.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/dpi-india-stack",
        "is_tpac_recommended": True,
        "skills": ["Digital Public Infrastructure (DPI)"],
    },

    # 4. Behavioural & Managerial Courses
    {
        "igot_course_id": "IGOT-MGT-001",
        "title": "Statistical Ethics, Leadership & Field Survey Management",
        "description": "Guidance on UN Fundamental Principles of Official Statistics, managing field enumerators, conflict resolution, and quality inspection.",
        "provider": "NSSTA",
        "duration_hours": 12.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/statistical-ethics-leadership",
        "is_tpac_recommended": True,
        "skills": ["Statistical Ethics & Code of Practice", "Leadership & Team Management", "Project Management in Statistical Operations"],
    },
    {
        "igot_course_id": "IGOT-MGT-002",
        "title": "Effective Communication & Dissemination of Official Statistics",
        "description": "Translating technical statistical indices into clear press releases, infographics, and policy briefs for decision-makers.",
        "provider": "NSSTA",
        "duration_hours": 10.0,
        "level": "beginner",
        "url": "https://igotkarmayogi.gov.in/learn/course/statistical-communication",
        "is_tpac_recommended": True,
        "skills": ["Communication & Statistical Dissemination"],
    },
    {
        "igot_course_id": "IGOT-MGT-003",
        "title": "Project Management for Large-Scale Field Surveys",
        "description": "Work breakdown structures, budget tracking, field monitoring protocols, and risk mitigation in nationwide surveys.",
        "provider": "NSSTA",
        "duration_hours": 18.0,
        "level": "advanced",
        "url": "https://igotkarmayogi.gov.in/learn/course/survey-project-management",
        "is_tpac_recommended": True,
        "skills": ["Project Management in Statistical Operations", "Leadership & Team Management"],
    },
    {
        "igot_course_id": "IGOT-MGT-004",
        "title": "Change Management & CAPI Digital Transformation",
        "description": "Managing the organizational transition from Paper-Assisted Personal Interview (PAPI) to Computer-Assisted Personal Interview (CAPI).",
        "provider": "NSSTA",
        "duration_hours": 12.0,
        "level": "intermediate",
        "url": "https://igotkarmayogi.gov.in/learn/course/capi-change-management",
        "is_tpac_recommended": True,
        "skills": ["Change Management & Technology Adoption"],
    },
]

ROLE_REQUIREMENTS = {
    "Statistical Officer": [
        ("Survey Design & Questionnaire Formulation", 4, "high"),
        ("Sampling Techniques & Estimation", 4, "critical"),
        ("National Accounts Statistics (SNA 2008)", 3, "medium"),
        ("Price Statistics (CPI & WPI)", 3, "medium"),
        ("Python for Statistical Computing", 3, "high"),
        ("Statistical Ethics & Code of Practice", 4, "high"),
    ],
    "Data Analyst": [
        ("Python for Statistical Computing", 4, "critical"),
        ("R Programming & R-Studio", 4, "high"),
        ("SQL & Relational Databases", 4, "critical"),
        ("Data Visualization & Power BI / Tableau", 4, "high"),
        ("AI / Machine Learning for Data Quality", 3, "medium"),
        ("Data Quality Assurance Frameworks", 3, "medium"),
    ],
    "Senior Statistical Officer": [
        ("Sampling Techniques & Estimation", 5, "critical"),
        ("National Accounts Statistics (SNA 2008)", 5, "critical"),
        ("Leadership & Team Management", 4, "high"),
        ("Project Management in Statistical Operations", 4, "high"),
        ("Data Quality Assurance Frameworks", 4, "high"),
        ("Data Privacy & DPDP Act 2023", 4, "high"),
    ],
}


def run():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        # 1. Seed Roles
        role_objs = {}
        for name in DEFAULT_ROLES:
            r = db.query(Role).filter(Role.name == name).first()
            if not r:
                r = Role(name=name, description=f"{name} role")
                db.add(r)
                db.commit()
                db.refresh(r)
            role_objs[name] = r

        # 2. Seed Departments
        dept_objs = {}
        for name, code, desc in DEFAULT_DEPARTMENTS:
            d = db.query(Department).filter(Department.code == code).first()
            if not d:
                d = Department(name=name, code=code, description=desc)
                db.add(d)
                db.commit()
                db.refresh(d)
            dept_objs[code] = d

        # 3. Seed Competency Domains
        domain_objs = {}
        for name, category, desc in DEFAULT_DOMAINS:
            domain = db.query(CompetencyDomain).filter(CompetencyDomain.name == name).first()
            if not domain:
                domain = CompetencyDomain(name=name, category=category, description=desc)
                db.add(domain)
                db.commit()
                db.refresh(domain)
            domain_objs[name] = domain

        # 4. Seed Individual Skills
        skill_objs = {}
        for domain_name, skills in DEFAULT_SKILLS.items():
            domain = domain_objs.get(domain_name)
            if not domain:
                continue
            for skill_name, skill_desc, max_lvl in skills:
                skill = db.query(Skill).filter(Skill.domain_id == domain.id, Skill.name == skill_name).first()
                if not skill:
                    skill = Skill(domain_id=domain.id, name=skill_name, description=skill_desc, max_level=max_lvl)
                    db.add(skill)
                    db.commit()
                    db.refresh(skill)
                skill_objs[skill_name] = skill

        # 5. Seed Courses with Tags
        course_objs = {}
        for c_data in DEFAULT_COURSES:
            course = db.query(Course).filter(Course.igot_course_id == c_data["igot_course_id"]).first()
            if not course:
                course = Course(
                    igot_course_id=c_data["igot_course_id"],
                    title=c_data["title"],
                    description=c_data["description"],
                    provider=c_data["provider"],
                    duration_hours=c_data["duration_hours"],
                    level=c_data["level"],
                    url=c_data["url"],
                    is_tpac_recommended=c_data["is_tpac_recommended"],
                )
                db.add(course)
                db.commit()
                db.refresh(course)

                for sk_name in c_data.get("skills", []):
                    sk = skill_objs.get(sk_name)
                    if sk:
                        db.add(CourseSkillTag(course_id=course.id, skill_id=sk.id, relevance_score=1.0))
                db.commit()
            course_objs[c_data["igot_course_id"]] = course

        # 6. Seed Role Requirements
        for role_name, reqs in ROLE_REQUIREMENTS.items():
            r_obj = role_objs.get(role_name)
            if not r_obj:
                continue
            for sk_name, req_lvl, prio in reqs:
                sk_obj = skill_objs.get(sk_name)
                if not sk_obj:
                    continue
                req_entry = db.query(RoleRequirement).filter(
                    RoleRequirement.role_id == r_obj.id,
                    RoleRequirement.skill_id == sk_obj.id,
                ).first()
                if not req_entry:
                    db.add(RoleRequirement(
                        role_id=r_obj.id,
                        skill_id=sk_obj.id,
                        required_level=req_lvl,
                        priority=prio,
                    ))
        db.commit()

        # 7. Seed Demo Personas
        nssta_dept = dept_objs.get("NSSTA")
        diid_dept = dept_objs.get("DIID")
        nad_dept = dept_objs.get("NAD")

        demo_personas = [
            {
                "employee_code": "ADMIN001",
                "name": "Dr. Arun Mehra (Director General)",
                "email": "admin@nssta.gov.in",
                "password": "ChangeMe123!",
                "designation": "Head of Academy / System Administrator",
                "role": "admin",
                "department_id": nssta_dept.id if nssta_dept else None,
                "experience": 22.0,
                "competencies": {
                    "Leadership & Team Management": 5,
                    "Statistical Ethics & Code of Practice": 5,
                    "Project Management in Statistical Operations": 5,
                    "Cybersecurity & CERT-In Guidelines": 4,
                }
            },
            {
                "employee_code": "JSO1042",
                "name": "Karthikeya Sharma",
                "email": "karthikeya@mospi.gov.in",
                "password": "SecurePassword123!",
                "designation": "Junior Statistical Officer (JSO)",
                "role": "Statistical Officer",
                "department_id": nssta_dept.id if nssta_dept else None,
                "experience": 3.5,
                "competencies": {
                    "Survey Design & Questionnaire Formulation": 2,
                    "Sampling Techniques & Estimation": 1,
                    "National Accounts Statistics (SNA 2008)": 2,
                    "Price Statistics (CPI & WPI)": 2,
                    "Python for Statistical Computing": 2,
                    "Statistical Ethics & Code of Practice": 3,
                }
            },
            {
                "employee_code": "ANA2045",
                "name": "Priya Nair",
                "email": "priya.nair@mospi.gov.in",
                "password": "SecurePassword123!",
                "designation": "Assistant Director / Data Analyst",
                "role": "Data Analyst",
                "department_id": diid_dept.id if diid_dept else None,
                "experience": 5.0,
                "competencies": {
                    "Python for Statistical Computing": 3,
                    "R Programming & R-Studio": 2,
                    "SQL & Relational Databases": 3,
                    "Data Visualization & Power BI / Tableau": 3,
                    "AI / Machine Learning for Data Quality": 2,
                    "Data Quality Assurance Frameworks": 2,
                }
            },
            {
                "employee_code": "SSO3091",
                "name": "Rajesh Verma",
                "email": "rajesh.verma@mospi.gov.in",
                "password": "SecurePassword123!",
                "designation": "Senior Statistical Officer (SSO)",
                "role": "Senior Statistical Officer",
                "department_id": nad_dept.id if nad_dept else None,
                "experience": 11.0,
                "competencies": {
                    "Sampling Techniques & Estimation": 4,
                    "National Accounts Statistics (SNA 2008)": 3,
                    "Leadership & Team Management": 3,
                    "Project Management in Statistical Operations": 3,
                    "Data Quality Assurance Frameworks": 3,
                    "Data Privacy & DPDP Act 2023": 3,
                }
            },
        ]

        for p_data in demo_personas:
            official = db.query(Official).filter(Official.email == p_data["email"]).first()
            role_obj = role_objs.get(p_data["role"])
            if not official:
                official = Official(
                    employee_code=p_data["employee_code"],
                    name=p_data["name"],
                    email=p_data["email"],
                    password_hash=hash_password(p_data["password"]),
                    designation=p_data["designation"],
                    role_id=role_obj.id if role_obj else None,
                    department_id=p_data["department_id"],
                    work_experience_years=p_data["experience"],
                )
                db.add(official)
                db.commit()
                db.refresh(official)
            else:
                # Update role and designation to ensure consistency
                if role_obj:
                    official.role_id = role_obj.id
                official.name = p_data["name"]
                official.designation = p_data["designation"]
                if p_data["department_id"]:
                    official.department_id = p_data["department_id"]
                db.commit()

            # Seed competencies
            for sk_name, lvl in p_data["competencies"].items():
                sk = skill_objs.get(sk_name)
                if not sk:
                    continue
                comp = db.query(OfficialCompetency).filter(
                    OfficialCompetency.official_id == official.id,
                    OfficialCompetency.skill_id == sk.id,
                ).first()
                if not comp:
                    db.add(OfficialCompetency(
                        official_id=official.id,
                        skill_id=sk.id,
                        current_level=lvl,
                        target_level=min(lvl + 1, 5),
                        assessment_source="self",
                    ))
                else:
                    comp.current_level = lvl
            db.commit()

            # Seed Progress & Quiz attempts for demo learners
            if p_data["role"] in ("Statistical Officer", "Data Analyst", "Senior Statistical Officer"):
                c1 = course_objs.get("IGOT-STAT-001")
                c3 = course_objs.get("IGOT-TECH-001")
                if c1:
                    prog1 = db.query(Progress).filter(Progress.official_id == official.id, Progress.course_id == c1.id).first()
                    if not prog1:
                        db.add(Progress(official_id=official.id, course_id=c1.id, completion=100.0, learning_hours=18.5))
                if c3:
                    prog2 = db.query(Progress).filter(Progress.official_id == official.id, Progress.course_id == c3.id).first()
                    if not prog2:
                        db.add(Progress(official_id=official.id, course_id=c3.id, completion=65.0, learning_hours=20.0))
                db.commit()

        print("Seeding successfully finished!")
        print("- 6 Roles verified")
        print("- 6 Departments created")
        print("- 4 Domains and 32 Skills configured")
        print("- 22 iGOT / NSSTA TPAC Courses seeded")
        print("- All 4 Demo Personas (Admin, Karthikeya, Priya, Rajesh) active with role competencies")
    finally:
        db.close()


if __name__ == "__main__":
    run()
