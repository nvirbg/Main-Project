# AI-Enabled Skill Intelligence & Learning Platform — Backend

FastAPI backend for the SIH problem statement: competency-gap assessment,
personalized learning recommendations integrated with **iGOT Karmayogi**, and
an AI-powered engine that generates quizzes/MCQs from uploaded learning
material — for officials in India's Official Statistical System.

Built to match an 18-table MySQL schema: `roles`, `departments`, `officials`,
`refresh_tokens`, `competency_domains`, `skills`, `official_competencies`,
`skill_history`, `courses`, `course_skill_tags`, `recommendations`,
`documents`, `quizzes`, `questions`, `question_options`, `quiz_attempts`,
`quiz_attempt_answers`, `audit_logs`.

## 1. Setup

```bash
cd sih_backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then fill in DATABASE_URL, SECRET_KEY, ANTHROPIC_API_KEY, etc.
```

Create the MySQL database first:

```sql
CREATE DATABASE sih_skill_platform CHARACTER SET utf8mb4;
```

## 2. Initialize tables + seed data

Tables auto-create on app startup, but you can also do it explicitly and seed
default roles / competency domains / a demo admin:

```bash
python -m scripts.seed
```

This creates `admin@nssta.gov.in` / `ChangeMe123!` — **change this immediately
in any real deployment.**

## 3. Run

```bash
uvicorn app.main:app --reload --port 8000
```

Interactive API docs: `http://localhost:8000/docs`

## 4. Frontend Integration Endpoints (React / Vite)

All endpoints accept and return JSON. CORS is enabled for all origins (`*`).
Base URL: `http://localhost:8000`

| Method | Endpoint | Description | Auth Required? |
| :--- | :--- | :--- | :--- |
| `POST` | `/auth/login` | Returns JWT `{access_token, refresh_token}` | No |
| `POST` | `/auth/register` | Register new official | No |
| `GET` | `/profile` | Current official profile + competencies | Bearer JWT |
| `PUT` | `/profile` | Update profile / designation / role | Bearer JWT |
| `GET` | `/skill-gaps` | Ranked skill gaps against role requirements | Bearer JWT |
| `GET` | `/recommendations` | Personalized courses with match reasons | Bearer JWT |
| `GET` | `/courses` | Complete course catalogue | No |
| `POST` | `/quiz/generate` | Generate MCQs from text or document | Bearer JWT |
| `POST` | `/quiz/submit` | Submit answers, get instant score & explanation | Bearer JWT |
| `POST` | `/assistant/chat` | AI Assistant for statistical queries & courses | Bearer JWT |
| `GET` | `/dashboard/learner` | Chart-ready stats for Learner Dashboard | Bearer JWT |
| `GET` | `/dashboard/admin` | Chart-ready workforce analytics (Admin only) | Bearer JWT (Admin) |
| `GET` | `/integration/igot/courses` | iGOT Karmayogi course catalogue adapter | No |
| `POST` | `/documents/upload` | Upload PDF/DOCX/PPTX learning material | Bearer JWT |

### Demo Accounts
- **Admin**: `admin@nssta.gov.in` / `ChangeMe123!`
- **Official (JSO)**: `karthikeya@mospi.gov.in` / `SecurePassword123!`

**Auth**
- `POST /auth/register` — create an official account
- `POST /auth/login` — returns access + refresh JWT
- `POST /auth/refresh` — rotate tokens
- `GET  /auth/me`

**Competency profiling & gap analysis**
- `GET/POST /competencies/domains`, `/competencies/skills`
- `PUT  /competencies/me` — set current/target level for a skill
- `GET  /competencies/me/gaps` — computed skill-gap list, sorted by size of gap
- `GET  /competencies/{official_id}/gaps` — admin/trainer view

**Courses & iGOT integration**
- `GET/POST /courses` — catalogue + skill tagging (`course_skill_tags`)
- `POST /courses/sync-igot` — stub for the iGOT Karmayogi catalogue sync job;
  wire in real HTTP calls once API credentials/contracts are available
  (see `app/routers/courses.py`)

**Personalized recommendations**
- `POST /recommendations/me/generate` — blends structural skill-tag matching
  (70%) with TF-IDF semantic similarity (30%) between the official's skill
  gaps and course descriptions (`app/services/recommender.py`)
- `GET  /recommendations/me`

**AI-generated quizzes from uploaded material**
- `POST /documents/upload` — upload pdf/docx/pptx/txt, text auto-extracted
- `POST /quizzes/generate` — LLM (Claude) generates MCQs + explanations from
  the extracted text (`app/services/quiz_generator.py`); strictly validates
  exactly 4 options / 1 correct answer per question
- `POST /quizzes/{quiz_id}/start` → `POST /quizzes/attempts/{id}/submit` —
  scored instantly; a strong/weak result nudges `official_competencies` and
  logs to `skill_history` (`app/services/competency_engine.py`)

**Dashboards**
- `GET /dashboard/me` — employee view: current competencies, gaps,
  recommended paths, learning hours, overall progress
- `GET /dashboard/admin/overview` — admin view: org-wide competency
  distribution, top skill gaps, avg quiz score, recommendation completion rate

**Audit**
- `GET /audit-logs` — admin-only, every login/quiz/competency/recommendation
  event is logged (`app/services/audit_service.py`)

## 5. Design notes / what to extend for production

- **iGOT sync**: `courses.py::sync_igot_catalogue` is a stub. Replace with real
  `httpx` calls against `IGOT_API_BASE_URL` to pull catalogue, enrolment and
  completion status, then upsert `courses` / update `recommendations.status`.
- **Semantic search**: recommender uses TF-IDF for a lightweight, dependency-light
  semantic match. Swap in embeddings (e.g. a sentence-transformer or an
  embeddings API) for stronger semantic matching at scale.
- **RBAC**: role-based access is enforced via `app/deps.py::require_roles`;
  roles are rows in `roles` (`admin`, `trainer`, `official` seeded by default).
- **Migrations**: `Base.metadata.create_all` is used for fast bootstrapping.
  Move to Alembic (`alembic init`) once the schema stabilizes.
- **SSO**: current auth is username/password + JWT. For government SSO,
  add an OIDC/SAML flow in `app/routers/auth.py` that issues the same
  internal JWTs after federated login.
