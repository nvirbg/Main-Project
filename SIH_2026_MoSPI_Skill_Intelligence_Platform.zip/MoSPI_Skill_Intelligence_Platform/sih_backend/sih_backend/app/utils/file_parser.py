"""Extracts plain text from uploaded learning materials (pdf, docx, pptx, txt)
so it can be fed to the LLM for MCQ / quiz generation.
"""
import os


def extract_text(file_path: str, file_type: str) -> str:
    file_type = file_type.lower().lstrip(".")

    if file_type == "pdf":
        return _extract_pdf(file_path)
    if file_type == "docx":
        return _extract_docx(file_path)
    if file_type == "pptx":
        return _extract_pptx(file_path)
    if file_type in ("txt", "md"):
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    raise ValueError(f"Unsupported file type for text extraction: {file_type}")


def _extract_pdf(path: str) -> str:
    import pdfplumber

    text_chunks = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text()
            if page_text:
                text_chunks.append(page_text)
    return "\n".join(text_chunks)


def _extract_docx(path: str) -> str:
    import docx

    doc = docx.Document(path)
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())


def _extract_pptx(path: str) -> str:
    from pptx import Presentation

    prs = Presentation(path)
    chunks = []
    for slide in prs.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                chunks.append(shape.text)
    return "\n".join(chunks)


def infer_file_type(filename: str) -> str:
    return os.path.splitext(filename)[1].lstrip(".").lower()
