from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr, ConfigDict


# --------------------------------------------------------------- auth ---
class OfficialRegister(BaseModel):
    employee_code: str
    name: str
    email: EmailStr
    password: str
    designation: Optional[str] = None
    department_id: Optional[int] = None
    department_name: Optional[str] = None
    role_id: Optional[int] = None
    role_name: Optional[str] = None
    qualification: Optional[str] = None
    work_experience_years: Optional[float] = 0
    initial_skills: Optional[dict[str, int]] = None


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user: Optional["OfficialOut"] = None


class RefreshRequest(BaseModel):
    refresh_token: str


class OfficialOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    employee_code: str
    name: str
    email: str
    designation: Optional[str] = None
    department_id: Optional[int] = None
    department_name: Optional[str] = None
    role_id: Optional[int] = None
    role_name: Optional[str] = None
    work_experience_years: Optional[float] = None
    is_active: bool
    access_token: Optional[str] = None
    refresh_token: Optional[str] = None


# --------------------------------------------------------- competencies ---
class DomainOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    category: str
    description: Optional[str] = None


class SkillCreate(BaseModel):
    domain_id: int
    name: str
    description: Optional[str] = None
    max_level: int = 5


class SkillOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    domain_id: int
    name: str
    description: Optional[str] = None
    max_level: int


class CompetencyUpdate(BaseModel):
    skill_id: int
    current_level: int
    target_level: Optional[int] = None
    assessment_source: str = "self"


class CompetencyOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    skill_id: int
    current_level: int
    target_level: int
    assessment_source: str
    assessed_at: datetime


class SkillGapItem(BaseModel):
    skill_id: int
    skill_name: str
    domain: str
    current_level: int
    target_level: int
    gap: int


# -------------------------------------------------------------- courses ---
class CourseCreate(BaseModel):
    igot_course_id: Optional[str] = None
    title: str
    description: Optional[str] = None
    provider: str = "iGOT Karmayogi"
    duration_hours: float = 0
    level: str = "beginner"
    url: Optional[str] = None
    is_tpac_recommended: bool = False
    skill_ids: list[int] = []


class CourseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    igot_course_id: Optional[str] = None
    title: str
    description: Optional[str] = None
    provider: str
    duration_hours: float
    level: str
    url: Optional[str] = None
    is_tpac_recommended: bool
    category: Optional[str] = None
    skills: list[str] = []


# -------------------------------------------------------- recommendations -
class RecommendationOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    course_id: int
    source: str
    score: float
    reason: Optional[str] = None
    status: str
    recommended_at: datetime


# ------------------------------------------------------------- documents --
class DocumentOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    file_type: Optional[str] = None
    processed: bool
    uploaded_at: datetime


# ---------------------------------------------------------------- quizzes -
class OptionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    option_text: str
    # is_correct intentionally excluded from learner-facing responses


class OptionWithAnswerOut(OptionOut):
    is_correct: bool


class QuestionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    question_text: str
    question_type: str
    difficulty: str
    options: list[OptionOut]


class QuizGenerateRequest(BaseModel):
    document_id: int
    num_questions: int = 10
    difficulty: str = "medium"  # easy | medium | hard
    skill_id: Optional[int] = None
    course_id: Optional[int] = None


class QuizOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    generated_by: str
    difficulty: str
    created_at: datetime
    questions: list[QuestionOut] = []


class AttemptStartOut(BaseModel):
    attempt_id: int
    quiz: QuizOut


class AnswerSubmit(BaseModel):
    question_id: int
    selected_option_id: Optional[int] = None


class AttemptSubmitRequest(BaseModel):
    answers: list[AnswerSubmit]


class AttemptResultOut(BaseModel):
    attempt_id: int
    score: float
    total_questions: int
    correct_count: int
    percentage: float
    skill_updates: list[dict] = []
