from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Official, Role
from app.security import decode_token

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_current_official(
    token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)
) -> Official:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            raise credentials_exception
        official_id = payload.get("sub")
        if official_id is None:
            raise credentials_exception
    except ValueError:
        raise credentials_exception

    official = db.query(Official).filter(Official.id == int(official_id)).first()
    if official is None or not official.is_active:
        raise credentials_exception
    return official


def require_roles(*role_names: str):
    """Dependency factory: restricts an endpoint to given role names, e.g. require_roles('admin'). Case-insensitive."""

    allowed = {r.strip().lower() for r in role_names}
    if "admin" in allowed:
        allowed.add("administrator")

    def checker(official: Official = Depends(get_current_official), db: Session = Depends(get_db)):
        role = None
        if official.role_id:
            role = db.query(Role).filter(Role.id == official.role_id).first()
        elif official.role:
            role = official.role

        role_name = (role.name if role else (official.designation or "")).lower()
        if not any(a in role_name for a in allowed):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires one of roles: {role_names}",
            )
        return official

    return checker


oauth2_scheme_optional = OAuth2PasswordBearer(tokenUrl="/auth/login", auto_error=False)


def get_optional_official(
    token: str | None = Depends(oauth2_scheme_optional), db: Session = Depends(get_db)
) -> Official | None:
    """Returns Official if a valid Bearer token is provided, otherwise None without raising 401."""
    if not token:
        return None
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            return None
        official_id = payload.get("sub")
        if official_id is None:
            return None
        return db.query(Official).filter(Official.id == int(official_id), Official.is_active == True).first()
    except Exception:
        return None
