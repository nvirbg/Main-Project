from sqlalchemy.orm import Session

from app.models import AuditLog


def log_action(
    db: Session,
    official_id: int | None,
    action: str,
    entity_type: str | None = None,
    entity_id: int | None = None,
    details: dict | None = None,
    ip_address: str | None = None,
):
    entry = AuditLog(
        official_id=official_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        details=details or {},
        ip_address=ip_address,
    )
    db.add(entry)
    db.commit()
    return entry
