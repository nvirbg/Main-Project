"""AI-powered Intelligent Assessment Engine.

Generates MCQs + explanations from uploaded learning material text using an
LLM (Claude). Falls back to a clear error if no API key is configured, so the
rest of the platform still runs without an LLM key during local dev/demo.
"""
import json
import re

from app.config import settings

SYSTEM_PROMPT = (
    "You are an expert item-writer for a government statistical-training platform "
    "(India's Official Statistical System / iGOT Karmayogi). You write rigorous, "
    "unambiguous multiple-choice questions strictly grounded in the supplied source "
    "material. Respond with ONLY valid JSON — no markdown fences, no preamble."
)

USER_PROMPT_TEMPLATE = """Generate {num_questions} multiple-choice questions at "{difficulty}" \
difficulty from the SOURCE MATERIAL below.

Rules:
- Each question must have exactly 4 options, exactly one correct.
- Base every question strictly on facts present in the source material.
- Avoid duplicate or trivially similar questions.
- Include a one-to-two sentence explanation for why the correct answer is right.

Return JSON matching exactly this schema:
{{
  "questions": [
    {{
      "question_text": "...",
      "options": [
        {{"text": "...", "is_correct": true}},
        {{"text": "...", "is_correct": false}},
        {{"text": "...", "is_correct": false}},
        {{"text": "...", "is_correct": false}}
      ],
      "explanation": "..."
    }}
  ]
}}

SOURCE MATERIAL:
\"\"\"
{source_text}
\"\"\"
"""

MAX_SOURCE_CHARS = 12000  # keep prompt within a reasonable context budget


def _call_llm(system: str, user: str) -> str:
    if not settings.ANTHROPIC_API_KEY:
        raise RuntimeError(
            "ANTHROPIC_API_KEY is not configured. Set it in .env to enable AI quiz generation."
        )
    import anthropic

    client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
    response = client.messages.create(
        model=settings.LLM_MODEL,
        max_tokens=4000,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def _strip_code_fences(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(json)?", "", text).strip()
    text = re.sub(r"```$", "", text).strip()
    return text


def generate_mcqs(source_text: str, num_questions: int = 10, difficulty: str = "medium") -> list[dict]:
    if not source_text or not source_text.strip():
        raise ValueError("Cannot generate a quiz from empty document text.")

    trimmed_text = source_text[:MAX_SOURCE_CHARS]
    user_prompt = USER_PROMPT_TEMPLATE.format(
        num_questions=num_questions, difficulty=difficulty, source_text=trimmed_text
    )

    raw = _call_llm(SYSTEM_PROMPT, user_prompt)
    cleaned = _strip_code_fences(raw)

    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"LLM did not return valid JSON: {exc}\nRaw output: {raw[:500]}")

    questions = parsed.get("questions", [])
    _validate_questions(questions)
    return questions


def _validate_questions(questions: list[dict]) -> None:
    if not questions:
        raise RuntimeError("LLM returned zero questions.")
    for q in questions:
        opts = q.get("options", [])
        if len(opts) < 2:
            raise RuntimeError(f"Question has fewer than 2 options: {q.get('question_text')}")
        correct_count = sum(1 for o in opts if o.get("is_correct"))
        if correct_count != 1:
            raise RuntimeError(
                f"Question must have exactly one correct option, found {correct_count}: "
                f"{q.get('question_text')}"
            )
