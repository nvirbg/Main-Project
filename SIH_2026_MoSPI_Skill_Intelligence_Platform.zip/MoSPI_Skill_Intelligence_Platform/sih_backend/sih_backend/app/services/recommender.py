"""Skill-gap analysis + personalized learning-path recommendation engine.

Two signals are combined:
1. Structural match: courses explicitly tagged (course_skill_tags) against a
   gapped skill, weighted by the tag's relevance_score and the size of the gap.
2. Semantic match: TF-IDF cosine similarity between the textual description of
   the official's skill gaps and each course's description, to surface
   relevant courses even where explicit tagging is incomplete (a lightweight
   stand-in for the NLP / semantic-search component called for in the
   problem statement).
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sqlalchemy.orm import Session

from app.models import Course, CourseSkillTag, CompetencyDomain, OfficialCompetency, Skill


def compute_skill_gaps(db: Session, official_id: int) -> list[dict]:
    rows = (
        db.query(OfficialCompetency, Skill, CompetencyDomain)
        .join(Skill, Skill.id == OfficialCompetency.skill_id)
        .join(CompetencyDomain, CompetencyDomain.id == Skill.domain_id)
        .filter(OfficialCompetency.official_id == official_id)
        .all()
    )
    gaps = []
    for comp, skill, domain in rows:
        gap = comp.target_level - comp.current_level
        if gap > 0:
            gaps.append(
                {
                    "skill_id": skill.id,
                    "skill_name": skill.name,
                    "domain": domain.name,
                    "current_level": comp.current_level,
                    "target_level": comp.target_level,
                    "gap": gap,
                }
            )
    gaps.sort(key=lambda g: g["gap"], reverse=True)
    return gaps


def _structural_scores(db: Session, gaps: list[dict]) -> dict[int, float]:
    """course_id -> score, from explicit course_skill_tags matches."""
    scores: dict[int, float] = {}
    if not gaps:
        return scores
    gap_by_skill = {g["skill_id"]: g["gap"] for g in gaps}
    tags = (
        db.query(CourseSkillTag)
        .filter(CourseSkillTag.skill_id.in_(gap_by_skill.keys()))
        .all()
    )
    for tag in tags:
        weight = tag.relevance_score * gap_by_skill[tag.skill_id]
        scores[tag.course_id] = scores.get(tag.course_id, 0.0) + weight
    return scores


def _semantic_scores(db: Session, gaps: list[dict]) -> dict[int, float]:
    """course_id -> score, from TF-IDF similarity between gap text and course text."""
    if not gaps:
        return {}
    courses = db.query(Course).all()
    if not courses:
        return {}

    gap_text = " ".join(g["skill_name"] for g in gaps)
    corpus = [gap_text] + [f"{c.title} {c.description or ''}" for c in courses]

    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        tfidf = vectorizer.fit_transform(corpus)
    except ValueError:
        return {}  # empty vocabulary (e.g. all courses have blank descriptions)

    sims = cosine_similarity(tfidf[0:1], tfidf[1:]).flatten()
    return {course.id: float(score) for course, score in zip(courses, sims)}


def recommend_courses(db: Session, official_id: int, top_n: int = 10) -> list[dict]:
    gaps = compute_skill_gaps(db, official_id)
    structural = _structural_scores(db, gaps)
    semantic = _semantic_scores(db, gaps)

    all_course_ids = set(structural) | set(semantic)
    if not all_course_ids:
        return []

    # normalize each signal to 0-1, then blend 70/30 structural/semantic
    max_struct = max(structural.values(), default=1) or 1
    max_sem = max(semantic.values(), default=1) or 1

    combined = []
    for course_id in all_course_ids:
        struct_norm = structural.get(course_id, 0.0) / max_struct
        sem_norm = semantic.get(course_id, 0.0) / max_sem
        score = 0.7 * struct_norm + 0.3 * sem_norm
        combined.append((course_id, score))

    combined.sort(key=lambda x: x[1], reverse=True)
    top = combined[:top_n]

    course_map = {c.id: c for c in db.query(Course).filter(Course.id.in_([c_id for c_id, _ in top])).all()}
    results = []
    for course_id, score in top:
        course = course_map.get(course_id)
        if not course:
            continue
        results.append(
            {
                "course_id": course.id,
                "title": course.title,
                "score": round(score, 4),
                "is_tpac_recommended": course.is_tpac_recommended,
                "reason": _build_reason(course, gaps),
            }
        )
    return results


def _build_reason(course: Course, gaps: list[dict]) -> str:
    tagged_skill_ids = {t.skill_id for t in course.skill_tags}
    matched = [g["skill_name"] for g in gaps if g["skill_id"] in tagged_skill_ids]
    if matched:
        return f"Closes gaps in: {', '.join(matched[:3])}"
    return "Semantically relevant to your current skill-gap profile"
