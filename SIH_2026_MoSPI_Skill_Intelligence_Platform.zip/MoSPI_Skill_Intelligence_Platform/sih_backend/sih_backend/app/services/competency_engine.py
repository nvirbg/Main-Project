from sqlalchemy.orm import Session

from app.models import OfficialCompetency, SkillHistory


def apply_quiz_result_to_skill(
    db: Session, official_id: int, skill_id: int, percentage_correct: float, attempt_id: int
) -> dict | None:
    """Nudges an official's current_level for a skill based on quiz performance.

    Simple, explainable rule used for the assessment engine:
      >= 85% -> +1 level (capped at skill.max_level)
      <= 40% -> -1 level (floored at 0)
      otherwise -> no change
    """
    comp = (
        db.query(OfficialCompetency)
        .filter(
            OfficialCompetency.official_id == official_id,
            OfficialCompetency.skill_id == skill_id,
        )
        .first()
    )
    if comp is None:
        comp = OfficialCompetency(
            official_id=official_id, skill_id=skill_id, current_level=0, target_level=3
        )
        db.add(comp)
        db.flush()

    old_level = comp.current_level
    new_level = old_level
    if percentage_correct >= 85:
        new_level = old_level + 1
    elif percentage_correct <= 40:
        new_level = max(0, old_level - 1)

    max_level = comp.skill.max_level if comp.skill else 5
    new_level = min(new_level, max_level)

    if new_level == old_level:
        return None

    comp.current_level = new_level
    comp.assessment_source = "quiz"
    history = SkillHistory(
        official_id=official_id,
        skill_id=skill_id,
        old_level=old_level,
        new_level=new_level,
        reason=f"quiz_attempt#{attempt_id}",
    )
    db.add(history)
    db.commit()
    return {"skill_id": skill_id, "old_level": old_level, "new_level": new_level}
