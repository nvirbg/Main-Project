import enum
from datetime import datetime

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, Float, ForeignKey, Integer,
    JSON, String, Text, UniqueConstraint
)
from sqlalchemy.orm import relationship

from app.database import Base


class CompetencyCategory(str, enum.Enum):
    statistical = "statistical"
    technical = "technical"
    digital_governance = "digital_governance"
    behavioural = "behavioural"


class RecommendationSource(str, enum.Enum):
    igot = "igot"
    tpac = "tpac"
    internal = "internal"


class RecommendationStatus(str, enum.Enum):
    pending = "pending"
    enrolled = "enrolled"
    completed = "completed"
    dismissed = "dismissed"


class QuizGeneratedBy(str, enum.Enum):
    ai = "ai"
    manual = "manual"


class AttemptStatus(str, enum.Enum):
    in_progress = "in_progress"
    submitted = "submitted"
    expired = "expired"


# ---------------------------------------------------------------- roles ----
class Role(Base):
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True, nullable=False)  # e.g. admin, official, trainer
    description = Column(String(255))

    officials = relationship("Official", back_populates="role")
    requirements = relationship("RoleRequirement", back_populates="role")


# ----------------------------------------------------------- departments ---
class Department(Base):
    __tablename__ = "departments"

    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    code = Column(String(30), unique=True)
    description = Column(String(255))

    officials = relationship("Official", back_populates="department")


# ------------------------------------------------------------- officials ---
class Official(Base):
    __tablename__ = "officials"

    id = Column(Integer, primary_key=True)
    employee_code = Column(String(50), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    email = Column(String(150), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    designation = Column(String(150))
    department_id = Column(Integer, ForeignKey("departments.id"))
    role_id = Column(Integer, ForeignKey("roles.id"))
    qualification = Column(String(255))
    work_experience_years = Column(Float, default=0)
    joining_date = Column(DateTime)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    department = relationship("Department", back_populates="officials")
    role = relationship("Role", back_populates="officials")
    competencies = relationship("OfficialCompetency", back_populates="official")
    refresh_tokens = relationship("RefreshToken", back_populates="official")
    recommendations = relationship("Recommendation", back_populates="official")
    quiz_attempts = relationship("QuizAttempt", back_populates="official")
    skill_history = relationship("SkillHistory", back_populates="official")
    documents = relationship("Document", back_populates="uploaded_by_official")
    progress_records = relationship("Progress", back_populates="official")


# -------------------------------------------------------- refresh_tokens ---
class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id = Column(Integer, primary_key=True)
    official_id = Column(Integer, ForeignKey("officials.id"), nullable=False)
    token = Column(String(500), unique=True, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    revoked = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    official = relationship("Official", back_populates="refresh_tokens")


# --------------------------------------------------- competency_domains ---
class CompetencyDomain(Base):
    __tablename__ = "competency_domains"

    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    category = Column(Enum(CompetencyCategory), nullable=False)
    description = Column(Text)

    skills = relationship("Skill", back_populates="domain")


# ------------------------------------------------------------------ skills -
class Skill(Base):
    __tablename__ = "skills"

    id = Column(Integer, primary_key=True)
    domain_id = Column(Integer, ForeignKey("competency_domains.id"), nullable=False)
    name = Column(String(150), nullable=False)
    description = Column(Text)
    max_level = Column(Integer, default=5)  # e.g. proficiency scale 0-5

    domain = relationship("CompetencyDomain", back_populates="skills")
    official_competencies = relationship("OfficialCompetency", back_populates="skill")
    course_tags = relationship("CourseSkillTag", back_populates="skill")
    history = relationship("SkillHistory", back_populates="skill")
    questions = relationship("Question", back_populates="skill")
    role_requirements = relationship("RoleRequirement", back_populates="skill")

    __table_args__ = (UniqueConstraint("domain_id", "name", name="uq_skill_domain_name"),)


# ------------------------------------------------------ official_competencies
class OfficialCompetency(Base):
    __tablename__ = "official_competencies"

    id = Column(Integer, primary_key=True)
    official_id = Column(Integer, ForeignKey("officials.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    current_level = Column(Integer, default=0)
    target_level = Column(Integer, default=3)
    assessment_source = Column(String(50), default="self")  # self, quiz, manager, ai
    assessed_at = Column(DateTime, default=datetime.utcnow)

    official = relationship("Official", back_populates="competencies")
    skill = relationship("Skill", back_populates="official_competencies")

    __table_args__ = (UniqueConstraint("official_id", "skill_id", name="uq_official_skill"),)


# ------------------------------------------------------------ skill_history
class SkillHistory(Base):
    __tablename__ = "skill_history"

    id = Column(Integer, primary_key=True)
    official_id = Column(Integer, ForeignKey("officials.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    old_level = Column(Integer)
    new_level = Column(Integer)
    reason = Column(String(255))  # e.g. "quiz_attempt#42", "manual_update"
    changed_at = Column(DateTime, default=datetime.utcnow)

    official = relationship("Official", back_populates="skill_history")
    skill = relationship("Skill", back_populates="history")


# ------------------------------------------------------------------ courses
class Course(Base):
    __tablename__ = "courses"

    id = Column(Integer, primary_key=True)
    igot_course_id = Column(String(100), unique=True, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text)
    provider = Column(String(150), default="iGOT Karmayogi")
    duration_hours = Column(Float, default=0)
    level = Column(String(30), default="beginner")  # beginner/intermediate/advanced
    url = Column(String(500))
    is_tpac_recommended = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    skill_tags = relationship("CourseSkillTag", back_populates="course")
    recommendations = relationship("Recommendation", back_populates="course")
    quizzes = relationship("Quiz", back_populates="course")
    progress_records = relationship("Progress", back_populates="course")


# ---------------------------------------------------------- course_skill_tags
class CourseSkillTag(Base):
    __tablename__ = "course_skill_tags"

    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    relevance_score = Column(Float, default=1.0)  # 0-1, how central the skill is to the course

    course = relationship("Course", back_populates="skill_tags")
    skill = relationship("Skill", back_populates="course_tags")

    __table_args__ = (UniqueConstraint("course_id", "skill_id", name="uq_course_skill"),)


# ------------------------------------------------------------ recommendations
class Recommendation(Base):
    __tablename__ = "recommendations"

    id = Column(Integer, primary_key=True)
    official_id = Column(Integer, ForeignKey("officials.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    source = Column(Enum(RecommendationSource), default=RecommendationSource.internal)
    score = Column(Float, default=0.0)  # ranking score
    reason = Column(String(500))
    status = Column(Enum(RecommendationStatus), default=RecommendationStatus.pending)
    recommended_at = Column(DateTime, default=datetime.utcnow)

    official = relationship("Official", back_populates="recommendations")
    course = relationship("Course", back_populates="recommendations")


# ----------------------------------------------------------------- documents
class Document(Base):
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True)
    uploaded_by = Column(Integer, ForeignKey("officials.id"), nullable=False)
    title = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_type = Column(String(20))  # pdf, docx, pptx, txt
    extracted_text = Column(Text)
    processed = Column(Boolean, default=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    uploaded_by_official = relationship("Official", back_populates="documents")
    quizzes = relationship("Quiz", back_populates="document")


# ------------------------------------------------------------------- quizzes
class Quiz(Base):
    __tablename__ = "quizzes"

    id = Column(Integer, primary_key=True)
    title = Column(String(255), nullable=False)
    document_id = Column(Integer, ForeignKey("documents.id"), nullable=True)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=True)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=True)
    generated_by = Column(Enum(QuizGeneratedBy), default=QuizGeneratedBy.ai)
    created_by = Column(Integer, ForeignKey("officials.id"))
    difficulty = Column(String(20), default="medium")
    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="quizzes")
    course = relationship("Course", back_populates="quizzes")
    questions = relationship("Question", back_populates="quiz", cascade="all, delete-orphan")
    attempts = relationship("QuizAttempt", back_populates="quiz")


# ----------------------------------------------------------------- questions
class Question(Base):
    __tablename__ = "questions"

    id = Column(Integer, primary_key=True)
    quiz_id = Column(Integer, ForeignKey("quizzes.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=True)
    question_text = Column(Text, nullable=False)
    question_type = Column(String(20), default="mcq")
    difficulty = Column(String(20), default="medium")
    explanation = Column(Text)

    quiz = relationship("Quiz", back_populates="questions")
    skill = relationship("Skill", back_populates="questions")
    options = relationship("QuestionOption", back_populates="question", cascade="all, delete-orphan")
    answers = relationship("QuizAttemptAnswer", back_populates="question")


# --------------------------------------------------------- question_options
class QuestionOption(Base):
    __tablename__ = "question_options"

    id = Column(Integer, primary_key=True)
    question_id = Column(Integer, ForeignKey("questions.id"), nullable=False)
    option_text = Column(Text, nullable=False)
    is_correct = Column(Boolean, default=False)

    question = relationship("Question", back_populates="options")


# ------------------------------------------------------------- quiz_attempts
class QuizAttempt(Base):
    __tablename__ = "quiz_attempts"

    id = Column(Integer, primary_key=True)
    quiz_id = Column(Integer, ForeignKey("quizzes.id"), nullable=False)
    official_id = Column(Integer, ForeignKey("officials.id"), nullable=False)
    started_at = Column(DateTime, default=datetime.utcnow)
    submitted_at = Column(DateTime, nullable=True)
    score = Column(Float, default=0.0)
    total_questions = Column(Integer, default=0)
    status = Column(Enum(AttemptStatus), default=AttemptStatus.in_progress)

    quiz = relationship("Quiz", back_populates="attempts")
    official = relationship("Official", back_populates="quiz_attempts")
    answers = relationship("QuizAttemptAnswer", back_populates="attempt", cascade="all, delete-orphan")


# ------------------------------------------------------ quiz_attempt_answers
class QuizAttemptAnswer(Base):
    __tablename__ = "quiz_attempt_answers"

    id = Column(Integer, primary_key=True)
    attempt_id = Column(Integer, ForeignKey("quiz_attempts.id"), nullable=False)
    question_id = Column(Integer, ForeignKey("questions.id"), nullable=False)
    selected_option_id = Column(Integer, ForeignKey("question_options.id"), nullable=True)
    is_correct = Column(Boolean, default=False)

    attempt = relationship("QuizAttempt", back_populates="answers")
    question = relationship("Question", back_populates="answers")
    selected_option = relationship("QuestionOption")


# ------------------------------------------------------------------ audit_logs
class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True)
    official_id = Column(Integer, ForeignKey("officials.id"), nullable=True)
    action = Column(String(100), nullable=False)  # e.g. LOGIN, QUIZ_SUBMIT, COURSE_ENROLL
    entity_type = Column(String(50))
    entity_id = Column(Integer)
    details = Column(JSON)
    ip_address = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)


# ------------------------------------------------------- role_requirements ---
class RoleRequirement(Base):
    __tablename__ = "role_requirements"

    id = Column(Integer, primary_key=True)
    role_id = Column(Integer, ForeignKey("roles.id"), nullable=False)
    skill_id = Column(Integer, ForeignKey("skills.id"), nullable=False)
    required_level = Column(Integer, default=3)
    priority = Column(String(20), default="high")  # high, medium, low

    role = relationship("Role", back_populates="requirements")
    skill = relationship("Skill", back_populates="role_requirements")

    __table_args__ = (UniqueConstraint("role_id", "skill_id", name="uq_role_skill_req"),)


# ---------------------------------------------------------------- progress ---
class Progress(Base):
    __tablename__ = "progress"

    id = Column(Integer, primary_key=True)
    official_id = Column(Integer, ForeignKey("officials.id"), nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id"), nullable=False)
    completion = Column(Float, default=0.0)  # percentage 0.0 - 100.0
    learning_hours = Column(Float, default=0.0)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    official = relationship("Official", back_populates="progress_records")
    course = relationship("Course", back_populates="progress_records")

    __table_args__ = (UniqueConstraint("official_id", "course_id", name="uq_official_course_progress"),)
