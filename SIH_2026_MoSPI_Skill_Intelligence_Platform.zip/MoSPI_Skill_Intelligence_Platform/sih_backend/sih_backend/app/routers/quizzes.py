from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_official
from app.models import (
    AttemptStatus, Document, Official, Question, QuestionOption, Quiz,
    QuizAttempt, QuizAttemptAnswer, QuizGeneratedBy
)
from app.schemas import (
    AttemptResultOut, AttemptStartOut, AttemptSubmitRequest,
    QuizGenerateRequest, QuizOut
)
from app.services.audit_service import log_action
from app.services.competency_engine import apply_quiz_result_to_skill
from app.services.quiz_generator import generate_mcqs

router = APIRouter(prefix="/quizzes", tags=["quizzes"])


@router.post("/generate", response_model=QuizOut, status_code=201)
def generate_quiz_from_document(
    payload: QuizGenerateRequest, db: Session = Depends(get_db),
    official: Official = Depends(get_current_official),
):
    document = db.query(Document).filter(Document.id == payload.document_id).first()
    if not document:
        raise HTTPException(status_code=404, detail="Document not found")
    if not document.processed or not document.extracted_text:
        raise HTTPException(status_code=400, detail="Document has no extracted text yet")

    try:
        raw_questions = generate_mcqs(
            document.extracted_text, num_questions=payload.num_questions, difficulty=payload.difficulty
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=f"AI quiz generation failed: {exc}")

    quiz = Quiz(
        title=f"Quiz: {document.title}",
        document_id=document.id,
        course_id=payload.course_id,
        skill_id=payload.skill_id,
        generated_by=QuizGeneratedBy.ai,
        created_by=official.id,
        difficulty=payload.difficulty,
    )
    db.add(quiz)
    db.flush()

    for q in raw_questions:
        question = Question(
            quiz_id=quiz.id,
            skill_id=payload.skill_id,
            question_text=q["question_text"],
            question_type="mcq",
            difficulty=payload.difficulty,
            explanation=q.get("explanation"),
        )
        db.add(question)
        db.flush()
        for opt in q["options"]:
            db.add(QuestionOption(
                question_id=question.id, option_text=opt["text"], is_correct=opt["is_correct"]
            ))

    db.commit()
    db.refresh(quiz)

    log_action(db, official.id, "QUIZ_GENERATED", "quiz", quiz.id,
               details={"document_id": document.id, "num_questions": len(raw_questions)})
    return quiz


@router.get("/{quiz_id}", response_model=QuizOut)
def get_quiz(quiz_id: int, db: Session = Depends(get_db),
             official: Official = Depends(get_current_official)):
    quiz = db.query(Quiz).filter(Quiz.id == quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    return quiz


@router.post("/{quiz_id}/start", response_model=AttemptStartOut)
def start_attempt(quiz_id: int, db: Session = Depends(get_db),
                   official: Official = Depends(get_current_official)):
    quiz = db.query(Quiz).filter(Quiz.id == quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")

    attempt = QuizAttempt(
        quiz_id=quiz.id, official_id=official.id,
        total_questions=len(quiz.questions), status=AttemptStatus.in_progress,
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)
    return AttemptStartOut(attempt_id=attempt.id, quiz=quiz)


@router.post("/attempts/{attempt_id}/submit", response_model=AttemptResultOut)
def submit_attempt(
    attempt_id: int, payload: AttemptSubmitRequest, db: Session = Depends(get_db),
    official: Official = Depends(get_current_official),
):
    attempt = db.query(QuizAttempt).filter(QuizAttempt.id == attempt_id).first()
    if not attempt:
        raise HTTPException(status_code=404, detail="Attempt not found")
    if attempt.official_id != official.id:
        raise HTTPException(status_code=403, detail="Not your attempt")
    if attempt.status == AttemptStatus.submitted:
        raise HTTPException(status_code=400, detail="Attempt already submitted")

    correct_count = 0
    for ans in payload.answers:
        question = db.query(Question).filter(Question.id == ans.question_id).first()
        if not question or question.quiz_id != attempt.quiz_id:
            continue
        selected = None
        is_correct = False
        if ans.selected_option_id is not None:
            selected = db.query(QuestionOption).filter(
                QuestionOption.id == ans.selected_option_id,
                QuestionOption.question_id == question.id,
            ).first()
            is_correct = bool(selected and selected.is_correct)
        if is_correct:
            correct_count += 1
        db.add(QuizAttemptAnswer(
            attempt_id=attempt.id, question_id=question.id,
            selected_option_id=selected.id if selected else None, is_correct=is_correct,
        ))

    total = attempt.total_questions or len(payload.answers) or 1
    percentage = round((correct_count / total) * 100, 2)

    attempt.score = percentage
    attempt.submitted_at = datetime.utcnow()
    attempt.status = AttemptStatus.submitted
    db.commit()

    skill_updates = []
    quiz = db.query(Quiz).filter(Quiz.id == attempt.quiz_id).first()
    if quiz and quiz.skill_id:
        update = apply_quiz_result_to_skill(db, official.id, quiz.skill_id, percentage, attempt.id)
        if update:
            skill_updates.append(update)

    log_action(db, official.id, "QUIZ_SUBMIT", "quiz_attempt", attempt.id,
               details={"score": percentage, "correct": correct_count, "total": total})

    return AttemptResultOut(
        attempt_id=attempt.id, score=percentage, total_questions=total,
        correct_count=correct_count, percentage=percentage, skill_updates=skill_updates,
    )


@router.get("/attempts/me", response_model=list[dict])
def my_attempts(db: Session = Depends(get_db), official: Official = Depends(get_current_official)):
    attempts = db.query(QuizAttempt).filter(QuizAttempt.official_id == official.id).all()
    return [
        {
            "attempt_id": a.id, "quiz_id": a.quiz_id, "score": a.score,
            "status": a.status.value if hasattr(a.status, "value") else a.status,
            "started_at": a.started_at, "submitted_at": a.submitted_at,
        }
        for a in attempts
    ]
