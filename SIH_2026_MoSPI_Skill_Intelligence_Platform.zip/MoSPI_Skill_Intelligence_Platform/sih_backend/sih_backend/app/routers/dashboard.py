from sqlalchemy import func
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_official, require_roles
from app.models import (
    Course, Official, OfficialCompetency, QuizAttempt, Recommendation,
    RecommendationStatus, Skill
)
from app.services.recommender import compute_skill_gaps

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/me")
def employee_dashboard(db: Session = Depends(get_db), official: Official = Depends(get_current_official)):
    competencies = (
        db.query(OfficialCompetency, Skill)
        .join(Skill, Skill.id == OfficialCompetency.skill_id)
        .filter(OfficialCompetency.official_id == official.id)
        .all()
    )
    gaps = compute_skill_gaps(db, official.id)

    total_skills = len(competencies)
    avg_progress = 0.0
    if total_skills:
        avg_progress = round(
            sum(c.current_level / (s.max_level or 1) for c, s in competencies) / total_skills * 100, 1
        )

    learning_hours = (
        db.query(func.coalesce(func.sum(Course.duration_hours), 0))
        .join(Recommendation, Recommendation.course_id == Course.id)
        .filter(
            Recommendation.official_id == official.id,
            Recommendation.status == RecommendationStatus.completed,
        )
        .scalar()
    )

    completed_courses = (
        db.query(Recommendation)
        .filter(
            Recommendation.official_id == official.id,
            Recommendation.status == RecommendationStatus.completed,
        )
        .count()
    )

    return {
        "official_id": official.id,
        "name": official.name,
        "current_competencies": [
            {
                "skill_id": s.id, "skill_name": s.name,
                "current_level": c.current_level, "target_level": c.target_level, "max_level": s.max_level,
            }
            for c, s in competencies
        ],
        "skill_gaps": gaps,
        "overall_progress_pct": avg_progress,
        "learning_hours_completed": float(learning_hours or 0),
        "courses_completed": completed_courses,
    }


@router.get("/admin/overview")
def admin_dashboard(db: Session = Depends(get_db), _admin: Official = Depends(require_roles("admin"))):
    total_officials = db.query(Official).filter(Official.is_active == True).count()  # noqa: E712

    # competency distribution: avg current_level per skill across the org
    distribution_rows = (
        db.query(Skill.name, func.avg(OfficialCompetency.current_level), func.count(OfficialCompetency.id))
        .join(OfficialCompetency, OfficialCompetency.skill_id == Skill.id)
        .group_by(Skill.name)
        .all()
    )
    competency_distribution = [
        {"skill": name, "avg_level": round(float(avg_level or 0), 2), "officials_assessed": count}
        for name, avg_level, count in distribution_rows
    ]

    # emerging / most common skill gaps org-wide
    gap_rows = (
        db.query(Skill.name, func.count(OfficialCompetency.id))
        .join(OfficialCompetency, OfficialCompetency.skill_id == Skill.id)
        .filter(OfficialCompetency.current_level < OfficialCompetency.target_level)
        .group_by(Skill.name)
        .order_by(func.count(OfficialCompetency.id).desc())
        .limit(10)
        .all()
    )
    top_org_gaps = [{"skill": name, "officials_with_gap": count} for name, count in gap_rows]

    # training effectiveness: avg quiz score trend proxy = overall avg score
    avg_quiz_score = db.query(func.avg(QuizAttempt.score)).scalar()

    completed_recs = db.query(Recommendation).filter(
        Recommendation.status == RecommendationStatus.completed
    ).count()
    total_recs = db.query(Recommendation).count()
    completion_rate = round((completed_recs / total_recs) * 100, 1) if total_recs else 0.0

    return {
        "total_active_officials": total_officials,
        "competency_distribution": competency_distribution,
        "top_organization_wide_skill_gaps": top_org_gaps,
        "avg_quiz_score": round(float(avg_quiz_score or 0), 2),
        "recommendation_completion_rate_pct": completion_rate,
    }
