from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_official, require_roles
from app.models import CompetencyDomain, Official, OfficialCompetency, Skill
from app.schemas import (
    CompetencyOut, CompetencyUpdate, DomainOut, SkillCreate,
    SkillGapItem, SkillOut
)
from app.services.audit_service import log_action
from app.services.recommender import compute_skill_gaps

router = APIRouter(prefix="/competencies", tags=["competencies"])


@router.get("/domains", response_model=list[DomainOut])
def list_domains(db: Session = Depends(get_db)):
    return db.query(CompetencyDomain).all()


@router.post("/domains", response_model=DomainOut)
def create_domain(
    name: str, category: str, description: str | None = None,
    db: Session = Depends(get_db), _admin: Official = Depends(require_roles("admin")),
):
    domain = CompetencyDomain(name=name, category=category, description=description)
    db.add(domain)
    db.commit()
    db.refresh(domain)
    return domain


@router.get("/skills", response_model=list[SkillOut])
def list_skills(domain_id: int | None = None, db: Session = Depends(get_db)):
    query = db.query(Skill)
    if domain_id:
        query = query.filter(Skill.domain_id == domain_id)
    return query.all()


@router.post("/skills", response_model=SkillOut)
def create_skill(
    payload: SkillCreate, db: Session = Depends(get_db),
    _admin: Official = Depends(require_roles("admin")),
):
    skill = Skill(**payload.model_dump())
    db.add(skill)
    db.commit()
    db.refresh(skill)
    return skill


@router.get("/me", response_model=list[CompetencyOut])
def my_competencies(
    db: Session = Depends(get_db), official: Official = Depends(get_current_official)
):
    return (
        db.query(OfficialCompetency)
        .filter(OfficialCompetency.official_id == official.id)
        .all()
    )


@router.put("/me", response_model=CompetencyOut)
def upsert_my_competency(
    payload: CompetencyUpdate, db: Session = Depends(get_db),
    official: Official = Depends(get_current_official),
):
    skill = db.query(Skill).filter(Skill.id == payload.skill_id).first()
    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")
    if payload.current_level > skill.max_level or payload.current_level < 0:
        raise HTTPException(status_code=400, detail=f"current_level must be 0-{skill.max_level}")

    comp = (
        db.query(OfficialCompetency)
        .filter(
            OfficialCompetency.official_id == official.id,
            OfficialCompetency.skill_id == payload.skill_id,
        )
        .first()
    )
    if comp is None:
        comp = OfficialCompetency(official_id=official.id, skill_id=payload.skill_id)
        db.add(comp)

    comp.current_level = payload.current_level
    if payload.target_level is not None:
        comp.target_level = payload.target_level
    comp.assessment_source = payload.assessment_source
    db.commit()
    db.refresh(comp)

    log_action(db, official.id, "COMPETENCY_UPDATE", "skill", payload.skill_id,
               details={"current_level": payload.current_level})
    return comp


@router.put("/me/batch", response_model=list[CompetencyOut])
def batch_update_competencies(
    payload: list[CompetencyUpdate], db: Session = Depends(get_db),
    official: Official = Depends(get_current_official),
):
    results = []
    for item in payload:
        skill = db.query(Skill).filter(Skill.id == item.skill_id).first()
        if not skill:
            continue
        lvl = max(0, min(skill.max_level or 5, item.current_level))
        comp = (
            db.query(OfficialCompetency)
            .filter(
                OfficialCompetency.official_id == official.id,
                OfficialCompetency.skill_id == item.skill_id,
            )
            .first()
        )
        if comp is None:
            comp = OfficialCompetency(official_id=official.id, skill_id=item.skill_id)
            db.add(comp)
        comp.current_level = lvl
        if item.target_level is not None:
            comp.target_level = item.target_level
        comp.assessment_source = item.assessment_source
        results.append(comp)
    db.commit()
    for c in results:
        db.refresh(c)
    log_action(db, official.id, "BATCH_COMPETENCY_UPDATE", "official", official.id,
               details={"updated_count": len(results)})
    return results


@router.get("/me/gaps", response_model=list[SkillGapItem])
def my_skill_gaps(
    db: Session = Depends(get_db), official: Official = Depends(get_current_official)
):
    return compute_skill_gaps(db, official.id)


@router.get("/{official_id}/gaps", response_model=list[SkillGapItem])
def official_skill_gaps(
    official_id: int, db: Session = Depends(get_db),
    _admin: Official = Depends(require_roles("admin", "trainer")),
):
    return compute_skill_gaps(db, official_id)
