from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_official
from app.models import Department, Official, OfficialCompetency, RefreshToken, Role, Skill
from app.schemas import (
    LoginRequest, OfficialOut, OfficialRegister, RefreshRequest, TokenResponse
)
from app.security import (
    create_access_token, create_refresh_token, decode_token,
    hash_password, verify_password
)
from app.services.audit_service import log_action


def seed_initial_competencies_for_official(db: Session, official: Official, initial_skills: dict = None):
    """Initializes official's competencies in MySQL.
    If initial_skills is provided (from registration/onboarding), sets those exact user-specified levels (0-5).
    Otherwise, sets 0 for all competencies so newly registered users start with a clean slate (0% readiness).
    """
    initial_map = initial_skills or {}
    all_skills = db.query(Skill).all()
    for sk in all_skills:
        existing = db.query(OfficialCompetency).filter(
            OfficialCompetency.official_id == official.id,
            OfficialCompetency.skill_id == sk.id
        ).first()
        if not existing:
            lvl = 0
            if str(sk.id) in initial_map:
                lvl = int(initial_map[str(sk.id)])
            elif sk.id in initial_map:
                lvl = int(initial_map[sk.id])
            elif sk.name in initial_map:
                lvl = int(initial_map[sk.name])
            else:
                for k, v in initial_map.items():
                    if str(k).strip().lower() == sk.name.strip().lower():
                        lvl = int(v)
                        break

            lvl = max(0, min(sk.max_level or 5, lvl))
            db.add(OfficialCompetency(
                official_id=official.id,
                skill_id=sk.id,
                current_level=lvl,
                target_level=3,
                assessment_source="self_assessment"
            ))
    db.commit()

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/register", response_model=OfficialOut, status_code=status.HTTP_201_CREATED)
def register(payload: OfficialRegister, db: Session = Depends(get_db)):
    if db.query(Official).filter(Official.email == payload.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    if db.query(Official).filter(Official.employee_code == payload.employee_code).first():
        raise HTTPException(status_code=400, detail="Employee code already exists")

    # Resolve Role
    resolved_role_id = payload.role_id
    if not resolved_role_id and payload.role_name:
        role_search = payload.role_name.strip()
        role_match = db.query(Role).filter(Role.name.ilike(role_search)).first()
        if not role_match:
            # Check common aliases
            if "stat" in role_search.lower():
                role_match = db.query(Role).filter(Role.name == "Statistical Officer").first()
            elif "analyst" in role_search.lower() or "data" in role_search.lower():
                role_match = db.query(Role).filter(Role.name == "Data Analyst").first()
            elif "admin" in role_search.lower():
                role_match = db.query(Role).filter(Role.name == "admin").first()
            elif "senior" in role_search.lower():
                role_match = db.query(Role).filter(Role.name == "Senior Statistical Officer").first()
        if role_match:
            resolved_role_id = role_match.id

    # Fallback to Statistical Officer if still not assigned
    if not resolved_role_id:
        def_role = db.query(Role).filter(Role.name == "Statistical Officer").first()
        if def_role:
            resolved_role_id = def_role.id

    # Resolve Department
    resolved_dept_id = payload.department_id
    if not resolved_dept_id and payload.department_name:
        dept_match = db.query(Department).filter(Department.name.ilike(payload.department_name.strip())).first()
        if not dept_match:
            dept_code = "".join(c for c in payload.department_name if c.isupper())[:10] or "DEPT"
            dept_match = Department(name=payload.department_name.strip(), code=dept_code)
            db.add(dept_match)
            db.flush()
        resolved_dept_id = dept_match.id

    if not resolved_dept_id:
        def_dept = db.query(Department).first()
        if def_dept:
            resolved_dept_id = def_dept.id

    official = Official(
        employee_code=payload.employee_code,
        name=payload.name,
        email=payload.email,
        password_hash=hash_password(payload.password),
        designation=payload.designation or (payload.role_name or "Statistical Officer"),
        department_id=resolved_dept_id,
        role_id=resolved_role_id,
        qualification=payload.qualification,
        work_experience_years=payload.work_experience_years or 0,
    )
    db.add(official)
    db.commit()
    db.refresh(official)

    # Initialize baseline competencies in MySQL for this new official
    seed_initial_competencies_for_official(db, official, initial_skills=payload.initial_skills)

    # Issue JWT tokens for instant seamless onboarding
    access_token = create_access_token(subject=str(official.id))
    refresh_token, expires_at = create_refresh_token(subject=str(official.id))
    db.add(RefreshToken(official_id=official.id, token=refresh_token, expires_at=expires_at))
    db.commit()

    log_action(db, official.id, "REGISTER", "official", official.id)

    # Convert to response dictionary with tokens and names
    response_data = OfficialOut(
        id=official.id,
        employee_code=official.employee_code,
        name=official.name,
        email=official.email,
        designation=official.designation,
        department_id=official.department_id,
        department_name=official.department.name if official.department else None,
        role_id=official.role_id,
        role_name=official.role.name if official.role else None,
        work_experience_years=official.work_experience_years,
        is_active=official.is_active,
        access_token=access_token,
        refresh_token=refresh_token,
    )
    return response_data


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    official = db.query(Official).filter(Official.email == payload.email).first()
    if not official or not verify_password(payload.password, official.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not official.is_active:
        raise HTTPException(status_code=403, detail="Account is deactivated")

    access_token = create_access_token(subject=str(official.id))
    refresh_token, expires_at = create_refresh_token(subject=str(official.id))

    db.add(RefreshToken(official_id=official.id, token=refresh_token, expires_at=expires_at))
    db.commit()

    log_action(db, official.id, "LOGIN", "official", official.id,
               ip_address=request.client.host if request.client else None)
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user=OfficialOut(
            id=official.id,
            employee_code=official.employee_code,
            name=official.name,
            email=official.email,
            designation=official.designation,
            department_id=official.department_id,
            department_name=official.department.name if official.department else None,
            role_id=official.role_id,
            role_name=official.role.name if official.role else None,
            work_experience_years=official.work_experience_years,
            is_active=official.is_active,
        )
    )


@router.post("/refresh", response_model=TokenResponse)
def refresh(payload: RefreshRequest, db: Session = Depends(get_db)):
    try:
        claims = decode_token(payload.refresh_token)
    except ValueError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    if claims.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Not a refresh token")

    stored = db.query(RefreshToken).filter(RefreshToken.token == payload.refresh_token).first()
    if not stored or stored.revoked or stored.expires_at < datetime.utcnow():
        raise HTTPException(status_code=401, detail="Refresh token is invalid or expired")

    official_id = claims["sub"]
    new_access = create_access_token(subject=official_id)
    new_refresh, expires_at = create_refresh_token(subject=official_id)

    stored.revoked = True  # rotate refresh tokens
    db.add(RefreshToken(official_id=int(official_id), token=new_refresh, expires_at=expires_at))
    db.commit()

    return TokenResponse(access_token=new_access, refresh_token=new_refresh)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(payload: RefreshRequest, db: Session = Depends(get_db),
           official: Official = Depends(get_current_official)):
    stored = db.query(RefreshToken).filter(RefreshToken.token == payload.refresh_token).first()
    if stored:
        stored.revoked = True
        db.commit()
    log_action(db, official.id, "LOGOUT", "official", official.id)
    return None


@router.get("/me", response_model=OfficialOut)
def me(official: Official = Depends(get_current_official)):
    return official
