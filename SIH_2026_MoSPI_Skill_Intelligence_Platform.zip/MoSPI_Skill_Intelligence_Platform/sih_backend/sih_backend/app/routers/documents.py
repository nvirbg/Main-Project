import os
import uuid

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.deps import get_current_official
from app.models import Document, Official
from app.schemas import DocumentOut
from app.services.audit_service import log_action
from app.utils.file_parser import extract_text, infer_file_type

router = APIRouter(prefix="/documents", tags=["documents"])

ALLOWED_TYPES = {"pdf", "docx", "pptx", "txt", "md"}


@router.post("/upload", response_model=DocumentOut, status_code=201)
def upload_document(
    title: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    official: Official = Depends(get_current_official),
):
    file_type = infer_file_type(file.filename)
    if file_type not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '.{file_type}'. Allowed: {sorted(ALLOWED_TYPES)}",
        )

    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    stored_name = f"{uuid.uuid4().hex}_{file.filename}"
    stored_path = os.path.join(settings.UPLOAD_DIR, stored_name)

    contents = file.file.read()
    max_bytes = settings.MAX_UPLOAD_MB * 1024 * 1024
    if len(contents) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File exceeds {settings.MAX_UPLOAD_MB}MB limit")

    with open(stored_path, "wb") as f:
        f.write(contents)

    document = Document(
        uploaded_by=official.id,
        title=title,
        file_path=stored_path,
        file_type=file_type,
        processed=False,
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    try:
        text = extract_text(stored_path, file_type)
        document.extracted_text = text
        document.processed = True
        db.commit()
        db.refresh(document)
    except Exception as exc:
        # Document row is kept even if extraction fails, so an admin can retry.
        log_action(db, official.id, "DOCUMENT_EXTRACT_FAILED", "document", document.id,
                   details={"error": str(exc)})

    log_action(db, official.id, "DOCUMENT_UPLOAD", "document", document.id,
               details={"file_type": file_type})
    return document


@router.get("/{document_id}", response_model=DocumentOut)
def get_document(
    document_id: int, db: Session = Depends(get_db),
    official: Official = Depends(get_current_official),
):
    doc = db.query(Document).filter(Document.id == document_id).first()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return doc


@router.get("", response_model=list[DocumentOut])
def list_my_documents(
    db: Session = Depends(get_db), official: Official = Depends(get_current_official)
):
    return db.query(Document).filter(Document.uploaded_by == official.id).all()
