from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import require_roles
from app.models import AuditLog, Official

router = APIRouter(prefix="/audit-logs", tags=["audit"])


@router.get("")
def list_audit_logs(
    skip: int = 0, limit: int = 100, official_id: int | None = None,
    db: Session = Depends(get_db), _admin: Official = Depends(require_roles("admin")),
):
    query = db.query(AuditLog)
    if official_id:
        query = query.filter(AuditLog.official_id == official_id)
    logs = query.order_by(AuditLog.created_at.desc()).offset(skip).limit(limit).all()
    return [
        {
            "id": log.id, "official_id": log.official_id, "action": log.action,
            "entity_type": log.entity_type, "entity_id": log.entity_id,
            "details": log.details, "ip_address": log.ip_address, "created_at": log.created_at,
        }
        for log in logs
    ]
