from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.deps import require_roles
from app.models import Course, CourseSkillTag, Official
from app.schemas import CourseCreate, CourseOut

router = APIRouter(prefix="/courses", tags=["courses"])


@router.get("", response_model=list[CourseOut])
def list_courses(skip: int = 0, limit: int = 50, db: Session = Depends(get_db)):
    return db.query(Course).offset(skip).limit(limit).all()


@router.get("/{course_id}", response_model=CourseOut)
def get_course(course_id: int, db: Session = Depends(get_db)):
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    return course


@router.post("", response_model=CourseOut, status_code=201)
def create_course(
    payload: CourseCreate, db: Session = Depends(get_db),
    _admin: Official = Depends(require_roles("admin", "trainer")),
):
    data = payload.model_dump(exclude={"skill_ids"})
    course = Course(**data)
    db.add(course)
    db.flush()

    for skill_id in payload.skill_ids:
        db.add(CourseSkillTag(course_id=course.id, skill_id=skill_id, relevance_score=1.0))

    db.commit()
    db.refresh(course)
    return course


@router.post("/sync-igot", status_code=202)
def sync_igot_catalogue(_admin: Official = Depends(require_roles("admin"))):
    """
    Stub for the iGOT Karmayogi catalogue sync job described in the problem
    statement. In production this calls the iGOT API (settings.IGOT_API_BASE_URL)
    to pull course metadata, enrolment status and completion status, and
    upserts local `courses` / `recommendations` rows. Wire in real HTTP calls
    (e.g. via httpx) once iGOT API credentials + endpoint contracts are available.
    """
    if not settings.IGOT_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="IGOT_API_KEY not configured — cannot reach iGOT Karmayogi API.",
        )
    return {
        "status": "queued",
        "message": "iGOT catalogue sync scheduled (stub — implement HTTP call to IGOT_API_BASE_URL).",
    }
