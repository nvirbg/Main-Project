from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_official, require_roles
from app.models import Official
from app.schemas import OfficialOut

router = APIRouter(prefix="/officials", tags=["officials"])


@router.get("", response_model=list[OfficialOut])
def list_officials(
    skip: int = 0, limit: int = 50,
    db: Session = Depends(get_db),
    _admin: Official = Depends(require_roles("admin")),
):
    return db.query(Official).offset(skip).limit(limit).all()


@router.get("/{official_id}", response_model=OfficialOut)
def get_official(
    official_id: int, db: Session = Depends(get_db),
    current: Official = Depends(get_current_official),
):
    if current.id != official_id:
        # non-owners must be admins
        from app.models import Role
        role = db.query(Role).filter(Role.id == current.role_id).first()
        if not role or role.name != "admin":
            raise HTTPException(status_code=403, detail="Not authorized to view this profile")

    official = db.query(Official).filter(Official.id == official_id).first()
    if not official:
        raise HTTPException(status_code=404, detail="Official not found")
    return official


@router.patch("/{official_id}/deactivate", response_model=OfficialOut)
def deactivate_official(
    official_id: int, db: Session = Depends(get_db),
    _admin: Official = Depends(require_roles("admin")),
):
    official = db.query(Official).filter(Official.id == official_id).first()
    if not official:
        raise HTTPException(status_code=404, detail="Official not found")
    official.is_active = False
    db.commit()
    db.refresh(official)
    return official
