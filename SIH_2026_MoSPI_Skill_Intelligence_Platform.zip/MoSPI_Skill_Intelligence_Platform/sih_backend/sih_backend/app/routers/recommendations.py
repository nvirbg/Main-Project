from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_official, require_roles
from app.models import Official, Recommendation, RecommendationSource
from app.schemas import RecommendationOut
from app.services.audit_service import log_action
from app.services.recommender import recommend_courses

router = APIRouter(prefix="/recommendations", tags=["recommendations"])


@router.post("/me/generate", response_model=list[RecommendationOut])
def generate_my_recommendations(
    top_n: int = 10, db: Session = Depends(get_db),
    official: Official = Depends(get_current_official),
):
    ranked = recommend_courses(db, official.id, top_n=top_n)
    created = []
    for item in ranked:
        rec = Recommendation(
            official_id=official.id,
            course_id=item["course_id"],
            source=RecommendationSource.tpac if item["is_tpac_recommended"] else RecommendationSource.internal,
            score=item["score"],
            reason=item["reason"],
        )
        db.add(rec)
        created.append(rec)
    db.commit()
    for rec in created:
        db.refresh(rec)

    log_action(db, official.id, "RECOMMENDATIONS_GENERATED", "official", official.id,
               details={"count": len(created)})
    return created


@router.get("/me", response_model=list[RecommendationOut])
def my_recommendations(db: Session = Depends(get_db), official: Official = Depends(get_current_official)):
    return (
        db.query(Recommendation)
        .filter(Recommendation.official_id == official.id)
        .order_by(Recommendation.score.desc())
        .all()
    )


@router.get("/{official_id}", response_model=list[RecommendationOut])
def recommendations_for_official(
    official_id: int, db: Session = Depends(get_db),
    _admin: Official = Depends(require_roles("admin", "trainer")),
):
    return (
        db.query(Recommendation)
        .filter(Recommendation.official_id == official_id)
        .order_by(Recommendation.score.desc())
        .all()
    )
