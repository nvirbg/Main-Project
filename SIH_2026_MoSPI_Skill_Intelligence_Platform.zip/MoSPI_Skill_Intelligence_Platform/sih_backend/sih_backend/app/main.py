
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine
from app.routers import auth, officials, competencies, courses, documents, quizzes, recommendations, dashboard, audit, unified_api

app = FastAPI(
    title="AI-Enabled Skill Intelligence & Learning Platform",
    description=(
        "Backend for competency-gap assessment, personalized learning recommendations "
        "(integrated with iGOT Karmayogi), and AI-generated quizzes/MCQs from uploaded "
        "learning material, for India's Official Statistical System."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    # For quick local/demo bootstrapping. In production, use Alembic migrations instead.
    Base.metadata.create_all(bind=engine)


app.include_router(unified_api.router)
app.include_router(auth.router)
app.include_router(officials.router)
app.include_router(competencies.router)
app.include_router(courses.router)
app.include_router(documents.router)
app.include_router(quizzes.router)
app.include_router(recommendations.router)
app.include_router(dashboard.router)
app.include_router(audit.router)


import os
from starlette.staticfiles import StaticFiles

@app.get("/health", tags=["health"])
def health_check():
    return {"status": "ok"}


# Mount frontend single-page application
candidate_dirs = [
    os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../frontend")),
    os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../frontend")),
    os.path.abspath(os.path.join(os.getcwd(), "../../frontend")),
    os.path.abspath(os.path.join(os.getcwd(), "frontend")),
]
frontend_dir = next((d for d in candidate_dirs if os.path.exists(d) and os.path.isfile(os.path.join(d, "index.html"))), None)
if frontend_dir:
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")


