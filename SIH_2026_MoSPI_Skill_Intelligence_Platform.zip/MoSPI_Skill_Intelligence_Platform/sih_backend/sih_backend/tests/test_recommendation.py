import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ai.skill_gap import calculate_skill_gaps, calculate_overall_competency, get_priority_gaps
from ai.recommender import recommend_courses, score_course

def test_statistical_officer_gaps():
    role_reqs = {
        "Survey Design & Questionnaire Formulation": {"required_level": 4, "priority": "high"},
        "Sampling Techniques & Estimation": {"required_level": 4, "priority": "critical"},
        "National Accounts Statistics (SNA 2008)": {"required_level": 3, "priority": "medium"},
        "Price Statistics (CPI & WPI)": {"required_level": 3, "priority": "medium"},
        "Python for Statistical Computing": {"required_level": 3, "priority": "high"},
        "Statistical Ethics & Code of Practice": {"required_level": 4, "priority": "high"},
    }

    # Baseline: Python at 2/5
    user_skills = {
        "Survey Design & Questionnaire Formulation": 2,
        "Sampling Techniques & Estimation": 1,
        "National Accounts Statistics (SNA 2008)": 2,
        "Price Statistics (CPI & WPI)": 2,
        "Python for Statistical Computing": 2,
        "Statistical Ethics & Code of Practice": 3,
    }

    score_before = calculate_overall_competency(user_skills, role_reqs)
    gaps_before = calculate_skill_gaps(user_skills, role_reqs)
    top_gaps = get_priority_gaps(gaps_before, top_n=3)

    assert len(gaps_before) == 6
    assert top_gaps[0]["skill_name"] == "Sampling Techniques & Estimation"
    assert top_gaps[0]["gap"] == 3
    assert top_gaps[0]["priority"] == "critical"

    courses = [
        {
            "id": 1,
            "title": "Modern Survey Sampling and Estimation Techniques",
            "provider": "iGOT Karmayogi",
            "level": "intermediate",
            "is_tpac_recommended": True,
            "skills": ["Sampling Techniques & Estimation", "Survey Design & Questionnaire Formulation"],
        },
        {
            "id": 3,
            "title": "Python for Official Statistics & Microdata Analysis",
            "provider": "iGOT Karmayogi",
            "level": "beginner",
            "is_tpac_recommended": True,
            "skills": ["Python for Statistical Computing"],
        },
    ]

    recs_before = recommend_courses(courses, gaps_before, role="Statistical Officer")
    assert recs_before[0]["title"] == "Modern Survey Sampling and Estimation Techniques"
    assert "[NSSTA TPAC Priority]" in recs_before[0]["reason"]

    # DEMO ACTION: Change Python from 2/5 to 3/5 (closing Python gap)
    user_skills["Python for Statistical Computing"] = 3
    score_after = calculate_overall_competency(user_skills, role_reqs)
    gaps_after = calculate_skill_gaps(user_skills, role_reqs)

    assert score_after > score_before, "Readiness score must improve when Python reaches target"
    assert not any(g["skill_name"] == "Python for Statistical Computing" for g in gaps_after), "Python gap must be resolved"

    print(f"Skill gap & recommendation tests passed! Score improved from {score_before}% to {score_after}%.")

if __name__ == "__main__":
    test_statistical_officer_gaps()
