import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json() == {"status": "ok"}

def test_frontend_serving():
    res = client.get("/")
    assert res.status_code == 200
    assert "<!DOCTYPE html>" in res.text
    assert "MoSPI & iGOT Karmayogi" in res.text

def test_all_demo_personas_login_and_scores():
    users = [
        ("karthikeya@mospi.gov.in", "SecurePassword123!", "Statistical Officer"),
        ("priya.nair@mospi.gov.in", "SecurePassword123!", "Data Analyst"),
        ("rajesh.verma@mospi.gov.in", "SecurePassword123!", "Senior Statistical Officer"),
        ("admin@nssta.gov.in", "ChangeMe123!", "admin"),
    ]

    for email, pwd, expected_role in users:
        res = client.post("/auth/login", json={"email": email, "password": pwd})
        assert res.status_code == 200, f"Login failed for {email}: {res.text}"
        data = res.json()
        assert "access_token" in data
        token = data["access_token"]
        headers = {"Authorization": f"Bearer {token}"}

        if expected_role == "admin":
            # Admin can access admin dashboard
            admin_res = client.get("/dashboard/admin", headers=headers)
            assert admin_res.status_code == 200
            admin_data = admin_res.json()
            assert "metrics" in admin_data
            assert "competency_distribution_chart" in admin_data
        else:
            # Learner checks
            prof_res = client.get("/profile", headers=headers)
            assert prof_res.status_code == 200
            prof_data = prof_res.json()

            dash_res = client.get("/dashboard/learner", headers=headers)
            assert dash_res.status_code == 200
            dash_data = dash_res.json()

            gaps_res = client.get("/skill-gaps", headers=headers)
            assert gaps_res.status_code == 200

            recs_res = client.get("/recommendations", headers=headers)
            assert recs_res.status_code == 200

            # Score consistency
            prof_score = prof_data["overall_competency_score"]
            dash_score = dash_data["learner"]["overall_competency_pct"]
            assert prof_score == dash_score, f"Score mismatch for {email}: {prof_score} vs {dash_score}"

            # Learner cannot access admin dashboard
            forbidden_res = client.get("/dashboard/admin", headers=headers)
            assert forbidden_res.status_code == 403

def test_courses_and_igot_catalogue():
    res = client.get("/courses")
    assert res.status_code == 200
    courses = res.json()
    assert len(courses) >= 20, f"Expected >= 20 courses, got {len(courses)}"
    c1 = courses[0]
    assert "title" in c1
    assert "provider" in c1
    assert "skills" in c1
    assert "category" in c1

    igot_res = client.get("/integration/igot/courses")
    assert igot_res.status_code == 200
    assert len(igot_res.json()) >= 20

def test_quiz_generation_and_submission():
    login_res = client.post("/auth/login", json={"email": "karthikeya@mospi.gov.in", "password": "SecurePassword123!"})
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    gen_res = client.post("/quiz/generate", headers=headers, json={"num_questions": 4, "difficulty": "medium"})
    assert gen_res.status_code == 200
    q_data = gen_res.json()
    assert "quiz_id" in q_data
    assert len(q_data["questions"]) == 4

    # Submit answers
    answers = [{"question_id": q["id"], "selected_option": q["options"][0]} for q in q_data["questions"]]
    sub_res = client.post("/quiz/submit", headers=headers, json={"quiz_id": q_data["quiz_id"], "answers": answers})
    assert sub_res.status_code == 200
    sub_data = sub_res.json()
    assert "score_percentage" in sub_data
    assert "detailed_results" in sub_data

def test_ai_assistant_chat():
    login_res = client.post("/auth/login", json={"email": "karthikeya@mospi.gov.in", "password": "SecurePassword123!"})
    token = login_res.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    chat_res = client.post("/assistant/chat", headers=headers, json={"question": "What is the UN System of National Accounts?"})
    assert chat_res.status_code == 200
    c_data = chat_res.json()
    assert "answer" in c_data
    assert "sources" in c_data

if __name__ == "__main__":
    test_health()
    test_frontend_serving()
    test_all_demo_personas_login_and_scores()
    test_courses_and_igot_catalogue()
    test_quiz_generation_and_submission()
    test_ai_assistant_chat()
    print("ALL TESTS PASSED SUCCESSFULLY!")
