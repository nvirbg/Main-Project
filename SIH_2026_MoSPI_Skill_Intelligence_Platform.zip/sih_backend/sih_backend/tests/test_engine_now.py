import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import json

from ai.engine import analyze_user


# Load datasets
with open("data/roles.json", "r") as f:
    roles = json.load(f)

with open("data/courses.json", "r") as f:
    courses = json.load(f)


# Pick Statistical Officer
role = next(
    r for r in roles
    if r["name"] == "Statistical Officer"
)


# Demo user
user = {
    "id": "TEST001",
    "name": "Test User",
    "role": "Statistical Officer",

    # Skill levels: 1-5
    "skills": {
        "SK-001": 2,
        "SK-005": 2,
        "SK-011": 1
    },

    "completed_courses": []
}


# Run AI engine
result = analyze_user(
    user,
    role,
    courses,
    top_n=5
)


# Print results
print("\n========== OVERALL COMPETENCY ==========")
print(result["overall_competency"], "%")


print("\n========== SKILL GAPS ==========")

for gap in result["skill_gaps"]:
    print(
        gap["skill_id"],
        "| Current:",
        gap["current_level"],
        "| Required:",
        gap["required_level"],
        "| Gap:",
        gap["gap"],
        "| Priority:",
        gap["priority"]
    )


print("\n========== PRIORITY GAPS ==========")

for gap in result["priority_gaps"]:
    print(
        gap["skill_id"],
        "| Gap:",
        gap["gap"],
        "| Priority Score:",
        gap.get("weighted_priority", gap.get("priority", "N/A"))
    )


print("\n========== RECOMMENDATIONS ==========")

for course in result["recommendations"]:
    print(
        course["title"],
        "| Score:",
        course["score"],
        "| Reason:",
        course["reason"]
    )