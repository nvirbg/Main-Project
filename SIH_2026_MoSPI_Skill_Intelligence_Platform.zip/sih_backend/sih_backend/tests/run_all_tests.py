import sys
import os
import subprocess

# Ensure correct base path
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(base_dir)
sys.path.insert(0, base_dir)

py_bin = sys.executable

tests = [
    ["tests/test_all_mvp.py", "Core Platform & RBAC Integration Tests"],
    ["tests/test_recommendation.py", "AI iGOT Course Recommendation Model"],
    ["tests/test_adaptive.py", "Adaptive Competency Skill Calibration"],
    ["tests/test_assessment_now.py", "Assessment Scoring to Skill-Level Mapper"],
    ["tests/test_engine_now.py", "Competency Gap & Multiplier Engine"],
    ["tests/test_llm.py", "AI Question & MCQ Generation Engine"],
    ["analytics/matrix.py", "Workforce Multi-Dimensional Competency Matrix"],
    ["analytics/metrics.py", "NSSTA Executive Capacity & Readiness Analytics"],
    ["data/seed_data.py", "MySQL / Database Seeding & Schema Verification"],
]

print("======================================================================")
print("  EXECUTING ALL 9 AI, DATA SCIENCE & BACKEND TEST SUITES (SIH 2026)")
print("======================================================================\n")

all_ok = True
passed_count = 0

for test_file, desc in tests:
    cmd = [py_bin, test_file]
    print(f"[*] Running: {desc} ({test_file})...", end=" ", flush=True)
    res = subprocess.run(cmd, capture_output=True, text=True, cwd=base_dir)
    if res.returncode == 0:
        print("[PASSED OK]")
        passed_count += 1
    else:
        print("[FAILED]")
        print("\n--- STDOUT ---")
        print(res.stdout)
        print("--- STDERR ---")
        print(res.stderr)
        print("--------------\n")
        all_ok = False

print("\n" + "=" * 70)
if all_ok:
    print(f"  SUCCESS: ALL {passed_count}/{len(tests)} TEST SUITES PASSED CLEANLY (100% SUCCESS RATE)")
    print("======================================================================")
    sys.exit(0)
else:
    print(f"  WARNING: ONLY {passed_count}/{len(tests)} TESTS PASSED. PLEASE CHECK LOGS.")
    print("======================================================================")
    sys.exit(1)
