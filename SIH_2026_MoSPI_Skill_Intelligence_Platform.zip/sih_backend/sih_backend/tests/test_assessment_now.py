import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import json

from ai.assessment import assessment_to_skills
from ai.engine import analyze_user


# Load questions
with open("data/questions.json", "r") as f:
    questions = json.load(f)


# Example learner answers
answers = {
    "Q001": "A",
    "Q002": "A",
    "Q003": "A",
    "Q004": "A",
    "Q005": "B",
    "Q006": "A",
    "Q007": "A",
    "Q008": "A",
    "Q009": "A",
    "Q010": "A"
}


# Convert quiz answers → skill levels
skills = assessment_to_skills(
    answers,
    questions
)


print("\n========== ASSESSMENT SKILLS ==========")

for skill, level in skills.items():
    print(
        skill,
        "| Level:",
        level
    )


# Load roles and courses
with open("data/roles.json", "r") as f:
    roles = json.load(f)

with open("data/courses.json", "r") as f:
    courses = json.load(f)


# Select Statistical Officer
role = next(
    r for r in roles
    if r["name"] == "Statistical Officer"
)


# Create learner
user = {
    "id": "TEST_ASSESSMENT",
    "name": "Assessment Test User",
    "role": "Statistical Officer",
    "skills": skills,
    "completed_courses": []
}


# Run complete AI analysis
result = analyze_user(
    user,
    role,
    courses
)


print("\n========== OVERALL COMPETENCY ==========")

print(
    result["overall_competency"],
    "%"
)


print("\n========== PRIORITY GAPS ==========")

for gap in result["priority_gaps"]:

    print(
        gap["skill_id"],
        "| Current:",
        gap["current_level"],
        "| Required:",
        gap["required_level"],
        "| Gap:",
        gap["gap"],
        "| Priority:",
        gap.get("weighted_priority", gap.get("priority", "N/A"))
    )


print("\n========== RECOMMENDATIONS ==========")

for course in result["recommendations"]:

    print(
        course["title"],
        "| Score:",
        course["score"]
    )