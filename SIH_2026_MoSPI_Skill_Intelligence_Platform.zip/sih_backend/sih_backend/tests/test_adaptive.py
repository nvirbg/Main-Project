import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import json

from ai.engine import analyze_user


# Load data
with open("data/roles.json", "r") as f:
    roles = json.load(f)

with open("data/courses.json", "r") as f:
    courses = json.load(f)


role = next(
    r for r in roles
    if r["name"] == "Statistical Officer"
)


# -------------------------
# CASE 1: Inferential Statistics = 3
# -------------------------

user_before = {
    "id": "U001",
    "name": "Demo Statistical Officer",
    "role": "Statistical Officer",
    "skills": {
        "SK-001": 3,
        "SK-005": 5,
        "SK-011": 5
    },
    "completed_courses": []
}


result_before = analyze_user(
    user_before,
    role,
    courses
)


print("\n===== BEFORE =====")
print("SK-001 level:", user_before["skills"]["SK-001"])
print("Priority gaps:")

for gap in result_before["priority_gaps"]:
    print(
        gap["skill_id"],
        "gap =", gap["gap"]
    )

print("\nRecommendations:")

for course in result_before["recommendations"]:
    print(
        course["title"],
        "->",
        course["score"]
    )


# -------------------------
# CASE 2: Inferential Statistics = 4
# -------------------------

user_after = {
    "id": "U001",
    "name": "Demo Statistical Officer",
    "role": "Statistical Officer",
    "skills": {
        "SK-001": 4,
        "SK-005": 5,
        "SK-011": 5
    },
    "completed_courses": []
}


result_after = analyze_user(
    user_after,
    role,
    courses
)


print("\n===== AFTER =====")
print("SK-001 level:", user_after["skills"]["SK-001"])
print("Priority gaps:")

for gap in result_after["priority_gaps"]:
    print(
        gap["skill_id"],
        "gap =", gap["gap"]
    )

print("\nRecommendations:")

for course in result_after["recommendations"]:
    print(
        course["title"],
        "->",
        course["score"]
    )